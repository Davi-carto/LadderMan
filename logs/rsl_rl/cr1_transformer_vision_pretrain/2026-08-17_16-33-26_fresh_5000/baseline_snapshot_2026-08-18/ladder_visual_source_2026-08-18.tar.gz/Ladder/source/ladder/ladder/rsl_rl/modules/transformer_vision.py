"""Transformer-GRU visual estimator used before it is connected to PPO."""

from __future__ import annotations

from dataclasses import dataclass

import torch
from torch import nn

from ladder.utils.limb_heightmaps import RUNG


_HISTORY_FRAMES = 10
_DEPTH_FRAMES = 2
_DEPTH_HEIGHT = 60
_DEPTH_WIDTH = 80
_TOKEN_DIM = 64
_VISUAL_TOKEN_COUNT = 10
_HIDDEN_DIM = 256
_MAP_SHAPE = (10, 3)


@dataclass
class TransformerVisionOutput:
    """Deployable estimates and training-only reconstruction outputs."""

    velocity: torch.Tensor
    hand_left_map: torch.Tensor
    hand_right_map: torch.Tensor
    foot_left_map: torch.Tensor
    foot_right_map: torch.Tensor
    next_proprio: torch.Tensor
    dynamic_mu: torch.Tensor
    dynamic_logvar: torch.Tensor
    latent: torch.Tensor
    valid_mask: torch.Tensor
    next_hidden_state: torch.Tensor


@dataclass
class TransformerVisionTargets:
    """Simulator-only supervision that never enters the frozen actor."""

    velocity: torch.Tensor
    limb_heightmaps: torch.Tensor
    heightmap_valid: torch.Tensor
    heightmap_hit_class: torch.Tensor
    next_proprio: torch.Tensor
    future_valid: torch.Tensor | None = None


@dataclass(frozen=True)
class TransformerVisionLossWeights:
    velocity: float = 2.0
    hand: float = 2.0
    foot: float = 2.0
    future: float = 5.0
    kl: float = 1.0


def _elu_mlp(input_dim: int, hidden_dims: tuple[int, ...], output_dim: int) -> nn.Sequential:
    layers: list[nn.Module] = []
    previous_dim = input_dim
    for hidden_dim in hidden_dims:
        layers.extend((nn.Linear(previous_dim, hidden_dim), nn.ELU()))
        previous_dim = hidden_dim
    layers.append(nn.Linear(previous_dim, output_dim))
    return nn.Sequential(*layers)


class TransformerVisionEncoder(nn.Module):
    """The accepted 11-token Transformer and GRU visual estimator.

    This module has no action head. During visual pretraining its 51-D latent
    is deliberately not connected to the frozen nonvisual policy.
    """

    def __init__(self, proprio_dim: int = 85) -> None:
        super().__init__()
        self.proprio_dim = proprio_dim
        self.state_encoder = _elu_mlp(proprio_dim * _HISTORY_FRAMES, (256, 128), _TOKEN_DIM)
        self.depth_encoder = nn.Sequential(
            nn.Conv2d(_DEPTH_FRAMES, 16, kernel_size=5, stride=2, padding=2),
            nn.ELU(),
            nn.Conv2d(16, 32, kernel_size=3, stride=2, padding=1),
            nn.ELU(),
            nn.Conv2d(32, 64, kernel_size=3, stride=2, padding=1),
            nn.ELU(),
            nn.Conv2d(64, 128, kernel_size=3, stride=1, padding=1),
            nn.ELU(),
        )
        self.depth_pool = nn.AdaptiveAvgPool2d((2, 5))
        self.visual_token_encoder = nn.Sequential(nn.Linear(128, _TOKEN_DIM), nn.ELU())
        self.transformer = nn.Sequential(
            *[
                nn.TransformerEncoderLayer(
                    d_model=_TOKEN_DIM,
                    nhead=1,
                    dim_feedforward=256,
                    dropout=0.1,
                    batch_first=True,
                    norm_first=False,
                )
                for _ in range(2)
            ]
        )
        self.fusion = nn.Sequential(nn.Linear(11 * _TOKEN_DIM, _HIDDEN_DIM), nn.ELU())
        self.gru = nn.GRU(_HIDDEN_DIM, _HIDDEN_DIM, num_layers=1)

        self.velocity_head = nn.Linear(_HIDDEN_DIM, 3)
        self.hand_left_head = nn.Linear(_HIDDEN_DIM, 8)
        self.hand_right_head = nn.Linear(_HIDDEN_DIM, 8)
        self.foot_left_head = nn.Linear(_HIDDEN_DIM, 8)
        self.foot_right_head = nn.Linear(_HIDDEN_DIM, 8)
        self.dynamic_mu_head = nn.Linear(_HIDDEN_DIM, 16)
        self.dynamic_logvar_head = nn.Linear(_HIDDEN_DIM, 16)

        map_size = _MAP_SHAPE[0] * _MAP_SHAPE[1]
        self.hand_left_decoder = _elu_mlp(8, (64, 128), map_size)
        self.hand_right_decoder = _elu_mlp(8, (64, 128), map_size)
        self.foot_left_decoder = _elu_mlp(8, (64, 128), map_size)
        self.foot_right_decoder = _elu_mlp(8, (64, 128), map_size)
        # The current rslRL-317-rq-humanoid_ssr_pure implementation makes the
        # stochastic implicit latent solely responsible for future-state
        # reconstruction. This prevents deterministic explicit heads from
        # bypassing the dynamic latent while KL drives it toward the prior.
        self.future_decoder = _elu_mlp(16, (64, 128), proprio_dim)
        self.future_decoder_activation = nn.ELU()
        self.future_decoder_final = nn.Linear(proprio_dim, proprio_dim)

    def forward(
        self,
        proprio_history: torch.Tensor,
        depth_history: torch.Tensor,
        *,
        hidden_state: torch.Tensor | None = None,
        dones: torch.Tensor | None = None,
        masks: torch.Tensor | None = None,
        deterministic: bool = False,
        dynamic_noise: torch.Tensor | None = None,
    ) -> TransformerVisionOutput:
        leading_shape, depth_history = self._validate_inputs(proprio_history, depth_history)
        state_token, visual_tokens = self._tokens(proprio_history, depth_history, leading_shape)
        batch_size = int(torch.tensor(leading_shape).prod().item())
        tokens = torch.cat((state_token, visual_tokens), dim=-2)
        transformed = self.transformer(tokens.reshape(batch_size, 11, _TOKEN_DIM))
        fused = self.fusion(transformed.reshape(batch_size, -1)).reshape(*leading_shape, _HIDDEN_DIM)
        recurrent, next_hidden_state, valid_mask = self._run_gru(
            fused, leading_shape, hidden_state, dones, masks
        )

        velocity = self.velocity_head(recurrent)
        hand_left = self.hand_left_head(recurrent)
        hand_right = self.hand_right_head(recurrent)
        foot_left = self.foot_left_head(recurrent)
        foot_right = self.foot_right_head(recurrent)
        dynamic_mu = self.dynamic_mu_head(recurrent)
        dynamic_logvar = self.dynamic_logvar_head(recurrent)
        if deterministic:
            dynamic = dynamic_mu
        else:
            noise = torch.randn_like(dynamic_mu) if dynamic_noise is None else dynamic_noise
            if noise.shape != dynamic_mu.shape:
                raise ValueError(f"dynamic_noise must have shape {tuple(dynamic_mu.shape)}, got {tuple(noise.shape)}")
            dynamic = dynamic_mu + torch.exp(0.5 * dynamic_logvar) * noise
        latent = torch.cat((velocity, hand_left, hand_right, foot_left, foot_right, dynamic), dim=-1)
        return TransformerVisionOutput(
            velocity=velocity,
            hand_left_map=self.hand_left_decoder(hand_left).reshape(*leading_shape, *_MAP_SHAPE),
            hand_right_map=self.hand_right_decoder(hand_right).reshape(*leading_shape, *_MAP_SHAPE),
            foot_left_map=self.foot_left_decoder(foot_left).reshape(*leading_shape, *_MAP_SHAPE),
            foot_right_map=self.foot_right_decoder(foot_right).reshape(*leading_shape, *_MAP_SHAPE),
            next_proprio=self.future_decoder_final(
                self.future_decoder_activation(self.future_decoder(dynamic))
            ),
            dynamic_mu=dynamic_mu,
            dynamic_logvar=dynamic_logvar,
            latent=latent,
            valid_mask=valid_mask,
            next_hidden_state=next_hidden_state,
        )

    def losses(
        self,
        output: TransformerVisionOutput,
        targets: TransformerVisionTargets,
        weights: TransformerVisionLossWeights = TransformerVisionLossWeights(),
    ) -> dict[str, torch.Tensor]:
        expected_leading = output.velocity.shape[:-1]
        expected_maps = (*expected_leading, 4, *_MAP_SHAPE)
        if targets.velocity.shape != output.velocity.shape:
            raise ValueError("velocity target shape does not match the velocity estimate")
        if (
            targets.limb_heightmaps.shape != expected_maps
            or targets.heightmap_valid.shape != expected_maps
            or targets.heightmap_hit_class.shape != expected_maps
        ):
            raise ValueError(f"height-map targets must have shape {expected_maps}")
        if targets.next_proprio.shape != output.next_proprio.shape:
            raise ValueError("future proprio target shape does not match the prediction")

        valid = output.valid_mask.to(dtype=output.velocity.dtype)
        map_valid = targets.heightmap_valid.to(dtype=output.velocity.dtype) * valid[..., None, None, None]
        rung_mask = targets.heightmap_hit_class == RUNG
        map_weight = torch.where(rung_mask, 2.0, 1.0).to(dtype=output.velocity.dtype) * map_valid
        future_valid = valid if targets.future_valid is None else valid * targets.future_valid.to(valid.dtype)
        map_predictions = (output.hand_left_map, output.hand_right_map, output.foot_left_map, output.foot_right_map)
        map_losses = tuple(
            self.masked_mse(prediction, targets.limb_heightmaps[..., index, :, :], map_weight[..., index, :, :])
            for index, prediction in enumerate(map_predictions)
        )
        velocity = self.masked_mse(output.velocity, targets.velocity, valid)
        velocity_zero = self.masked_mse(torch.zeros_like(targets.velocity), targets.velocity, valid)
        velocity_skill = self.relative_skill(velocity, velocity_zero)
        velocity_axis = tuple(
            self.masked_mse(output.velocity[..., index], targets.velocity[..., index], valid)
            for index in range(3)
        )
        velocity_zero_axis = tuple(
            self.masked_mse(torch.zeros_like(targets.velocity[..., index]), targets.velocity[..., index], valid)
            for index in range(3)
        )
        velocity_skill_axis = tuple(
            self.relative_skill(model_error, zero_error)
            for model_error, zero_error in zip(velocity_axis, velocity_zero_axis, strict=True)
        )
        hand = 0.5 * (map_losses[0] + map_losses[1])
        foot = 0.5 * (map_losses[2] + map_losses[3])
        stacked_predictions = torch.stack(map_predictions, dim=-3)
        heightmap_rung = self.masked_mse(
            stacked_predictions,
            targets.limb_heightmaps,
            map_valid * rung_mask.to(dtype=map_valid.dtype),
        )
        heightmap_non_rung = self.masked_mse(
            stacked_predictions,
            targets.limb_heightmaps,
            map_valid * (~rung_mask).to(dtype=map_valid.dtype),
        )
        hand_rung = self.masked_mse(
            stacked_predictions[..., :2, :, :],
            targets.limb_heightmaps[..., :2, :, :],
            map_valid[..., :2, :, :] * rung_mask[..., :2, :, :].to(dtype=map_valid.dtype),
        )
        hand_non_rung = self.masked_mse(
            stacked_predictions[..., :2, :, :],
            targets.limb_heightmaps[..., :2, :, :],
            map_valid[..., :2, :, :] * (~rung_mask[..., :2, :, :]).to(dtype=map_valid.dtype),
        )
        foot_rung = self.masked_mse(
            stacked_predictions[..., 2:, :, :],
            targets.limb_heightmaps[..., 2:, :, :],
            map_valid[..., 2:, :, :] * rung_mask[..., 2:, :, :].to(dtype=map_valid.dtype),
        )
        foot_non_rung = self.masked_mse(
            stacked_predictions[..., 2:, :, :],
            targets.limb_heightmaps[..., 2:, :, :],
            map_valid[..., 2:, :, :] * (~rung_mask[..., 2:, :, :]).to(dtype=map_valid.dtype),
        )
        future = self.masked_mse(output.next_proprio, targets.next_proprio, future_valid)
        kl = self.masked_mean(
            -0.5 * torch.sum(1.0 + output.dynamic_logvar - output.dynamic_mu.square() - output.dynamic_logvar.exp(), dim=-1),
            valid,
        )
        total = weights.velocity * velocity + weights.hand * hand + weights.foot * foot + weights.future * future + weights.kl * kl
        return {
            "velocity": velocity,
            "velocity_zero_baseline": velocity_zero,
            "velocity_skill_score": velocity_skill,
            "velocity_x": velocity_axis[0],
            "velocity_y": velocity_axis[1],
            "velocity_z": velocity_axis[2],
            "velocity_zero_x": velocity_zero_axis[0],
            "velocity_zero_y": velocity_zero_axis[1],
            "velocity_zero_z": velocity_zero_axis[2],
            "velocity_skill_x": velocity_skill_axis[0],
            "velocity_skill_y": velocity_skill_axis[1],
            "velocity_skill_z": velocity_skill_axis[2],
            "hand_left": map_losses[0],
            "hand_right": map_losses[1],
            "foot_left": map_losses[2],
            "foot_right": map_losses[3],
            "hand": hand,
            "foot": foot,
            "heightmap_rung": heightmap_rung,
            "heightmap_non_rung": heightmap_non_rung,
            "hand_rung": hand_rung,
            "hand_non_rung": hand_non_rung,
            "foot_rung": foot_rung,
            "foot_non_rung": foot_non_rung,
            "future": future,
            "kl": kl,
            "total": total,
        }

    @staticmethod
    def masked_mse(prediction: torch.Tensor, target: torch.Tensor, valid: torch.Tensor) -> torch.Tensor:
        while valid.ndim < prediction.ndim:
            valid = valid.unsqueeze(-1)
        valid = valid.to(dtype=prediction.dtype)
        return ((prediction - target).square() * valid).sum() / valid.expand_as(prediction).sum().clamp_min(1.0)

    @staticmethod
    def masked_mean(value: torch.Tensor, valid: torch.Tensor) -> torch.Tensor:
        valid = valid.to(dtype=value.dtype)
        return (value * valid).sum() / valid.sum().clamp_min(1.0)

    @staticmethod
    def relative_skill(model_error: torch.Tensor, zero_baseline_error: torch.Tensor) -> torch.Tensor:
        """Return 1 - model MSE / zero-prediction MSE without dividing by zero."""

        return 1.0 - model_error / zero_baseline_error.clamp_min(1.0e-12)

    def _tokens(
        self, proprio_history: torch.Tensor, depth_history: torch.Tensor, leading_shape: tuple[int, ...]
    ) -> tuple[torch.Tensor, torch.Tensor]:
        batch_size = int(torch.tensor(leading_shape).prod().item())
        state = self.state_encoder(proprio_history.reshape(batch_size, -1)).reshape(*leading_shape, 1, _TOKEN_DIM)
        depth = self.depth_encoder(depth_history.reshape(batch_size, _DEPTH_FRAMES, _DEPTH_HEIGHT, _DEPTH_WIDTH))
        visual = self.visual_token_encoder(
            self.depth_pool(depth).permute(0, 2, 3, 1).reshape(batch_size, _VISUAL_TOKEN_COUNT, 128)
        ).reshape(*leading_shape, _VISUAL_TOKEN_COUNT, _TOKEN_DIM)
        return state, visual

    def _validate_inputs(
        self, proprio_history: torch.Tensor, depth_history: torch.Tensor
    ) -> tuple[tuple[int, ...], torch.Tensor]:
        if proprio_history.ndim not in (3, 4) or tuple(proprio_history.shape[-2:]) != (_HISTORY_FRAMES, self.proprio_dim):
            raise ValueError(
                f"proprio_history must have shape [B,10,{self.proprio_dim}] or [T,B,10,{self.proprio_dim}]"
            )
        leading_shape = tuple(proprio_history.shape[:-2])
        expected = (*leading_shape, _DEPTH_FRAMES, _DEPTH_HEIGHT, _DEPTH_WIDTH)
        singleton_channel = (*leading_shape, _DEPTH_FRAMES, 1, _DEPTH_HEIGHT, _DEPTH_WIDTH)
        if tuple(depth_history.shape) == singleton_channel:
            depth_history = depth_history.squeeze(-3)
        elif tuple(depth_history.shape) != expected:
            raise ValueError(f"depth_history must have shape {expected} or {singleton_channel}")
        return leading_shape, depth_history

    def _run_gru(
        self,
        fused: torch.Tensor,
        leading_shape: tuple[int, ...],
        hidden_state: torch.Tensor | None,
        dones: torch.Tensor | None,
        masks: torch.Tensor | None,
    ) -> tuple[torch.Tensor, torch.Tensor, torch.Tensor]:
        if len(leading_shape) == 1:
            batch_size = leading_shape[0]
            valid = self._optional_mask(masks, (batch_size,), fused.device, True)
            done = self._optional_mask(dones, (batch_size,), fused.device, False)
            hidden = self._prepare_hidden(hidden_state, batch_size, fused)
            hidden = self.reset_hidden_state(hidden, done & valid)
            recurrent, candidate = self.gru(fused.unsqueeze(0), hidden)
            return recurrent.squeeze(0), torch.where(valid[None, :, None], candidate, hidden), valid

        steps, batch_size = leading_shape
        valid = self._optional_mask(masks, (steps, batch_size), fused.device, True)
        done = self._optional_mask(dones, (steps, batch_size), fused.device, False)
        hidden = self._prepare_hidden(hidden_state, batch_size, fused)
        outputs = []
        for step in range(steps):
            active = valid[step]
            hidden = self.reset_hidden_state(hidden, done[step] & active)
            recurrent, candidate = self.gru(fused[step].unsqueeze(0), hidden)
            hidden = torch.where(active[None, :, None], candidate, hidden)
            outputs.append(recurrent.squeeze(0))
        return torch.stack(outputs), hidden, valid

    @staticmethod
    def reset_hidden_state(hidden_state: torch.Tensor, dones: torch.Tensor) -> torch.Tensor:
        if tuple(hidden_state.shape[:1]) != (1,) or hidden_state.shape[-1] != _HIDDEN_DIM:
            raise ValueError(f"hidden_state must have shape [1,B,{_HIDDEN_DIM}]")
        return hidden_state * (~dones.to(dtype=torch.bool))[None, :, None].to(hidden_state.dtype)

    @staticmethod
    def _optional_mask(value: torch.Tensor | None, shape: tuple[int, ...], device: torch.device, default: bool) -> torch.Tensor:
        if value is None:
            return torch.full(shape, default, dtype=torch.bool, device=device)
        if tuple(value.shape) != shape:
            raise ValueError(f"mask must have shape {shape}, got {tuple(value.shape)}")
        return value.to(device=device, dtype=torch.bool)

    @staticmethod
    def _prepare_hidden(hidden: torch.Tensor | None, batch_size: int, features: torch.Tensor) -> torch.Tensor:
        if hidden is None:
            return torch.zeros((1, batch_size, _HIDDEN_DIM), device=features.device, dtype=features.dtype)
        if tuple(hidden.shape) != (1, batch_size, _HIDDEN_DIM):
            raise ValueError(f"hidden_state must have shape {(1, batch_size, _HIDDEN_DIM)}")
        return hidden
