from __future__ import annotations

import math
import os
from collections.abc import Sequence
from dataclasses import MISSING
from typing import TYPE_CHECKING

import numpy as np
import torch
import isaaclab.sim as sim_utils
from isaaclab.assets import Articulation, RigidObjectCollection
from isaaclab.managers import CommandTerm, CommandTermCfg
from isaaclab.markers import VisualizationMarkers, VisualizationMarkersCfg
from isaaclab.markers.config import FRAME_MARKER_CFG
from isaaclab.utils import configclass
from isaaclab.utils.math import (
    quat_apply,
    quat_error_magnitude,
    quat_from_euler_xyz,
    quat_inv,
    quat_mul,
    sample_uniform,
    yaw_quat,
)

from ladder.tasks.ladder_climb.ladder_geometry import (
    LADDER_A,
    LadderGeometry,
    limb_lateral_offsets_tensor,
)
from ladder.utils.contact_force import (
    filtered_surface_force_max,
    non_target_rung_forces,
    target_rung_forces,
)
from ladder.utils.contact_metrics import classify_limb_contacts
from ladder.utils.contact_schema import DEFAULT_LIMB_BODY_NAMES, LIMB_NAMES
from ladder.utils.motion_reset import (
    load_reset_valid_mask,
    mix_nominal_ladder_geometry_samples,
    mix_reset_frame_samples,
    pose_range_bounds,
    select_geometry_cell_reset_masks,
)

if TYPE_CHECKING:
    from isaaclab.envs import ManagerBasedRLEnv


_REFERENCE_PROGRESS_DISTANCE_THRESHOLD = 0.05
_REFERENCE_MOVING_SPEED_THRESHOLD = 0.05
_ROBOT_STATIONARY_SPEED_THRESHOLD = 0.03


class LadderMotionLoader:
    """Load LadderMan motion-tracking references with contact annotations."""

    def __init__(
        self,
        motion_file: str,
        joint_names: Sequence[str],
        body_names: Sequence[str],
        device: str = "cpu",
    ):
        if not os.path.isfile(motion_file):
            raise FileNotFoundError(
                f"Invalid motion file path: {motion_file}. "
                "Provide a LadderMan climbing motion npz before creating the environment."
            )
        data = np.load(motion_file)
        required_keys = (
            "fps",
            "joint_pos",
            "joint_vel",
            "body_pos_w",
            "body_quat_w",
            "body_lin_vel_w",
            "body_ang_vel_w",
            "contact_indicator",
            "contact_rung_id",
            "joint_names",
            "body_names",
        )
        missing_keys = [key for key in required_keys if key not in data.files]
        if missing_keys:
            raise KeyError(
                f"Ladder climbing motion file '{motion_file}' is missing {missing_keys}. "
                "Expected the whole-body tracking motion keys plus contact_indicator/contact_rung_id."
            )

        motion_joint_names = [str(name) for name in data["joint_names"].tolist()]
        motion_body_names = [str(name) for name in data["body_names"].tolist()]
        missing_joints = [name for name in joint_names if name not in motion_joint_names]
        missing_bodies = [name for name in body_names if name not in motion_body_names]
        if missing_joints or missing_bodies:
            raise ValueError(
                f"motion is missing robot joints {missing_joints} or tracking bodies {missing_bodies}"
            )
        joint_indexes = [motion_joint_names.index(name) for name in joint_names]
        body_indexes = [motion_body_names.index(name) for name in body_names]

        self.fps = float(np.asarray(data["fps"]).reshape(-1)[0])
        self.joint_pos = torch.tensor(data["joint_pos"][:, joint_indexes], dtype=torch.float32, device=device)
        self.joint_vel = torch.tensor(data["joint_vel"][:, joint_indexes], dtype=torch.float32, device=device)
        self._body_pos_w = torch.tensor(data["body_pos_w"], dtype=torch.float32, device=device)
        self._body_quat_w = torch.tensor(data["body_quat_w"], dtype=torch.float32, device=device)
        self._body_lin_vel_w = torch.tensor(data["body_lin_vel_w"], dtype=torch.float32, device=device)
        self._body_ang_vel_w = torch.tensor(data["body_ang_vel_w"], dtype=torch.float32, device=device)
        self.contact_indicator = torch.tensor(data["contact_indicator"], dtype=torch.float32, device=device)
        self.contact_rung_id = torch.tensor(data["contact_rung_id"], dtype=torch.long, device=device)
        self.ladder_params = (
            np.asarray(data["contact_annotation_ladder_params"], dtype=np.float32)
            if "contact_annotation_ladder_params" in data.files
            else None
        )
        self.ladder_origin = (
            np.asarray(data["contact_annotation_ladder_origin"], dtype=np.float32)
            if "contact_annotation_ladder_origin" in data.files
            else None
        )
        self.ladder_num_rungs = (
            int(np.asarray(data["contact_annotation_ladder_num_rungs"]).reshape(-1)[0])
            if "contact_annotation_ladder_num_rungs" in data.files
            else None
        )
        self.geometry_grid_inclination_deltas = (
            np.asarray(data["reset_ladder_geometry_grid_inclination_deltas"], dtype=np.float32)
            if "reset_ladder_geometry_grid_inclination_deltas" in data.files
            else None
        )
        self.geometry_grid_spacing_deltas = (
            np.asarray(data["reset_ladder_geometry_grid_spacing_deltas"], dtype=np.float32)
            if "reset_ladder_geometry_grid_spacing_deltas" in data.files
            else None
        )
        self.geometry_cell_reset_valid_masks = (
            np.asarray(data["reset_ladder_geometry_cell_valid_mask"], dtype=np.bool_)
            if "reset_ladder_geometry_cell_valid_mask" in data.files
            else None
        )
        self._body_indexes = body_indexes
        self.time_step_total = self.joint_pos.shape[0]

        reset_valid_mask, self.has_reset_valid_mask = load_reset_valid_mask(
            data, self.time_step_total
        )
        self.reset_valid_mask = torch.tensor(reset_valid_mask, dtype=torch.bool, device=device)
        self.reset_valid_frame_indexes = torch.nonzero(
            self.reset_valid_mask, as_tuple=False
        ).squeeze(-1)
        self.using_geometry_conditioned_reset_masks = False

        if self.contact_indicator.shape != self.contact_rung_id.shape:
            raise ValueError("contact_indicator and contact_rung_id must have identical shapes.")
        if self.contact_indicator.shape[0] != self.time_step_total:
            raise ValueError("contact annotations must have one row per motion frame.")
        if self.contact_indicator.shape[1] != len(LIMB_NAMES):
            raise ValueError(f"expected {len(LIMB_NAMES)} contact limbs, got {self.contact_indicator.shape[1]}")

    def use_geometry_conditioned_reset_masks(
        self,
        inclination_delta_range: tuple[float, float],
        spacing_delta_range: tuple[float, float],
    ) -> None:
        """Load per-cell reset masks covering the requested ladder randomization envelope."""

        if (
            self.geometry_grid_inclination_deltas is None
            or self.geometry_grid_spacing_deltas is None
            or self.geometry_cell_reset_valid_masks is None
        ):
            raise ValueError(
                "ladder geometry randomization requires geometry-grid axes and "
                "reset_ladder_geometry_cell_valid_mask in the motion file"
            )
        inclination_grid = self.geometry_grid_inclination_deltas.reshape(-1)
        spacing_grid = self.geometry_grid_spacing_deltas.reshape(-1)
        if inclination_grid.size < 2 or spacing_grid.size < 2:
            raise ValueError("ladder geometry reset grids must each contain at least two values")
        if not np.all(np.diff(inclination_grid) > 0.0) or not np.all(np.diff(spacing_grid) > 0.0):
            raise ValueError("ladder geometry reset grid axes must be strictly increasing")
        expected_shape = (inclination_grid.size - 1, spacing_grid.size - 1, self.time_step_total)
        if self.geometry_cell_reset_valid_masks.shape != expected_shape:
            raise ValueError(
                f"reset_ladder_geometry_cell_valid_mask must have shape {expected_shape}, "
                f"got {self.geometry_cell_reset_valid_masks.shape}"
            )
        requested_inclination = np.asarray(inclination_delta_range, dtype=np.float32)
        requested_spacing = np.asarray(spacing_delta_range, dtype=np.float32)
        tolerance = 1.0e-6
        if (
            requested_inclination[0] < inclination_grid[0] - tolerance
            or requested_inclination[1] > inclination_grid[-1] + tolerance
            or requested_spacing[0] < spacing_grid[0] - tolerance
            or requested_spacing[1] > spacing_grid[-1] + tolerance
        ):
            raise ValueError(
                "motion reset geometry grid does not cover requested ladder randomization: "
                f"requested inclination={requested_inclination.tolist()}, spacing={requested_spacing.tolist()}, "
                f"available inclination={[float(inclination_grid[0]), float(inclination_grid[-1])]}, "
                f"spacing={[float(spacing_grid[0]), float(spacing_grid[-1])]}"
            )
        cell_masks = torch.tensor(
            self.geometry_cell_reset_valid_masks, dtype=torch.bool, device=self.joint_pos.device
        )
        if torch.any(~torch.any(cell_masks, dim=-1)):
            raise ValueError("at least one ladder geometry grid cell excludes every reference frame")
        self._geometry_grid_inclination_deltas = torch.tensor(
            inclination_grid, dtype=torch.float32, device=self.joint_pos.device
        )
        self._geometry_grid_spacing_deltas = torch.tensor(
            spacing_grid, dtype=torch.float32, device=self.joint_pos.device
        )
        self._geometry_cell_reset_valid_masks = cell_masks
        union_mask = torch.any(cell_masks, dim=(0, 1))
        self.reset_valid_mask = union_mask
        self.reset_valid_frame_indexes = torch.nonzero(union_mask, as_tuple=False).squeeze(-1)
        self.using_geometry_conditioned_reset_masks = True

    def geometry_reset_valid_masks(
        self, inclination_deltas: torch.Tensor, spacing_deltas: torch.Tensor
    ) -> torch.Tensor:
        if not self.using_geometry_conditioned_reset_masks:
            return self.reset_valid_mask.unsqueeze(0).expand(len(inclination_deltas), -1)
        return select_geometry_cell_reset_masks(
            self._geometry_cell_reset_valid_masks,
            self._geometry_grid_inclination_deltas,
            self._geometry_grid_spacing_deltas,
            inclination_deltas,
            spacing_deltas,
        )

    @property
    def body_pos_w(self) -> torch.Tensor:
        return self._body_pos_w[:, self._body_indexes]

    @property
    def body_quat_w(self) -> torch.Tensor:
        return self._body_quat_w[:, self._body_indexes]

    @property
    def body_lin_vel_w(self) -> torch.Tensor:
        return self._body_lin_vel_w[:, self._body_indexes]

    @property
    def body_ang_vel_w(self) -> torch.Tensor:
        return self._body_ang_vel_w[:, self._body_indexes]


class LadderMotionCommand(CommandTerm):
    cfg: LadderMotionCommandCfg

    def __init__(self, cfg: LadderMotionCommandCfg, env: ManagerBasedRLEnv):
        super().__init__(cfg, env)

        self.robot: Articulation = env.scene[cfg.asset_name]
        self.robot_anchor_body_index = self.robot.body_names.index(self.cfg.anchor_body_name)
        self.motion_anchor_body_index = self.cfg.body_names.index(self.cfg.anchor_body_name)
        self.body_indexes = torch.tensor(
            self.robot.find_bodies(self.cfg.body_names, preserve_order=True)[0],
            dtype=torch.long,
            device=self.device,
        )
        self.motion = LadderMotionLoader(
            self.cfg.motion_file, self.robot.joint_names, self.cfg.body_names, device=self.device
        )
        control_fps = 1.0 / (env.cfg.decimation * env.cfg.sim.dt)
        if not math.isclose(self.motion.fps, control_fps, rel_tol=0.0, abs_tol=1.0e-4):
            raise ValueError(
                f"motion fps ({self.motion.fps:g}) must match environment control fps ({control_fps:g}); "
                "resample the reference motion before training"
            )
        self.ladder_geometry = cfg.ladder_geometry
        self._validate_ladder_metadata()
        inclination_range = tuple(self.cfg.ladder_inclination_delta_range)
        spacing_range = tuple(self.cfg.ladder_spacing_delta_range)
        if inclination_range[0] > inclination_range[1]:
            raise ValueError(f"invalid ladder_inclination_delta_range: {inclination_range}")
        if spacing_range[0] > spacing_range[1]:
            raise ValueError(f"invalid ladder_spacing_delta_range: {spacing_range}")
        if not 0.0 <= self.cfg.nominal_ladder_geometry_probability <= 1.0:
            raise ValueError(
                "nominal_ladder_geometry_probability must be in [0, 1], got "
                f"{self.cfg.nominal_ladder_geometry_probability}"
            )
        if self.ladder_geometry.rung_spacing + spacing_range[0] <= 0.0:
            raise ValueError("ladder spacing randomization must remain positive")
        if not (
            0.0 < self.ladder_geometry.phi + inclination_range[0]
            and self.ladder_geometry.phi + inclination_range[1] < math.pi / 2.0
        ):
            raise ValueError("ladder inclination randomization must remain between 0 and 90 degrees")
        self._geometry_randomization_enabled = (
            inclination_range != (0.0, 0.0) or spacing_range != (0.0, 0.0)
        )
        if (
            self._geometry_randomization_enabled
            and self.cfg.use_geometry_conditioned_reset_masks
        ):
            self.motion.use_geometry_conditioned_reset_masks(inclination_range, spacing_range)
        if self.cfg.fixed_reference_frame is not None and not (
            0 <= self.cfg.fixed_reference_frame < self.motion.time_step_total
        ):
            raise ValueError(
                f"fixed_reference_frame must be in [0, {self.motion.time_step_total}), "
                f"got {self.cfg.fixed_reference_frame}"
            )
        if not 0.0 <= self.cfg.fixed_start_probability <= 1.0:
            raise ValueError(
                f"fixed_start_probability must be in [0, 1], got {self.cfg.fixed_start_probability}"
            )
        if not 0.0 <= self.cfg.uniform_start_probability <= 1.0:
            raise ValueError(
                f"uniform_start_probability must be in [0, 1], got {self.cfg.uniform_start_probability}"
            )
        if self.cfg.fixed_start_probability + self.cfg.uniform_start_probability > 1.0:
            raise ValueError(
                "fixed_start_probability + uniform_start_probability must be at most 1, got "
                f"{self.cfg.fixed_start_probability + self.cfg.uniform_start_probability}"
            )
        if not 0 <= self.cfg.fixed_start_frame < self.motion.time_step_total:
            raise ValueError(
                f"fixed_start_frame must be in [0, {self.motion.time_step_total}), "
                f"got {self.cfg.fixed_start_frame}"
            )
        if self.cfg.fixed_start_probability > 0.0 and not self.motion.reset_valid_mask[
            self.cfg.fixed_start_frame
        ].item():
            raise ValueError(
                f"fixed_start_frame {self.cfg.fixed_start_frame} is excluded by reset_valid_mask"
            )
        if (
            self.cfg.fixed_start_probability > 0.0
            and self.motion.using_geometry_conditioned_reset_masks
            and not torch.all(
                self.motion._geometry_cell_reset_valid_masks[..., self.cfg.fixed_start_frame]
            )
        ):
            raise ValueError(
                f"fixed_start_frame {self.cfg.fixed_start_frame} is not valid in every ladder geometry cell"
            )
        nonfixed_mask = self.motion.reset_valid_frame_indexes != self.cfg.fixed_start_frame
        self.nonfixed_reset_valid_frame_indexes = self.motion.reset_valid_frame_indexes[nonfixed_mask]
        nonfixed_probability = 1.0 - self.cfg.fixed_start_probability
        if nonfixed_probability > 0.0 and len(self.nonfixed_reset_valid_frame_indexes) == 0:
            raise ValueError(
                "fixed/uniform/adaptive reset mixing requires at least one non-fixed valid reset frame"
            )

        self.time_steps = torch.zeros(self.num_envs, dtype=torch.long, device=self.device)
        self._episode_start_time_steps = torch.zeros(self.num_envs, dtype=torch.long, device=self.device)
        self._fixed_start_episode = torch.zeros(self.num_envs, dtype=torch.bool, device=self.device)
        self._fixed_start_pose_randomized_episode = torch.zeros(
            self.num_envs, dtype=torch.bool, device=self.device
        )
        self._uniform_start_episode = torch.zeros(self.num_envs, dtype=torch.bool, device=self.device)
        self._current_reset_valid_fraction = torch.ones(self.num_envs, device=self.device)
        self._tracking_path_initialized = torch.zeros(self.num_envs, dtype=torch.bool, device=self.device)
        self._tracking_start_reference_anchor_pos_w = torch.zeros(self.num_envs, 3, device=self.device)
        self._tracking_start_robot_anchor_pos_w = torch.zeros(self.num_envs, 3, device=self.device)
        self._tracking_previous_reference_anchor_pos_w = torch.zeros(self.num_envs, 3, device=self.device)
        self._tracking_previous_robot_anchor_pos_w = torch.zeros(self.num_envs, 3, device=self.device)
        self._tracking_episode_steps = torch.zeros(self.num_envs, device=self.device)
        self._tracking_reference_motion_steps = torch.zeros(self.num_envs, device=self.device)
        self._tracking_stationary_motion_steps = torch.zeros(self.num_envs, device=self.device)
        self.body_pos_relative_w = torch.zeros(self.num_envs, len(cfg.body_names), 3, device=self.device)
        self.body_quat_relative_w = torch.zeros(self.num_envs, len(cfg.body_names), 4, device=self.device)
        self.body_quat_relative_w[:, :, 0] = 1.0

        self.bin_count = int(self.motion.time_step_total // (1 / (env.cfg.decimation * env.cfg.sim.dt))) + 1
        self.bin_failed_count = torch.zeros(self.bin_count, dtype=torch.float, device=self.device)
        self._current_bin_failed = torch.zeros(self.bin_count, dtype=torch.float, device=self.device)
        self.kernel = torch.tensor([self.cfg.adaptive_lambda**i for i in range(self.cfg.adaptive_kernel_size)], device=self.device)
        self.kernel = self.kernel / self.kernel.sum()

        if self.motion.using_geometry_conditioned_reset_masks:
            reset_mask_source = "embedded geometry-conditioned reset masks"
        else:
            reset_mask_source = "embedded reset_valid_mask" if self.motion.has_reset_valid_mask else "all frames"
        print(
            f"[INFO] Ladder reset frames: {len(self.motion.reset_valid_frame_indexes)}/"
            f"{self.motion.time_step_total} valid ({reset_mask_source})."
        )
        if (
            self._geometry_randomization_enabled
            and not self.cfg.use_geometry_conditioned_reset_masks
        ):
            print(
                "[WARNING] Randomized ladder geometry is using the nominal-ladder reset mask; "
                "some reset states may initially penetrate the sampled ladder."
            )

        self.limb_names = tuple(cfg.limb_names)
        self.limb_body_names = [cfg.limb_body_names[name] for name in self.limb_names]
        self.limb_body_indexes = torch.tensor(
            self.robot.find_bodies(self.limb_body_names, preserve_order=True)[0], dtype=torch.long, device=self.device
        )
        if self.cfg.contact_sensor_name not in env.scene.sensors:
            raise ValueError(
                f"contact sensor {self.cfg.contact_sensor_name!r} is not present in the scene; "
                "required for physical contact metrics"
            )
        self._contact_sensor = env.scene.sensors[self.cfg.contact_sensor_name]
        contact_body_indexes, contact_body_names = self._contact_sensor.find_bodies(
            self.limb_body_names, preserve_order=True
        )
        if contact_body_names != self.limb_body_names:
            raise ValueError(
                "contact sensor must expose one body per configured limb in order; "
                f"requested={self.limb_body_names}, resolved={contact_body_names}"
            )
        self._contact_limb_body_indexes = torch.tensor(
            contact_body_indexes, dtype=torch.long, device=self.device
        )
        if self.cfg.limb_target_distance_thresholds is None:
            target_distance_thresholds = [0.10] * len(self.limb_names)
        else:
            missing_thresholds = [
                name for name in self.limb_names if name not in self.cfg.limb_target_distance_thresholds
            ]
            if missing_thresholds:
                raise ValueError(
                    f"limb_target_distance_thresholds is missing limbs: {missing_thresholds}"
                )
            target_distance_thresholds = [
                self.cfg.limb_target_distance_thresholds[name] for name in self.limb_names
            ]
        self._limb_target_distance_thresholds = torch.tensor(
            target_distance_thresholds, dtype=torch.float32, device=self.device
        )
        if torch.any(self._limb_target_distance_thresholds <= 0.0):
            raise ValueError("limb target distance thresholds must be positive")
        if self.cfg.contact_force_threshold < 0.0:
            raise ValueError(
                f"contact_force_threshold must be nonnegative, got {self.cfg.contact_force_threshold}"
            )
        if cfg.limb_target_offsets is None:
            self._limb_offsets = limb_lateral_offsets_tensor(
                self.ladder_geometry, self.limb_names, device=self.device
            )
        else:
            missing_offsets = [name for name in self.limb_names if name not in cfg.limb_target_offsets]
            if missing_offsets:
                raise ValueError(f"limb_target_offsets is missing limbs: {missing_offsets}")
            self._limb_offsets = torch.tensor(
                [cfg.limb_target_offsets[name] for name in self.limb_names],
                dtype=torch.float32,
                device=self.device,
            )

        self.ladder_phi = torch.full(
            (self.num_envs,), self.ladder_geometry.phi, dtype=torch.float32, device=self.device
        )
        self.ladder_spacing = torch.full(
            (self.num_envs,), self.ladder_geometry.rung_spacing, dtype=torch.float32, device=self.device
        )
        self._nominal_ladder_geometry_episode = torch.zeros(
            self.num_envs, dtype=torch.bool, device=self.device
        )
        self._ladder_origin_e = torch.tensor(
            self.ladder_geometry.origin, dtype=torch.float32, device=self.device
        )
        self._ladder_delta_quat = torch.zeros(self.num_envs, 4, dtype=torch.float32, device=self.device)
        self._ladder_delta_quat[:, 0] = 1.0
        self._ladder_asset: RigidObjectCollection | None = None
        if self.cfg.ladder_asset_name is not None:
            ladder_asset = self._env.scene[self.cfg.ladder_asset_name]
            if not isinstance(ladder_asset, RigidObjectCollection):
                raise TypeError(
                    f"scene asset {self.cfg.ladder_asset_name!r} must be a RigidObjectCollection"
                )
            self._ladder_asset = ladder_asset
            object_names = tuple(ladder_asset.object_names)
            configured_names = set(self.cfg.ladder_fixed_box_names) | set(
                self.cfg.ladder_rung_box_names
            ) | set(
                self.cfg.ladder_inclined_box_names
            )
            missing_names = sorted(configured_names - set(object_names))
            if missing_names:
                raise ValueError(f"ladder collection is missing configured boxes: {missing_names}")
            default_state = ladder_asset.data.default_object_state[0]
            self._ladder_box_positions_e = default_state[:, :3].clone()
            self._ladder_box_quats = default_state[:, 3:7].clone()
            self._ladder_fixed_box_mask = torch.tensor(
                [name in self.cfg.ladder_fixed_box_names for name in object_names],
                dtype=torch.bool,
                device=self.device,
            )
            self._ladder_inclined_box_mask = torch.tensor(
                [name in self.cfg.ladder_inclined_box_names for name in object_names],
                dtype=torch.bool,
                device=self.device,
            )
            object_name_to_index = {name: index for index, name in enumerate(object_names)}
            self._ladder_rung_box_indexes = torch.tensor(
                [object_name_to_index[name] for name in self.cfg.ladder_rung_box_names],
                dtype=torch.long,
                device=self.device,
            )
            rung_indexes = torch.arange(
                len(self.cfg.ladder_rung_box_names), dtype=torch.float32, device=self.device
            ).unsqueeze(-1)
            source_direction = torch.tensor(
                self.ladder_geometry.climb_direction, dtype=torch.float32, device=self.device
            )
            nominal_rung_tops = (
                self._ladder_origin_e.unsqueeze(0)
                + rung_indexes * self.ladder_geometry.rung_spacing * source_direction.unsqueeze(0)
            )
            self._ladder_rung_center_offsets_e = (
                self._ladder_box_positions_e[self._ladder_rung_box_indexes] - nominal_rung_tops
            )
            relative = self._ladder_box_positions_e - self._ladder_origin_e
            source_cos = math.cos(self.ladder_geometry.phi)
            source_sin = math.sin(self.ladder_geometry.phi)
            self._ladder_box_axial = relative[:, 0] * source_cos + relative[:, 2] * source_sin
            self._ladder_box_normal = -relative[:, 0] * source_sin + relative[:, 2] * source_cos
        elif self._geometry_randomization_enabled:
            raise ValueError("ladder geometry randomization requires ladder_asset_name")

        self.metrics["error_anchor_pos"] = torch.zeros(self.num_envs, device=self.device)
        self.metrics["error_anchor_rot"] = torch.zeros(self.num_envs, device=self.device)
        self.metrics["error_anchor_lin_vel"] = torch.zeros(self.num_envs, device=self.device)
        self.metrics["error_anchor_ang_vel"] = torch.zeros(self.num_envs, device=self.device)
        self.metrics["error_body_pos"] = torch.zeros(self.num_envs, device=self.device)
        self.metrics["error_body_rot"] = torch.zeros(self.num_envs, device=self.device)
        self.metrics["error_body_lin_vel"] = torch.zeros(self.num_envs, device=self.device)
        self.metrics["error_body_ang_vel"] = torch.zeros(self.num_envs, device=self.device)
        self.metrics["error_joint_pos"] = torch.zeros(self.num_envs, device=self.device)
        self.metrics["error_joint_vel"] = torch.zeros(self.num_envs, device=self.device)
        self.metrics["reference_anchor_speed"] = torch.zeros(self.num_envs, device=self.device)
        self.metrics["robot_anchor_speed"] = torch.zeros(self.num_envs, device=self.device)
        self.metrics["reference_joint_speed"] = torch.zeros(self.num_envs, device=self.device)
        self.metrics["robot_joint_speed"] = torch.zeros(self.num_envs, device=self.device)
        self.metrics["reference_anchor_path_length"] = torch.zeros(self.num_envs, device=self.device)
        self.metrics["robot_anchor_path_length"] = torch.zeros(self.num_envs, device=self.device)
        self.metrics["reference_anchor_displacement"] = torch.zeros(self.num_envs, device=self.device)
        self.metrics["robot_anchor_displacement"] = torch.zeros(self.num_envs, device=self.device)
        self.metrics["anchor_progress_ratio"] = torch.zeros(self.num_envs, device=self.device)
        self.metrics["progress_evaluable"] = torch.zeros(self.num_envs, device=self.device)
        self.metrics["reference_completion_fraction"] = torch.zeros(self.num_envs, device=self.device)
        self.metrics["reference_moving_fraction"] = torch.zeros(self.num_envs, device=self.device)
        self.metrics["stationary_during_reference_motion_fraction"] = torch.zeros(
            self.num_envs, device=self.device
        )
        self.metrics["sampling_entropy"] = torch.zeros(self.num_envs, device=self.device)
        self.metrics["sampling_top1_prob"] = torch.zeros(self.num_envs, device=self.device)
        self.metrics["sampling_top1_bin"] = torch.zeros(self.num_envs, device=self.device)
        self.metrics["adaptive_sampling_top1_prob"] = torch.zeros(self.num_envs, device=self.device)
        self.metrics["adaptive_sampling_top1_bin"] = torch.zeros(self.num_envs, device=self.device)
        self.metrics["ladder_inclination_deg"] = torch.full(
            (self.num_envs,), math.degrees(self.ladder_geometry.phi), device=self.device
        )
        self.metrics["ladder_rung_spacing"] = torch.full(
            (self.num_envs,), self.ladder_geometry.rung_spacing, device=self.device
        )
        self.metrics["nominal_ladder_geometry_episode"] = torch.zeros(
            self.num_envs, device=self.device
        )
        self.metrics["reset_valid_fraction"] = torch.full(
            (self.num_envs,),
            len(self.motion.reset_valid_frame_indexes) / self.motion.time_step_total,
            device=self.device,
        )
        self.metrics["mean_required_contact_error"] = torch.zeros(self.num_envs, device=self.device)
        self.metrics["required_contact_fraction"] = torch.zeros(self.num_envs, device=self.device)
        self.metrics["required_physical_contact_fraction"] = torch.zeros(
            self.num_envs, device=self.device
        )
        self.metrics["required_target_contact_fraction"] = torch.zeros(
            self.num_envs, device=self.device
        )
        self.metrics["swing_physical_contact_fraction"] = torch.zeros(
            self.num_envs, device=self.device
        )
        for limb_name in self.limb_names:
            self.metrics[f"{limb_name}_physical_contact"] = torch.zeros(
                self.num_envs, device=self.device
            )
            self.metrics[f"{limb_name}_required_physical_contact"] = torch.zeros(
                self.num_envs, device=self.device
            )
            self.metrics[f"{limb_name}_required_target_contact"] = torch.zeros(
                self.num_envs, device=self.device
            )
        for hand_name in ("left_hand", "right_hand"):
            self.metrics[f"{hand_name}_required_contact_error"] = torch.zeros(
                self.num_envs, device=self.device
            )
            self.metrics[f"{hand_name}_contact_required"] = torch.zeros(
                self.num_envs, device=self.device
            )
        self.metrics["fixed_start_episode"] = torch.zeros(self.num_envs, device=self.device)
        self.metrics["fixed_start_pose_randomized_episode"] = torch.zeros(
            self.num_envs, device=self.device
        )
        self.metrics["fixed_start_pose_nominal_episode"] = torch.zeros(
            self.num_envs, device=self.device
        )
        self.metrics["uniform_start_episode"] = torch.zeros(self.num_envs, device=self.device)
        self.metrics["adaptive_start_episode"] = torch.zeros(self.num_envs, device=self.device)
        self._contact_force_metric_specs: dict[str, tuple[object, str]] = {}
        for side in ("left", "right"):
            step_sensor_name = f"{side}_hand_step_contacts"
            if step_sensor_name in env.scene.sensors:
                step_sensor = env.scene.sensors[step_sensor_name]
                for surface in ("top", "front", "underside"):
                    metric_name = f"{side}_hand_{surface}_force_max"
                    self._contact_force_metric_specs[metric_name] = (step_sensor, surface)
                    self.metrics[metric_name] = torch.zeros(self.num_envs, device=self.device)
                self.metrics[f"{side}_hand_wrong_rung_force_max"] = torch.zeros(
                    self.num_envs, device=self.device
                )
                target_metric_name = f"{side}_hand_target_rung_upward_force_max"
                self.metrics[target_metric_name] = torch.zeros(self.num_envs, device=self.device)
            for surface_name, sensor_name in (
                ("side_board", f"{side}_hand_side_board_contacts"),
                ("ground", f"{side}_hand_ground_contacts"),
            ):
                if sensor_name in env.scene.sensors:
                    metric_name = f"{side}_hand_{surface_name}_force_max"
                    self._contact_force_metric_specs[metric_name] = (
                        env.scene.sensors[sensor_name],
                        "all",
                    )
                    self.metrics[metric_name] = torch.zeros(self.num_envs, device=self.device)
            foot_sensor_name = f"{side}_foot_step_contacts"
            if foot_sensor_name in env.scene.sensors:
                foot_sensor = env.scene.sensors[foot_sensor_name]
                metric_name = f"{side}_foot_step_force_max"
                self._contact_force_metric_specs[metric_name] = (foot_sensor, "all")
                self.metrics[metric_name] = torch.zeros(self.num_envs, device=self.device)
                target_metric_name = f"{side}_foot_target_rung_force_max"
                self.metrics[target_metric_name] = torch.zeros(self.num_envs, device=self.device)
        self._contact_force_soft_limits = dict(self.cfg.contact_force_soft_limits)
        self._contact_force_hard_limits = dict(self.cfg.contact_force_hard_limits)
        if self._contact_force_soft_limits.keys() != self._contact_force_hard_limits.keys():
            raise ValueError("contact force soft/hard limit keys must match")
        for name, force_soft in self._contact_force_soft_limits.items():
            force_hard = self._contact_force_hard_limits[name]
            if force_soft < 0.0 or force_hard <= force_soft:
                raise ValueError(
                    f"contact force limit {name!r} must satisfy 0 <= soft < hard, "
                    f"got soft={force_soft}, hard={force_hard}"
                )
        self._force_limit_sample_count: dict[str, torch.Tensor] = {}
        self._force_limit_over_soft_count: dict[str, torch.Tensor] = {}
        self._force_limit_previous_hard: dict[str, torch.Tensor] = {}
        self._force_histogram_bin_count = 64
        self._force_histogram_max = {
            "left_hand": 2000.0,
            "right_hand": 2000.0,
            "left_foot": 5000.0,
            "right_foot": 5000.0,
        }
        self._force_histograms: dict[str, torch.Tensor] = {}
        for limb_name in ("left_hand", "right_hand", "left_foot", "right_foot"):
            self._force_limit_sample_count[limb_name] = torch.zeros(
                self.num_envs, device=self.device
            )
            self._force_limit_over_soft_count[limb_name] = torch.zeros(
                self.num_envs, device=self.device
            )
            self._force_limit_previous_hard[limb_name] = torch.zeros(
                self.num_envs, dtype=torch.bool, device=self.device
            )
            self.metrics[f"{limb_name}_force_over_soft_fraction"] = torch.zeros(
                self.num_envs, device=self.device
            )
            self.metrics[f"{limb_name}_hard_collision_count"] = torch.zeros(
                self.num_envs, device=self.device
            )
            if self._contact_force_soft_limits:
                self._force_histograms[limb_name] = torch.zeros(
                    self.num_envs,
                    self._force_histogram_bin_count,
                    device=self.device,
                )
                self.metrics[f"{limb_name}_force_p95"] = torch.zeros(
                    self.num_envs, device=self.device
                )

    def _validate_ladder_metadata(self) -> None:
        if self.motion.ladder_params is not None:
            expected = np.asarray(
                [
                    self.ladder_geometry.phi,
                    self.ladder_geometry.rung_spacing,
                    self.ladder_geometry.rung_length,
                    self.ladder_geometry.rung_width,
                ],
                dtype=np.float32,
            )
            if not np.allclose(self.motion.ladder_params, expected, atol=1.0e-5):
                raise ValueError(
                    f"motion ladder parameters {self.motion.ladder_params.tolist()} do not match "
                    f"environment ladder parameters {expected.tolist()}"
                )
        if self.motion.ladder_origin is not None:
            expected_origin = np.asarray(self.ladder_geometry.origin, dtype=np.float32)
            if not np.allclose(self.motion.ladder_origin, expected_origin, atol=1.0e-5):
                raise ValueError(
                    f"motion ladder origin {self.motion.ladder_origin.tolist()} does not match "
                    f"environment ladder origin {expected_origin.tolist()}"
                )
        if (
            self.motion.ladder_num_rungs is not None
            and self.motion.ladder_num_rungs != self.ladder_geometry.num_rungs
        ):
            raise ValueError(
                f"motion has {self.motion.ladder_num_rungs} rungs but environment has "
                f"{self.ladder_geometry.num_rungs}"
            )

    def _sample_ladder_geometry(self, env_ids: torch.Tensor) -> None:
        inclination_range = self.cfg.ladder_inclination_delta_range
        spacing_range = self.cfg.ladder_spacing_delta_range
        inclination_deltas = sample_uniform(
            inclination_range[0], inclination_range[1], (len(env_ids),), self.device
        )
        spacing_deltas = sample_uniform(
            spacing_range[0], spacing_range[1], (len(env_ids),), self.device
        )
        inclination_deltas, spacing_deltas, nominal_mask = (
            mix_nominal_ladder_geometry_samples(
                inclination_deltas,
                spacing_deltas,
                self.cfg.nominal_ladder_geometry_probability,
            )
        )
        self.ladder_phi[env_ids] = self.ladder_geometry.phi + inclination_deltas
        self.ladder_spacing[env_ids] = self.ladder_geometry.rung_spacing + spacing_deltas
        self._nominal_ladder_geometry_episode[env_ids] = nominal_mask
        zeros = torch.zeros(len(env_ids), dtype=torch.float32, device=self.device)
        self._ladder_delta_quat[env_ids] = quat_from_euler_xyz(
            zeros,
            self.ladder_geometry.phi - self.ladder_phi[env_ids],
            zeros,
        )
        if self._ladder_asset is not None:
            self._write_ladder_box_poses(env_ids)

    def _write_ladder_box_poses(self, env_ids: torch.Tensor) -> None:
        target_cos = torch.cos(self.ladder_phi[env_ids]).unsqueeze(-1)
        target_sin = torch.sin(self.ladder_phi[env_ids]).unsqueeze(-1)
        axial = self._ladder_box_axial.unsqueeze(0) * (
            self.ladder_spacing[env_ids].unsqueeze(-1) / self.ladder_geometry.rung_spacing
        )
        normal = self._ladder_box_normal.unsqueeze(0)
        positions_e = self._ladder_box_positions_e.unsqueeze(0).repeat(len(env_ids), 1, 1)
        positions_e[..., 0] = self._ladder_origin_e[0] + axial * target_cos - normal * target_sin
        positions_e[..., 2] = self._ladder_origin_e[2] + axial * target_sin + normal * target_cos
        positions_e[:, self._ladder_fixed_box_mask] = self._ladder_box_positions_e[
            self._ladder_fixed_box_mask
        ]
        rung_indexes = torch.arange(
            len(self.cfg.ladder_rung_box_names), dtype=torch.float32, device=self.device
        ).view(1, -1, 1)
        directions = torch.stack(
            (
                torch.cos(self.ladder_phi[env_ids]),
                torch.zeros_like(self.ladder_phi[env_ids]),
                torch.sin(self.ladder_phi[env_ids]),
            ),
            dim=-1,
        ).unsqueeze(1)
        rung_tops = (
            self._ladder_origin_e.view(1, 1, 3)
            + rung_indexes * self.ladder_spacing[env_ids].view(-1, 1, 1) * directions
        )
        positions_e[:, self._ladder_rung_box_indexes] = (
            rung_tops + self._ladder_rung_center_offsets_e.unsqueeze(0)
        )

        quaternions = self._ladder_box_quats.unsqueeze(0).repeat(len(env_ids), 1, 1)
        if torch.any(self._ladder_inclined_box_mask):
            delta_quat = self._ladder_delta_quat[env_ids].unsqueeze(1).expand(-1, quaternions.shape[1], -1)
            rotated_quaternions = quat_mul(delta_quat, quaternions)
            quaternions[:, self._ladder_inclined_box_mask] = rotated_quaternions[
                :, self._ladder_inclined_box_mask
            ]
        positions_w = positions_e + self._env.scene.env_origins[env_ids].unsqueeze(1)
        self._ladder_asset.write_object_pose_to_sim(
            torch.cat((positions_w, quaternions), dim=-1), env_ids=env_ids
        )

    @property
    def command(self) -> torch.Tensor:
        return torch.cat([self.joint_pos, self.joint_vel], dim=1)

    @property
    def joint_pos(self) -> torch.Tensor:
        return self.motion.joint_pos[self.time_steps]

    @property
    def joint_vel(self) -> torch.Tensor:
        return self.motion.joint_vel[self.time_steps]

    @property
    def body_pos_w(self) -> torch.Tensor:
        return self.motion.body_pos_w[self.time_steps] + self._env.scene.env_origins[:, None, :]

    @property
    def body_quat_w(self) -> torch.Tensor:
        return self.motion.body_quat_w[self.time_steps]

    @property
    def body_lin_vel_w(self) -> torch.Tensor:
        return self.motion.body_lin_vel_w[self.time_steps]

    @property
    def body_ang_vel_w(self) -> torch.Tensor:
        return self.motion.body_ang_vel_w[self.time_steps]

    @property
    def anchor_pos_w(self) -> torch.Tensor:
        return (
            self.motion.body_pos_w[self.time_steps, self.motion_anchor_body_index]
            + self._env.scene.env_origins
        )

    @property
    def anchor_quat_w(self) -> torch.Tensor:
        return self.motion.body_quat_w[self.time_steps, self.motion_anchor_body_index]

    @property
    def anchor_lin_vel_w(self) -> torch.Tensor:
        return self.motion.body_lin_vel_w[self.time_steps, self.motion_anchor_body_index]

    @property
    def anchor_ang_vel_w(self) -> torch.Tensor:
        return self.motion.body_ang_vel_w[self.time_steps, self.motion_anchor_body_index]

    @property
    def robot_joint_pos(self) -> torch.Tensor:
        return self.robot.data.joint_pos

    @property
    def robot_joint_vel(self) -> torch.Tensor:
        return self.robot.data.joint_vel

    @property
    def robot_body_pos_w(self) -> torch.Tensor:
        return self.robot.data.body_pos_w[:, self.body_indexes]

    @property
    def robot_body_quat_w(self) -> torch.Tensor:
        return self.robot.data.body_quat_w[:, self.body_indexes]

    @property
    def robot_body_lin_vel_w(self) -> torch.Tensor:
        return self.robot.data.body_lin_vel_w[:, self.body_indexes]

    @property
    def robot_body_ang_vel_w(self) -> torch.Tensor:
        return self.robot.data.body_ang_vel_w[:, self.body_indexes]

    @property
    def robot_anchor_pos_w(self) -> torch.Tensor:
        return self.robot.data.body_pos_w[:, self.robot_anchor_body_index]

    @property
    def robot_anchor_quat_w(self) -> torch.Tensor:
        return self.robot.data.body_quat_w[:, self.robot_anchor_body_index]

    @property
    def robot_anchor_lin_vel_w(self) -> torch.Tensor:
        return self.robot.data.body_lin_vel_w[:, self.robot_anchor_body_index]

    @property
    def robot_anchor_ang_vel_w(self) -> torch.Tensor:
        return self.robot.data.body_ang_vel_w[:, self.robot_anchor_body_index]

    @property
    def contact_indicator(self) -> torch.Tensor:
        return self.motion.contact_indicator[self.time_steps]

    @property
    def contact_rung_id(self) -> torch.Tensor:
        return self.motion.contact_rung_id[self.time_steps]

    @property
    def ladder_origins_w(self) -> torch.Tensor:
        return self._ladder_origin_e.unsqueeze(0) + self._env.scene.env_origins

    @property
    def rung_positions_w(self) -> torch.Tensor:
        rung_indexes = torch.arange(
            self.ladder_geometry.num_rungs, dtype=torch.float32, device=self.device
        ).view(1, -1, 1)
        directions = torch.stack(
            (
                torch.cos(self.ladder_phi),
                torch.zeros_like(self.ladder_phi),
                torch.sin(self.ladder_phi),
            ),
            dim=-1,
        ).unsqueeze(1)
        origins = self.ladder_origins_w.unsqueeze(1)
        return origins + rung_indexes * self.ladder_spacing.view(-1, 1, 1) * directions

    @property
    def target_contact_pos_w(self) -> torch.Tensor:
        rung_ids = torch.clamp(self.contact_rung_id, 0, self.ladder_geometry.num_rungs - 1)
        rung_positions = self.rung_positions_w
        targets = torch.gather(
            rung_positions,
            1,
            rung_ids.unsqueeze(-1).expand(-1, -1, 3),
        )
        return targets + self._limb_offsets.unsqueeze(0)

    @property
    def robot_limb_pos_w(self) -> torch.Tensor:
        return self.robot.data.body_pos_w[:, self.limb_body_indexes]

    @property
    def ladder_params(self) -> torch.Tensor:
        return torch.stack(
            (
                self.ladder_phi,
                self.ladder_spacing,
                torch.full_like(self.ladder_phi, self.ladder_geometry.rung_length),
                torch.full_like(self.ladder_phi, self.ladder_geometry.rung_width),
            ),
            dim=-1,
        )

    def _update_metrics(self):
        reference_anchor_pos_w = self.anchor_pos_w
        robot_anchor_pos_w = self.robot_anchor_pos_w
        initialized = self._tracking_path_initialized.clone()
        if torch.any(~initialized):
            self._tracking_start_reference_anchor_pos_w[~initialized] = reference_anchor_pos_w[~initialized]
            self._tracking_start_robot_anchor_pos_w[~initialized] = robot_anchor_pos_w[~initialized]
            self._tracking_previous_reference_anchor_pos_w[~initialized] = reference_anchor_pos_w[~initialized]
            self._tracking_previous_robot_anchor_pos_w[~initialized] = robot_anchor_pos_w[~initialized]

        reference_step = torch.linalg.norm(
            reference_anchor_pos_w - self._tracking_previous_reference_anchor_pos_w, dim=-1
        )
        robot_step = torch.linalg.norm(robot_anchor_pos_w - self._tracking_previous_robot_anchor_pos_w, dim=-1)
        reference_step = torch.where(initialized, reference_step, torch.zeros_like(reference_step))
        robot_step = torch.where(initialized, robot_step, torch.zeros_like(robot_step))
        self.metrics["reference_anchor_path_length"] += reference_step
        self.metrics["robot_anchor_path_length"] += robot_step
        self._tracking_previous_reference_anchor_pos_w.copy_(reference_anchor_pos_w)
        self._tracking_previous_robot_anchor_pos_w.copy_(robot_anchor_pos_w)
        self._tracking_path_initialized[:] = True

        reference_displacement_vector = reference_anchor_pos_w - self._tracking_start_reference_anchor_pos_w
        robot_displacement_vector = robot_anchor_pos_w - self._tracking_start_robot_anchor_pos_w
        reference_displacement = torch.linalg.norm(reference_displacement_vector, dim=-1)
        robot_displacement = torch.linalg.norm(robot_displacement_vector, dim=-1)
        progress_evaluable = reference_displacement > _REFERENCE_PROGRESS_DISTANCE_THRESHOLD
        progress_ratio = torch.sum(robot_displacement_vector * reference_displacement_vector, dim=-1) / (
            torch.square(reference_displacement).clamp_min(1.0e-6)
        )
        self.metrics["reference_anchor_displacement"] = reference_displacement
        self.metrics["robot_anchor_displacement"] = robot_displacement
        self.metrics["anchor_progress_ratio"] = torch.where(
            progress_evaluable, progress_ratio, torch.zeros_like(progress_ratio)
        )
        self.metrics["progress_evaluable"] = progress_evaluable.float()

        reference_speed = torch.linalg.norm(self.anchor_lin_vel_w, dim=-1)
        robot_speed = torch.linalg.norm(self.robot_anchor_lin_vel_w, dim=-1)
        reference_moving = reference_speed > _REFERENCE_MOVING_SPEED_THRESHOLD
        robot_stationary = robot_speed < _ROBOT_STATIONARY_SPEED_THRESHOLD
        self._tracking_episode_steps += initialized.float()
        self._tracking_reference_motion_steps += reference_moving.float()
        self._tracking_stationary_motion_steps += (reference_moving & robot_stationary).float()
        self.metrics["reference_anchor_speed"] = reference_speed
        self.metrics["robot_anchor_speed"] = robot_speed
        self.metrics["reference_joint_speed"] = torch.linalg.norm(self.joint_vel, dim=-1)
        self.metrics["robot_joint_speed"] = torch.linalg.norm(self.robot_joint_vel, dim=-1)
        self.metrics["reference_moving_fraction"] = self._tracking_reference_motion_steps / self._tracking_episode_steps.clamp_min(1.0)
        self.metrics["stationary_during_reference_motion_fraction"] = (
            self._tracking_stationary_motion_steps / self._tracking_reference_motion_steps.clamp_min(1.0)
        )
        remaining_frames = (self.motion.time_step_total - 1 - self._episode_start_time_steps).clamp_min(1)
        self.metrics["reference_completion_fraction"] = (
            (self.time_steps - self._episode_start_time_steps).clamp_min(0).float() / remaining_frames.float()
        ).clamp(max=1.0)

        self.metrics["error_anchor_pos"] = torch.norm(self.anchor_pos_w - self.robot_anchor_pos_w, dim=-1)
        self.metrics["error_anchor_rot"] = quat_error_magnitude(self.anchor_quat_w, self.robot_anchor_quat_w)
        self.metrics["error_anchor_lin_vel"] = torch.norm(self.anchor_lin_vel_w - self.robot_anchor_lin_vel_w, dim=-1)
        self.metrics["error_anchor_ang_vel"] = torch.norm(self.anchor_ang_vel_w - self.robot_anchor_ang_vel_w, dim=-1)
        self.metrics["error_body_pos"] = torch.norm(
            self.body_pos_relative_w - self.robot_body_pos_w, dim=-1
        ).mean(dim=-1)
        self.metrics["error_body_rot"] = quat_error_magnitude(
            self.body_quat_relative_w, self.robot_body_quat_w
        ).mean(dim=-1)
        self.metrics["error_body_lin_vel"] = torch.norm(
            self.body_lin_vel_w - self.robot_body_lin_vel_w, dim=-1
        ).mean(dim=-1)
        self.metrics["error_body_ang_vel"] = torch.norm(
            self.body_ang_vel_w - self.robot_body_ang_vel_w, dim=-1
        ).mean(dim=-1)
        self.metrics["error_joint_pos"] = torch.norm(self.joint_pos - self.robot_joint_pos, dim=-1)
        self.metrics["error_joint_vel"] = torch.norm(self.joint_vel - self.robot_joint_vel, dim=-1)

        errors = torch.norm(self.robot_limb_pos_w - self.target_contact_pos_w, dim=-1)
        contact_forces_w = self._contact_sensor.data.net_forces_w[:, self._contact_limb_body_indexes, :]
        required, physical_contact, target_contact = classify_limb_contacts(
            self.contact_indicator,
            self.robot_limb_pos_w,
            self.target_contact_pos_w,
            contact_forces_w,
            self._limb_target_distance_thresholds,
            self.cfg.contact_force_threshold,
        )
        required_count = required.sum(dim=-1).clamp(min=1)
        self.metrics["mean_required_contact_error"] = (errors * required).sum(dim=-1) / required_count
        self.metrics["required_contact_fraction"] = required.float().mean(dim=-1)
        required_physical = required & physical_contact
        self.metrics["required_physical_contact_fraction"] = (
            required_physical.sum(dim=-1).float() / required_count
        )
        self.metrics["required_target_contact_fraction"] = (
            target_contact.sum(dim=-1).float() / required_count
        )
        self.metrics["swing_physical_contact_fraction"] = (
            ((~required) & physical_contact).float().mean(dim=-1)
        )
        for limb_index, limb_name in enumerate(self.limb_names):
            self.metrics[f"{limb_name}_physical_contact"] = physical_contact[:, limb_index].float()
            self.metrics[f"{limb_name}_required_physical_contact"] = (
                required_physical[:, limb_index].float()
            )
            self.metrics[f"{limb_name}_required_target_contact"] = target_contact[:, limb_index].float()
        for hand_name in ("left_hand", "right_hand"):
            hand_index = self.limb_names.index(hand_name)
            hand_required = required[:, hand_index]
            self.metrics[f"{hand_name}_required_contact_error"] = (
                errors[:, hand_index] * hand_required
            )
            self.metrics[f"{hand_name}_contact_required"] = hand_required.float()
        self._update_contact_force_metrics()
        self.metrics["fixed_start_episode"] = self._fixed_start_episode.float()
        self.metrics["fixed_start_pose_randomized_episode"] = (
            self._fixed_start_pose_randomized_episode.float()
        )
        self.metrics["fixed_start_pose_nominal_episode"] = (
            self._fixed_start_episode & ~self._fixed_start_pose_randomized_episode
        ).float()
        self.metrics["uniform_start_episode"] = self._uniform_start_episode.float()
        self.metrics["adaptive_start_episode"] = (
            ~self._fixed_start_episode & ~self._uniform_start_episode
        ).float()
        self.metrics["ladder_inclination_deg"] = torch.rad2deg(self.ladder_phi)
        self.metrics["ladder_rung_spacing"] = self.ladder_spacing
        self.metrics["nominal_ladder_geometry_episode"] = (
            self._nominal_ladder_geometry_episode.float()
        )

    def _finalize_force_histograms(self, env_ids: Sequence[int] | slice | None) -> None:
        if not self._force_histograms:
            return
        resolved_env_ids = slice(None) if env_ids is None else env_ids
        for limb_name, histogram in self._force_histograms.items():
            selected = histogram[resolved_env_ids]
            total = selected.sum(dim=-1)
            target = 0.95 * total
            cumulative = selected.cumsum(dim=-1)
            reached = cumulative >= target.unsqueeze(-1)
            bin_index = reached.float().argmax(dim=-1)
            p95 = (bin_index.float() + 0.5) * (
                self._force_histogram_max[limb_name] / self._force_histogram_bin_count
            )
            p95 = torch.where(total > 0.0, p95, torch.zeros_like(p95))
            self.metrics[f"{limb_name}_force_p95"][resolved_env_ids] = p95

    def reset(self, env_ids: Sequence[int] | None = None) -> dict[str, float]:
        self._finalize_force_histograms(env_ids)
        return super().reset(env_ids)

    def _update_contact_force_metrics(self) -> None:
        current_forces: dict[str, torch.Tensor] = {}
        for metric_name, (sensor, surface) in self._contact_force_metric_specs.items():
            force_matrix_w = sensor.data.force_matrix_w
            if force_matrix_w is None:
                continue
            current_max = filtered_surface_force_max(
                force_matrix_w,
                surface=surface,
                min_top_normal_fraction=(
                    self.cfg.contact_front_normal_fraction
                    if surface == "front"
                    else 0.5
                ),
            )
            self.metrics[metric_name] = torch.maximum(
                self.metrics[metric_name], current_max
            )
            current_forces[metric_name.removesuffix("_force_max")] = current_max

        for side, limb_name in (("left", "left_hand"), ("right", "right_hand")):
            sensor_name = f"{side}_hand_step_contacts"
            if sensor_name not in self._env.scene.sensors:
                continue
            force_matrix_w = self._env.scene.sensors[sensor_name].data.force_matrix_w
            if force_matrix_w is None:
                continue
            limb_index = self.limb_names.index(limb_name)
            target_forces_w = target_rung_forces(
                force_matrix_w,
                self.contact_rung_id[:, limb_index : limb_index + 1],
            )
            target_upward = torch.clamp_min(target_forces_w[:, 0, 2], 0.0)
            metric_name = f"{side}_hand_target_rung_upward_force_max"
            self.metrics[metric_name] = torch.maximum(
                self.metrics[metric_name], target_upward
            )
            current_forces[f"{side}_hand_target_rung_upward"] = target_upward
            non_target_forces_w = non_target_rung_forces(
                force_matrix_w,
                self.contact_rung_id[:, limb_index : limb_index + 1],
            )
            wrong_rung_top = filtered_surface_force_max(
                non_target_forces_w,
                surface="top",
                min_top_normal_fraction=0.5,
            )
            wrong_metric_name = f"{side}_hand_wrong_rung_force_max"
            self.metrics[wrong_metric_name] = torch.maximum(
                self.metrics[wrong_metric_name], wrong_rung_top
            )
            current_forces[f"{side}_hand_wrong_rung"] = wrong_rung_top

        for side, limb_name in (("left", "left_foot"), ("right", "right_foot")):
            sensor_name = f"{side}_foot_step_contacts"
            if sensor_name not in self._env.scene.sensors:
                continue
            force_matrix_w = self._env.scene.sensors[sensor_name].data.force_matrix_w
            if force_matrix_w is None:
                continue
            limb_index = self.limb_names.index(limb_name)
            target_forces_w = target_rung_forces(
                force_matrix_w,
                self.contact_rung_id[:, limb_index : limb_index + 1],
            )
            target_force = torch.linalg.vector_norm(target_forces_w[:, 0], dim=-1)
            metric_name = f"{side}_foot_target_rung_force_max"
            self.metrics[metric_name] = torch.maximum(
                self.metrics[metric_name], target_force
            )
            current_forces[f"{side}_foot_target_rung"] = target_force

        if self._force_histograms:
            histogram_values = {
                "left_hand": [
                    value
                    for name, value in current_forces.items()
                    if name.startswith("left_hand_") and not name.endswith("target_rung_upward")
                ],
                "right_hand": [
                    value
                    for name, value in current_forces.items()
                    if name.startswith("right_hand_") and not name.endswith("target_rung_upward")
                ],
                "left_foot": [
                    value
                    for name, value in current_forces.items()
                    if name == "left_foot_step"
                ],
                "right_foot": [
                    value
                    for name, value in current_forces.items()
                    if name == "right_foot_step"
                ],
            }
            for limb_name, values in histogram_values.items():
                if not values:
                    continue
                current_force = torch.stack(values, dim=-1).amax(dim=-1)
                bin_index = torch.clamp(
                    (
                        current_force
                        / self._force_histogram_max[limb_name]
                        * self._force_histogram_bin_count
                    ).long(),
                    min=0,
                    max=self._force_histogram_bin_count - 1,
                )
                self._force_histograms[limb_name].scatter_add_(
                    1,
                    bin_index.unsqueeze(-1),
                    torch.ones(
                        self.num_envs, 1, device=self.device, dtype=self._force_histograms[limb_name].dtype
                    ),
                )

        if self._contact_force_soft_limits:
            limit_values_by_limb = {
                "left_hand": {
                    name: value
                    for name, value in current_forces.items()
                    if name.startswith("left_hand_")
                },
                "right_hand": {
                    name: value
                    for name, value in current_forces.items()
                    if name.startswith("right_hand_")
                },
                "left_foot": {
                    name: value
                    for name, value in current_forces.items()
                    if name.startswith("left_foot_")
                },
                "right_foot": {
                    name: value
                    for name, value in current_forces.items()
                    if name.startswith("right_foot_")
                },
            }
            for limb_name, values in limit_values_by_limb.items():
                comparable = []
                for metric_name, force_value in values.items():
                    limit_key = metric_name.split("_", 1)[1]
                    if limit_key in self._contact_force_soft_limits:
                        comparable.append(
                            (
                                force_value,
                                self._contact_force_soft_limits[limit_key],
                                self._contact_force_hard_limits[limit_key],
                            )
                        )
                if not comparable:
                    continue
                soft_exceeded = torch.stack(
                    [force_value > force_soft for force_value, force_soft, _ in comparable],
                    dim=-1,
                ).any(dim=-1)
                hard_exceeded = torch.stack(
                    [force_value > force_hard for force_value, _, force_hard in comparable],
                    dim=-1,
                ).any(dim=-1)
                self._force_limit_sample_count[limb_name] += 1.0
                self._force_limit_over_soft_count[limb_name] += soft_exceeded.float()
                hard_event = hard_exceeded & ~self._force_limit_previous_hard[limb_name]
                self.metrics[f"{limb_name}_force_over_soft_fraction"] = (
                    self._force_limit_over_soft_count[limb_name]
                    / self._force_limit_sample_count[limb_name].clamp_min(1.0)
                )
                self.metrics[f"{limb_name}_hard_collision_count"] += hard_event.float()
                self._force_limit_previous_hard[limb_name] = hard_exceeded

    def _adaptive_sampling(self, env_ids: Sequence[int]):
        reset_valid_masks = self.motion.geometry_reset_valid_masks(
            self.ladder_phi[env_ids] - self.ladder_geometry.phi,
            self.ladder_spacing[env_ids] - self.ladder_geometry.rung_spacing,
        )
        self._current_reset_valid_fraction[env_ids] = reset_valid_masks.float().mean(dim=-1)
        if self.cfg.fixed_reference_frame is not None:
            if torch.any(~reset_valid_masks[:, self.cfg.fixed_reference_frame]):
                raise ValueError(
                    f"fixed_reference_frame {self.cfg.fixed_reference_frame} is invalid for at least "
                    "one sampled ladder geometry; disable geometry randomization for this diagnostic"
                )
            self.time_steps[env_ids] = self.cfg.fixed_reference_frame
            # A fixed frame-0 replay is still a fixed-start episode.  Preserve
            # the dedicated frame-0 reset pose randomization in this mode.
            self._fixed_start_episode[env_ids] = (
                self.cfg.fixed_reference_frame == self.cfg.fixed_start_frame
            )
            self._uniform_start_episode[env_ids] = False
            return
        if self.cfg.fixed_start_probability == 1.0:
            self.time_steps[env_ids] = self.cfg.fixed_start_frame
            self._fixed_start_episode[env_ids] = True
            self._uniform_start_episode[env_ids] = False
            fixed_bin = min(
                self.cfg.fixed_start_frame * self.bin_count // self.motion.time_step_total,
                self.bin_count - 1,
            )
            self.metrics["sampling_entropy"][env_ids] = 0.0
            self.metrics["sampling_top1_prob"][env_ids] = 1.0
            self.metrics["sampling_top1_bin"][env_ids] = fixed_bin / self.bin_count
            self.metrics["adaptive_sampling_top1_prob"][env_ids] = 0.0
            self.metrics["adaptive_sampling_top1_bin"][env_ids] = 0.0
            return

        episode_failed = self._env.termination_manager.terminated[env_ids]
        if torch.any(episode_failed):
            current_bin_index = torch.clamp(
                (self.time_steps * self.bin_count) // max(self.motion.time_step_total, 1), 0, self.bin_count - 1
            )
            fail_bins = current_bin_index[env_ids][episode_failed]
            self._current_bin_failed[:] = torch.bincount(fail_bins, minlength=self.bin_count)

        sampling_probabilities = self.bin_failed_count + self.cfg.adaptive_uniform_ratio / float(self.bin_count)
        sampling_probabilities = torch.nn.functional.pad(
            sampling_probabilities.unsqueeze(0).unsqueeze(0),
            (0, self.cfg.adaptive_kernel_size - 1),
            mode="replicate",
        )
        sampling_probabilities = torch.nn.functional.conv1d(sampling_probabilities, self.kernel.view(1, 1, -1)).view(-1)
        sampling_probabilities = sampling_probabilities / sampling_probabilities.sum()

        nonfixed_valid_masks = reset_valid_masks.clone()
        nonfixed_valid_masks[:, self.cfg.fixed_start_frame] = False
        if torch.any(~torch.any(nonfixed_valid_masks, dim=-1)):
            raise ValueError("sampled ladder geometry has no non-fixed valid reset frame")
        all_frame_indexes = torch.arange(
            self.motion.time_step_total, dtype=torch.long, device=self.device
        )
        frame_bins = torch.div(
            all_frame_indexes * self.bin_count,
            self.motion.time_step_total,
            rounding_mode="floor",
        ).clamp(max=self.bin_count - 1)
        valid_count_per_bin = torch.zeros(
            len(env_ids), self.bin_count, dtype=torch.float32, device=self.device
        )
        valid_count_per_bin.scatter_add_(
            1,
            frame_bins.unsqueeze(0).expand(len(env_ids), -1),
            nonfixed_valid_masks.float(),
        )
        per_frame_valid_count = torch.gather(
            valid_count_per_bin, 1, frame_bins.unsqueeze(0).expand(len(env_ids), -1)
        )
        adaptive_frame_probabilities = torch.where(
            nonfixed_valid_masks,
            sampling_probabilities[frame_bins].unsqueeze(0)
            / per_frame_valid_count.clamp_min(1.0),
            0.0,
        )
        adaptive_frame_probabilities /= adaptive_frame_probabilities.sum(dim=-1, keepdim=True)
        uniform_frame_probabilities = nonfixed_valid_masks.float()
        uniform_frame_probabilities /= uniform_frame_probabilities.sum(dim=-1, keepdim=True)
        adaptive_frames = torch.multinomial(
            adaptive_frame_probabilities, 1, replacement=True
        ).squeeze(-1)
        uniform_frames = torch.multinomial(
            uniform_frame_probabilities, 1, replacement=True
        ).squeeze(-1)
        sampled_frames, fixed_start_mask, uniform_start_mask = mix_reset_frame_samples(
            adaptive_frames,
            uniform_frames,
            self.cfg.fixed_start_frame,
            self.cfg.fixed_start_probability,
            self.cfg.uniform_start_probability,
        )
        self.time_steps[env_ids] = sampled_frames
        self._fixed_start_episode[env_ids] = fixed_start_mask
        self._uniform_start_episode[env_ids] = uniform_start_mask

        adaptive_bin_probabilities = torch.zeros_like(sampling_probabilities)
        adaptive_bin_probabilities.scatter_add_(
            0, frame_bins, adaptive_frame_probabilities.mean(dim=0)
        )
        uniform_bin_probabilities = torch.zeros_like(sampling_probabilities)
        uniform_bin_probabilities.scatter_add_(
            0,
            frame_bins,
            uniform_frame_probabilities.mean(dim=0),
        )
        adaptive_probability = 1.0 - self.cfg.fixed_start_probability - self.cfg.uniform_start_probability
        effective_probabilities = (
            adaptive_probability * adaptive_bin_probabilities
            + self.cfg.uniform_start_probability * uniform_bin_probabilities
        )
        fixed_bin = min(
            self.cfg.fixed_start_frame * self.bin_count // self.motion.time_step_total,
            self.bin_count - 1,
        )
        effective_probabilities[fixed_bin] += self.cfg.fixed_start_probability
        entropy = -(effective_probabilities * (effective_probabilities + 1e-12).log()).sum()
        entropy_norm = entropy / math.log(self.bin_count)
        pmax, imax = effective_probabilities.max(dim=0)
        adaptive_pmax, adaptive_imax = adaptive_bin_probabilities.max(dim=0)
        self.metrics["sampling_entropy"][env_ids] = entropy_norm
        self.metrics["sampling_top1_prob"][env_ids] = pmax
        self.metrics["sampling_top1_bin"][env_ids] = imax.float() / self.bin_count
        self.metrics["adaptive_sampling_top1_prob"][env_ids] = adaptive_pmax
        self.metrics["adaptive_sampling_top1_bin"][env_ids] = adaptive_imax.float() / self.bin_count

    def _resample_command(self, env_ids: Sequence[int]):
        if len(env_ids) == 0:
            return
        env_ids = torch.as_tensor(env_ids, dtype=torch.long, device=self.device)
        for limb_name in self._force_limit_sample_count:
            self._force_limit_sample_count[limb_name][env_ids] = 0.0
            self._force_limit_over_soft_count[limb_name][env_ids] = 0.0
            self._force_limit_previous_hard[limb_name][env_ids] = False
        for histogram in self._force_histograms.values():
            histogram[env_ids] = 0.0
        self._sample_ladder_geometry(env_ids)
        self._adaptive_sampling(env_ids)

        self._episode_start_time_steps[env_ids] = self.time_steps[env_ids]
        self._tracking_path_initialized[env_ids] = False
        self._tracking_episode_steps[env_ids] = 0.0
        self._tracking_reference_motion_steps[env_ids] = 0.0
        self._tracking_stationary_motion_steps[env_ids] = 0.0

        root_pos = self.body_pos_w[:, 0].clone()
        root_ori = self.body_quat_w[:, 0].clone()
        root_lin_vel = self.body_lin_vel_w[:, 0].clone()
        root_ang_vel = self.body_ang_vel_w[:, 0].clone()

        pose_lower, pose_upper, fixed_start_pose_randomized = pose_range_bounds(
            self.cfg.pose_range,
            len(env_ids),
            self.device,
            fixed_start_mask=self._fixed_start_episode[env_ids],
            fixed_start_pose_range=self.cfg.fixed_start_pose_range,
            fixed_start_pose_randomization_probability=(
                self.cfg.fixed_start_pose_randomization_probability
            ),
        )
        self._fixed_start_pose_randomized_episode[env_ids] = (
            fixed_start_pose_randomized
        )
        rand_samples = sample_uniform(
            pose_lower, pose_upper, (len(env_ids), 6), device=self.device
        )
        root_pos[env_ids] += rand_samples[:, 0:3]
        orientations_delta = quat_from_euler_xyz(rand_samples[:, 3], rand_samples[:, 4], rand_samples[:, 5])
        root_ori[env_ids] = quat_mul(orientations_delta, root_ori[env_ids])

        range_list = [self.cfg.velocity_range.get(key, (0.0, 0.0)) for key in ["x", "y", "z", "roll", "pitch", "yaw"]]
        ranges = torch.tensor(range_list, device=self.device)
        rand_samples = sample_uniform(ranges[:, 0], ranges[:, 1], (len(env_ids), 6), device=self.device)
        root_lin_vel[env_ids] += rand_samples[:, :3]
        root_ang_vel[env_ids] += rand_samples[:, 3:]

        joint_pos = self.joint_pos.clone()
        joint_vel = self.joint_vel.clone()
        joint_pos += sample_uniform(*self.cfg.joint_position_range, joint_pos.shape, joint_pos.device)
        soft_joint_pos_limits = self.robot.data.soft_joint_pos_limits[env_ids]
        joint_pos[env_ids] = torch.clip(
            joint_pos[env_ids], soft_joint_pos_limits[:, :, 0], soft_joint_pos_limits[:, :, 1]
        )
        self.robot.write_joint_state_to_sim(joint_pos[env_ids], joint_vel[env_ids], env_ids=env_ids)
        self.robot.write_root_state_to_sim(
            torch.cat([root_pos[env_ids], root_ori[env_ids], root_lin_vel[env_ids], root_ang_vel[env_ids]], dim=-1),
            env_ids=env_ids,
        )

        # Terminations and rewards run before the first post-reset command update.
        # Seed valid targets here so the first step never compares the robot against zero-filled buffers.
        self.body_pos_relative_w[env_ids] = self.body_pos_w[env_ids]
        self.body_quat_relative_w[env_ids] = self.body_quat_w[env_ids]
        self.metrics["reset_valid_fraction"][env_ids] = self._current_reset_valid_fraction[env_ids]

    def _update_command(self):
        if self.cfg.advance_reference:
            self.time_steps.add_(1).clamp_(max=self.motion.time_step_total - 1)

        anchor_pos_w_repeat = self.anchor_pos_w[:, None, :].repeat(1, len(self.cfg.body_names), 1)
        anchor_quat_w_repeat = self.anchor_quat_w[:, None, :].repeat(1, len(self.cfg.body_names), 1)
        robot_anchor_pos_w_repeat = self.robot_anchor_pos_w[:, None, :].repeat(1, len(self.cfg.body_names), 1)
        robot_anchor_quat_w_repeat = self.robot_anchor_quat_w[:, None, :].repeat(1, len(self.cfg.body_names), 1)

        delta_pos_w = robot_anchor_pos_w_repeat
        delta_pos_w[..., 2] = anchor_pos_w_repeat[..., 2]
        delta_ori_w = yaw_quat(quat_mul(robot_anchor_quat_w_repeat, quat_inv(anchor_quat_w_repeat)))

        self.body_quat_relative_w = quat_mul(delta_ori_w, self.body_quat_w)
        self.body_pos_relative_w = delta_pos_w + quat_apply(delta_ori_w, self.body_pos_w - anchor_pos_w_repeat)
        self.bin_failed_count = (
            self.cfg.adaptive_alpha * self._current_bin_failed + (1 - self.cfg.adaptive_alpha) * self.bin_failed_count
        )
        self._current_bin_failed.zero_()

    def _set_debug_vis_impl(self, debug_vis: bool):
        if debug_vis:
            if not hasattr(self, "current_anchor_visualizer"):
                self.current_anchor_visualizer = VisualizationMarkers(
                    self.cfg.anchor_visualizer_cfg.replace(prim_path="/Visuals/Command/current/anchor")
                )
                self.goal_anchor_visualizer = VisualizationMarkers(
                    self.cfg.anchor_visualizer_cfg.replace(prim_path="/Visuals/Command/goal/anchor")
                )
                self.current_body_visualizers = []
                self.goal_body_visualizers = []
                self.rung_visualizer = VisualizationMarkers(self.cfg.rung_visualizer_cfg)
                self.contact_target_visualizer = VisualizationMarkers(
                    self.cfg.contact_target_visualizer_cfg
                )
                for name in self.cfg.body_names:
                    self.current_body_visualizers.append(
                        VisualizationMarkers(
                            self.cfg.body_visualizer_cfg.replace(prim_path="/Visuals/Command/current/" + name)
                        )
                    )
                    self.goal_body_visualizers.append(
                        VisualizationMarkers(
                            self.cfg.body_visualizer_cfg.replace(prim_path="/Visuals/Command/goal/" + name)
                        )
                    )
            self.current_anchor_visualizer.set_visibility(True)
            self.goal_anchor_visualizer.set_visibility(True)
            self.rung_visualizer.set_visibility(True)
            self.contact_target_visualizer.set_visibility(True)
            for i in range(len(self.cfg.body_names)):
                self.current_body_visualizers[i].set_visibility(True)
                self.goal_body_visualizers[i].set_visibility(True)
        elif hasattr(self, "current_anchor_visualizer"):
            self.current_anchor_visualizer.set_visibility(False)
            self.goal_anchor_visualizer.set_visibility(False)
            self.rung_visualizer.set_visibility(False)
            self.contact_target_visualizer.set_visibility(False)
            for i in range(len(self.cfg.body_names)):
                self.current_body_visualizers[i].set_visibility(False)
                self.goal_body_visualizers[i].set_visibility(False)

    def _debug_vis_callback(self, event):
        if not self.robot.is_initialized:
            return
        self.current_anchor_visualizer.visualize(self.robot_anchor_pos_w, self.robot_anchor_quat_w)
        self.goal_anchor_visualizer.visualize(self.anchor_pos_w, self.anchor_quat_w)
        self.rung_visualizer.visualize(self.rung_positions_w.reshape(-1, 3))
        self.contact_target_visualizer.visualize(
            self.target_contact_pos_w.reshape(-1, 3),
            marker_indices=(self.contact_indicator <= 0.5).long().reshape(-1),
        )
        for i in range(len(self.cfg.body_names)):
            self.current_body_visualizers[i].visualize(self.robot_body_pos_w[:, i], self.robot_body_quat_w[:, i])
            self.goal_body_visualizers[i].visualize(self.body_pos_relative_w[:, i], self.body_quat_relative_w[:, i])


@configclass
class LadderMotionCommandCfg(CommandTermCfg):
    class_type: type = LadderMotionCommand

    asset_name: str = MISSING
    motion_file: str = "__MISSING_LADDER_MOTION_FILE__.npz"
    anchor_body_name: str = MISSING
    body_names: list[str] = MISSING

    ladder_geometry: LadderGeometry = LADDER_A
    ladder_asset_name: str | None = None
    ladder_inclination_delta_range: tuple[float, float] = (0.0, 0.0)
    ladder_spacing_delta_range: tuple[float, float] = (0.0, 0.0)
    nominal_ladder_geometry_probability: float = 0.0
    use_geometry_conditioned_reset_masks: bool = True
    ladder_fixed_box_names: tuple[str, ...] = ()
    ladder_rung_box_names: tuple[str, ...] = ()
    ladder_inclined_box_names: tuple[str, ...] = ()
    ladder_relative_observation_frame: str = "world"
    limb_names: tuple[str, ...] = LIMB_NAMES
    limb_body_names: dict[str, str] = DEFAULT_LIMB_BODY_NAMES
    limb_target_offsets: dict[str, tuple[float, float, float]] | None = None
    contact_sensor_name: str = "contact_forces"
    contact_force_threshold: float = 5.0
    contact_front_normal_fraction: float = 0.5
    limb_target_distance_thresholds: dict[str, float] | None = None
    contact_force_soft_limits: dict[str, float] = {}
    contact_force_hard_limits: dict[str, float] = {}
    fixed_reference_frame: int | None = None
    advance_reference: bool = True
    fixed_start_frame: int = 0
    fixed_start_probability: float = 0.0
    uniform_start_probability: float = 0.0

    pose_range: dict[str, tuple[float, float]] = {}
    fixed_start_pose_range: dict[str, tuple[float, float]] = {}
    fixed_start_pose_randomization_probability: float = 1.0
    velocity_range: dict[str, tuple[float, float]] = {}
    joint_position_range: tuple[float, float] = (-0.52, 0.52)

    adaptive_kernel_size: int = 1
    adaptive_lambda: float = 0.8
    adaptive_uniform_ratio: float = 0.1
    adaptive_alpha: float = 0.001

    anchor_visualizer_cfg: VisualizationMarkersCfg = FRAME_MARKER_CFG.replace(prim_path="/Visuals/Command/pose")
    anchor_visualizer_cfg.markers["frame"].scale = (0.2, 0.2, 0.2)
    body_visualizer_cfg: VisualizationMarkersCfg = FRAME_MARKER_CFG.replace(prim_path="/Visuals/Command/pose")
    body_visualizer_cfg.markers["frame"].scale = (0.1, 0.1, 0.1)
    rung_visualizer_cfg: VisualizationMarkersCfg = VisualizationMarkersCfg(
        prim_path="/Visuals/Command/ladder_rungs",
        markers={
            "rung": sim_utils.SphereCfg(
                radius=0.018,
                visual_material=sim_utils.PreviewSurfaceCfg(diffuse_color=(0.1, 0.7, 1.0)),
            )
        },
    )
    contact_target_visualizer_cfg: VisualizationMarkersCfg = VisualizationMarkersCfg(
        prim_path="/Visuals/Command/contact_targets",
        markers={
            "required": sim_utils.SphereCfg(
                radius=0.022,
                visual_material=sim_utils.PreviewSurfaceCfg(diffuse_color=(0.1, 1.0, 0.2)),
            ),
            "swing": sim_utils.SphereCfg(
                radius=0.014,
                visual_material=sim_utils.PreviewSurfaceCfg(diffuse_color=(0.45, 0.45, 0.45)),
            ),
        },
    )
