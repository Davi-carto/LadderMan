"""Vector-environment adapter for TransformerVision asymmetric PPO."""

from __future__ import annotations

import torch
from tensordict import TensorDict

from rsl_rl.env import VecEnv

from ladder.rsl_rl.modules.transformer_vision_actor import (
    CURRENT_PROPRIO_KEY,
    DEPTH_HISTORY_KEY,
    PROPRIO_HISTORY_KEY,
)
from ladder.rsl_rl.storage.transformer_vision_ppo_storage import (
    CRITIC_KEY,
    HEIGHTMAP_HIT_CLASS_KEY,
    HEIGHTMAP_KEY,
    HEIGHTMAP_VALID_KEY,
    NEXT_PROPRIO_KEY,
    VELOCITY_KEY,
)


def _as_transformer_vision_ppo_tensordict(
    observations: dict | TensorDict,
    *,
    num_envs: int,
    device: str | torch.device,
) -> TensorDict:
    if isinstance(observations, TensorDict):
        observations = observations.to_dict()
    inputs = observations["transformer_vision_inputs"]
    targets = observations["transformer_vision_targets"]
    auxiliary = observations["transformer_vision_auxiliary_targets"]
    proprio_history = inputs["proprio_history"]
    return TensorDict(
        {
            CURRENT_PROPRIO_KEY: proprio_history[:, -1],
            PROPRIO_HISTORY_KEY: proprio_history,
            DEPTH_HISTORY_KEY: inputs["depth_history"],
            HEIGHTMAP_KEY: targets["relative_height"],
            HEIGHTMAP_VALID_KEY: targets["hit_valid"],
            HEIGHTMAP_HIT_CLASS_KEY: targets["hit_class"],
            VELOCITY_KEY: auxiliary["base_lin_vel"],
            NEXT_PROPRIO_KEY: auxiliary["next_proprio"],
            CRITIC_KEY: observations["critic"],
        },
        batch_size=[num_envs],
        device=device,
    )


class TransformerVisionPPOVecEnvWrapper(VecEnv):
    """Expose deployable actor inputs and privileged labels as named fields."""

    def __init__(self, env, clip_actions: float | None = None) -> None:
        self.env = env
        self.clip_actions = clip_actions
        self.num_envs = env.unwrapped.num_envs
        self.device = env.unwrapped.device
        self.max_episode_length = env.unwrapped.max_episode_length
        self.num_actions = env.unwrapped.action_manager.total_action_dim
        self.env.reset()

    @property
    def cfg(self):
        return self.env.unwrapped.cfg

    @property
    def unwrapped(self):
        return self.env.unwrapped

    @property
    def episode_length_buf(self) -> torch.Tensor:
        return self.env.unwrapped.episode_length_buf

    @episode_length_buf.setter
    def episode_length_buf(self, value: torch.Tensor) -> None:
        self.env.unwrapped.episode_length_buf = value

    def get_observations(self) -> TensorDict:
        if hasattr(self.env.unwrapped, "observation_manager"):
            observations = self.env.unwrapped.observation_manager.compute()
        else:
            observations = self.env.unwrapped._get_observations()
        return _as_transformer_vision_ppo_tensordict(
            observations, num_envs=self.num_envs, device=self.device
        )

    def reset(self) -> TensorDict:
        observations, _ = self.env.reset()
        return _as_transformer_vision_ppo_tensordict(
            observations, num_envs=self.num_envs, device=self.device
        )

    def step(self, actions: torch.Tensor) -> tuple[TensorDict, torch.Tensor, torch.Tensor, dict]:
        if self.clip_actions is not None:
            actions = torch.clamp(actions, -self.clip_actions, self.clip_actions)
        observations, rewards, terminated, truncated, extras = self.env.step(actions)
        dones = (terminated | truncated).to(dtype=torch.bool)
        if not self.cfg.is_finite_horizon:
            extras["time_outs"] = truncated
        return (
            _as_transformer_vision_ppo_tensordict(
                observations, num_envs=self.num_envs, device=self.device
            ),
            rewards,
            dones,
            extras,
        )

    def close(self) -> None:
        self.env.close()


__all__ = ["TransformerVisionPPOVecEnvWrapper"]
