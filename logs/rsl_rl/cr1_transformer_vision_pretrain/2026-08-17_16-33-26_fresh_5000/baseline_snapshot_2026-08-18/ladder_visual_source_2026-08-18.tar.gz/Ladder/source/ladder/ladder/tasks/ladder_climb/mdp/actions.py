"""Ladder-specific action terms.

The reference policy outputs joint-position targets.  This term keeps the target
trajectory physically executable by applying a configurable first-order filter,
per-joint target rate limit, and optional reset startup ramp before the target is
sent to Isaac Lab's articulation drive.
"""

from __future__ import annotations

from collections.abc import Sequence
from typing import TYPE_CHECKING

import torch

import isaaclab.utils.string as string_utils
from isaaclab.envs.mdp.actions.joint_actions import JointPositionAction
from isaaclab.envs.mdp.actions.actions_cfg import JointPositionActionCfg
from isaaclab.utils import configclass

if TYPE_CHECKING:
    from isaaclab.envs import ManagerBasedEnv


def _resolve_joint_values(
    value: float | dict[str, float], joint_names: list[str], device: torch.device
) -> torch.Tensor:
    if isinstance(value, (float, int)):
        return torch.full((len(joint_names),), float(value), dtype=torch.float32, device=device)
    if not isinstance(value, dict):
        raise ValueError(f"joint value must be a float or dict, got {type(value)}")
    indexes, _, values = string_utils.resolve_matching_names_values(value, joint_names)
    result = torch.zeros(len(joint_names), dtype=torch.float32, device=device)
    result[indexes] = torch.tensor(values, dtype=torch.float32, device=device)
    return result


@configclass
class RateLimitedJointPositionActionCfg(JointPositionActionCfg):
    """Joint position targets with hardware-oriented target smoothing."""

    class_type: type = JointPositionAction
    max_target_velocity: float | dict[str, float] = 6.0
    """Maximum target change in rad/s, per joint."""

    filter_alpha: float | dict[str, float] = 0.5
    """First-order target filter coefficient in (0, 1]."""

    startup_ramp_s: float = 0.30
    """Time after reset over which target changes are gradually enabled."""

    def __post_init__(self):
        super().__post_init__()
        self.class_type = RateLimitedJointPositionAction


class RateLimitedJointPositionAction(JointPositionAction):
    """Filter and rate-limit joint position targets before applying them."""

    cfg: RateLimitedJointPositionActionCfg

    def __init__(self, cfg: RateLimitedJointPositionActionCfg, env: ManagerBasedEnv):
        super().__init__(cfg, env)
        self._step_dt = float(env.step_dt)
        if self._step_dt <= 0.0:
            raise ValueError(f"environment step_dt must be positive, got {self._step_dt}")
        max_velocity = _resolve_joint_values(cfg.max_target_velocity, self._joint_names, self.device)
        filter_alpha = _resolve_joint_values(cfg.filter_alpha, self._joint_names, self.device)
        if torch.any(max_velocity <= 0.0):
            raise ValueError("max_target_velocity must be positive for every joint")
        if torch.any((filter_alpha <= 0.0) | (filter_alpha > 1.0)):
            raise ValueError("filter_alpha must be in (0, 1] for every joint")
        if cfg.startup_ramp_s < 0.0:
            raise ValueError("startup_ramp_s must be non-negative")

        self._max_target_delta = max_velocity.unsqueeze(0) * self._step_dt
        self._filter_alpha = filter_alpha.unsqueeze(0)
        self._startup_ramp_s = float(cfg.startup_ramp_s)
        self._last_target = torch.zeros_like(self.raw_actions)
        self._initialized = torch.zeros(self.num_envs, dtype=torch.bool, device=self.device)
        self._startup_time = torch.zeros(self.num_envs, dtype=torch.float32, device=self.device)

    def process_actions(self, actions: torch.Tensor):
        super().process_actions(actions)
        current_position = self._asset.data.joint_pos[:, self._joint_ids]
        uninitialized = ~self._initialized
        if torch.any(uninitialized):
            # The command term writes the sampled reset pose before the first policy
            # action.  Starting from measured position prevents a reset kick.
            self._last_target[uninitialized] = current_position[uninitialized]
            self._initialized[uninitialized] = True
            self._startup_time[uninitialized] = 0.0

        desired = self._processed_actions
        alpha = self._filter_alpha
        if self._startup_ramp_s > 0.0:
            ramp = torch.clamp(self._startup_time / self._startup_ramp_s, 0.0, 1.0).unsqueeze(-1)
        else:
            ramp = torch.ones((self.num_envs, 1), dtype=desired.dtype, device=self.device)
        filtered = self._last_target + ramp * alpha * (desired - self._last_target)
        delta = torch.clamp(
            filtered - self._last_target,
            min=-self._max_target_delta,
            max=self._max_target_delta,
        )
        self._processed_actions = self._last_target + delta
        self._last_target.copy_(self._processed_actions)
        self._startup_time += self._step_dt

    def reset(self, env_ids: Sequence[int] | None = None) -> None:
        super().reset(env_ids)
        if env_ids is None:
            env_ids = slice(None)
        self._initialized[env_ids] = False
        self._startup_time[env_ids] = 0.0


RateLimitedJointPositionActionCfg.class_type = RateLimitedJointPositionAction


__all__ = ["RateLimitedJointPositionAction", "RateLimitedJointPositionActionCfg"]
