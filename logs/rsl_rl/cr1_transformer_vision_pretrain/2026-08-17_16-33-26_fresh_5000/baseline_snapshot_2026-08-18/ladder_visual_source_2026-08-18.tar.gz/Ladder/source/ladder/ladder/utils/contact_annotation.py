from __future__ import annotations

from dataclasses import dataclass, field
from os import PathLike
from pathlib import Path
from typing import Mapping, Sequence

import numpy as np

from ladder.tasks.ladder_climb.ladder_geometry import LADDER_A, LadderGeometry, generate_ladder, get_rung_pose
from ladder.utils.contact_schema import CR1_VIRTUAL_BODY_SPECS, DEFAULT_G1_BODY_NAMES, DEFAULT_LIMB_BODY_NAMES, LIMB_NAMES


@dataclass(frozen=True)
class ContactAnnotationCfg:
    """Rule-based labels for the first single-motion LadderMan expert."""

    ladder_geometry: LadderGeometry = field(default_factory=lambda: LADDER_A)
    limb_names: tuple[str, ...] = LIMB_NAMES
    limb_body_names: tuple[str, ...] = tuple(DEFAULT_LIMB_BODY_NAMES[name] for name in LIMB_NAMES)
    limb_target_offsets: tuple[tuple[float, float, float], ...] | None = None
    distance_threshold: float = 0.125
    limb_distance_thresholds: tuple[float, ...] | None = None
    speed_threshold: float = 0.35
    min_contact_frames: int = 4
    max_gap_frames: int = 2
    ladder_asset_translation: tuple[float, float, float] | None = None
    ladder_asset_yaw_deg: float | None = None
    ground_initial_feet: bool = False
    initial_foot_target_z: float = 0.0


def annotate_motion_file(
    input_file: str | PathLike[str],
    output_file: str | PathLike[str],
    cfg: ContactAnnotationCfg,
    *,
    limb_body_indexes: Sequence[int] | None = None,
    overwrite: bool = False,
) -> dict[str, np.ndarray]:
    """Annotate a WBT-style motion npz with ladder contact labels and save it."""

    input_path = Path(input_file)
    output_path = Path(output_file)
    if output_path.exists() and not overwrite:
        raise FileExistsError(f"Output file already exists: {output_path}. Pass overwrite=True to replace it.")

    with np.load(input_path, allow_pickle=False) as data:
        motion = {key: data[key] for key in data.files}

    motion = _prepare_motion(motion, cfg, limb_body_indexes)
    labels = annotate_ladder_contacts(motion, cfg, limb_body_indexes=limb_body_indexes)
    motion.update(labels)
    np.savez(output_path, **motion)
    return labels


def annotate_ladder_contacts(
    motion: Mapping[str, np.ndarray],
    cfg: ContactAnnotationCfg,
    *,
    limb_body_indexes: Sequence[int] | None = None,
) -> dict[str, np.ndarray]:
    """Infer `contact_indicator` and `contact_rung_id` from end-effector trajectories.

    The first version intentionally assumes one upward reference motion with fixed timing.
    It labels frames as contact when the limb is close to its geometry-derived target
    rung point and moving slowly enough to be considered in a support phase.
    """

    if "fps" not in motion or "body_pos_w" not in motion:
        raise KeyError("motion must contain at least 'fps' and 'body_pos_w'")

    motion = _prepare_motion(motion, cfg, limb_body_indexes)

    body_pos_w = np.asarray(motion["body_pos_w"], dtype=np.float32)
    if body_pos_w.ndim != 3 or body_pos_w.shape[-1] != 3:
        raise ValueError(f"body_pos_w must have shape (T, B, 3), got {body_pos_w.shape}")

    fps = float(np.asarray(motion["fps"]).reshape(-1)[0])
    body_indexes = _resolve_limb_body_indexes(motion, cfg.limb_body_names, limb_body_indexes, body_pos_w.shape[1])
    limb_pos_w = body_pos_w[:, body_indexes, :]

    target_offsets = _limb_target_offsets(cfg.ladder_geometry, cfg.limb_names, cfg.limb_target_offsets)
    target_points = _target_points(cfg.ladder_geometry, target_offsets)
    distances = np.linalg.norm(limb_pos_w[:, :, None, :] - target_points[None, :, :, :], axis=-1)
    nearest_distances = distances.min(axis=-1)
    nearest_rung_ids = distances.argmin(axis=-1).astype(np.int64)
    speeds = _finite_difference_speed(limb_pos_w, fps)
    distance_thresholds = _limb_distance_thresholds(
        cfg.distance_threshold, cfg.limb_distance_thresholds, len(cfg.limb_names)
    )

    contact_indicator = np.zeros_like(nearest_distances, dtype=bool)
    contact_rung_id = nearest_rung_ids.copy()
    raw_indicator = (nearest_distances <= distance_thresholds[None, :]) & (speeds <= cfg.speed_threshold)

    for limb_index in range(len(cfg.limb_names)):
        mask = raw_indicator[:, limb_index]
        mask = _fill_short_gaps(mask, cfg.max_gap_frames)
        mask = _remove_short_runs(mask, cfg.min_contact_frames)
        contact_indicator[:, limb_index] = mask
        contact_rung_id[:, limb_index] = _stabilize_rung_ids(
            nearest_rung_ids[:, limb_index], mask, cfg.ladder_geometry.num_rungs
        )

    labels = {
        "contact_indicator": contact_indicator.astype(np.float32),
        "contact_rung_id": contact_rung_id.astype(np.int64),
        "limb_names": np.asarray(cfg.limb_names),
        "limb_body_names": np.asarray(cfg.limb_body_names),
        "limb_body_indexes": body_indexes.astype(np.int64),
        "contact_annotation_limb_target_offsets": target_offsets,
        "contact_annotation_limb_distance_thresholds": distance_thresholds,
        "contact_nearest_distance": nearest_distances.astype(np.float32),
        "contact_speed": speeds.astype(np.float32),
        "contact_raw_indicator": raw_indicator.astype(np.float32),
        "contact_annotation_ladder_params": np.asarray(
            [
                cfg.ladder_geometry.phi,
                cfg.ladder_geometry.rung_spacing,
                cfg.ladder_geometry.rung_length,
                cfg.ladder_geometry.rung_width,
            ],
            dtype=np.float32,
        ),
        "contact_annotation_ladder_origin": np.asarray(cfg.ladder_geometry.origin, dtype=np.float32),
        "contact_annotation_ladder_num_rungs": np.asarray([cfg.ladder_geometry.num_rungs], dtype=np.int64),
        "contact_annotation_thresholds": np.asarray(
            [cfg.distance_threshold, cfg.speed_threshold, cfg.min_contact_frames, cfg.max_gap_frames],
            dtype=np.float32,
        ),
    }
    if cfg.ladder_asset_translation is not None:
        labels["contact_annotation_ladder_asset_translation"] = np.asarray(
            cfg.ladder_asset_translation, dtype=np.float32
        )
    if cfg.ladder_asset_yaw_deg is not None:
        labels["contact_annotation_ladder_asset_yaw_deg"] = np.asarray(
            [cfg.ladder_asset_yaw_deg], dtype=np.float32
        )
    if "contact_annotation_robot_grounding_z_offset" in motion:
        labels["contact_annotation_robot_grounding_z_offset"] = np.asarray(
            motion["contact_annotation_robot_grounding_z_offset"], dtype=np.float32
        )
    if "contact_annotation_robot_initial_foot_target_z" in motion:
        labels["contact_annotation_robot_initial_foot_target_z"] = np.asarray(
            motion["contact_annotation_robot_initial_foot_target_z"], dtype=np.float32
        )
    return labels


def make_contact_annotation_cfg(
    *,
    ladder_phi: float = 65.5,
    rung_spacing: float = 0.248,
    rung_length: float = 0.60,
    rung_width: float = 0.08,
    num_rungs: int = 12,
    ladder_origin: tuple[float, float, float] = (0.55, 0.0, 0.08),
    limb_body_names: Sequence[str] | None = None,
    limb_target_offsets: Sequence[Sequence[float]] | None = None,
    distance_threshold: float = 0.125,
    limb_distance_thresholds: Sequence[float] | None = None,
    speed_threshold: float = 0.35,
    min_contact_frames: int = 4,
    max_gap_frames: int = 2,
    ladder_asset_translation: tuple[float, float, float] | None = None,
    ladder_asset_yaw_deg: float | None = None,
    ground_initial_feet: bool = False,
    initial_foot_target_z: float = 0.0,
) -> ContactAnnotationCfg:
    """Create the default single-motion contact annotation config."""

    return ContactAnnotationCfg(
        ladder_geometry=generate_ladder(
            phi=ladder_phi,
            rung_spacing=rung_spacing,
            rung_length=rung_length,
            rung_radius_or_width=rung_width,
            num_rungs=num_rungs,
            origin=ladder_origin,
        ),
        limb_body_names=tuple(limb_body_names)
        if limb_body_names is not None
        else tuple(DEFAULT_LIMB_BODY_NAMES[name] for name in LIMB_NAMES),
        limb_target_offsets=(
            tuple(tuple(float(value) for value in offset) for offset in limb_target_offsets)
            if limb_target_offsets is not None
            else None
        ),
        distance_threshold=distance_threshold,
        limb_distance_thresholds=(
            tuple(float(value) for value in limb_distance_thresholds)
            if limb_distance_thresholds is not None
            else None
        ),
        speed_threshold=speed_threshold,
        min_contact_frames=min_contact_frames,
        max_gap_frames=max_gap_frames,
        ladder_asset_translation=ladder_asset_translation,
        ladder_asset_yaw_deg=ladder_asset_yaw_deg,
        ground_initial_feet=ground_initial_feet,
        initial_foot_target_z=initial_foot_target_z,
    )


def _prepare_motion(
    motion: Mapping[str, np.ndarray],
    cfg: ContactAnnotationCfg,
    limb_body_indexes: Sequence[int] | None,
) -> dict[str, np.ndarray]:
    result = {key: np.asarray(value) for key, value in motion.items()}
    if limb_body_indexes is None:
        result = _materialize_virtual_limb_bodies(result, cfg.limb_body_names)
    if cfg.ground_initial_feet:
        result = _ground_motion_at_initial_feet(
            result,
            cfg.limb_names,
            cfg.limb_body_names,
            limb_body_indexes,
            cfg.initial_foot_target_z,
        )
    return result


def _resolve_limb_body_indexes(
    motion: Mapping[str, np.ndarray],
    limb_body_names: Sequence[str],
    limb_body_indexes: Sequence[int] | None,
    num_bodies: int,
) -> np.ndarray:
    if limb_body_indexes is not None:
        indexes = np.asarray(limb_body_indexes, dtype=np.int64)
        if indexes.shape != (len(limb_body_names),):
            raise ValueError(f"expected {len(limb_body_names)} limb body indexes, got {indexes.shape}")
    else:
        if "body_names" in motion:
            body_names = _as_string_list(motion["body_names"])
        else:
            body_names = list(DEFAULT_G1_BODY_NAMES)
        missing = [name for name in limb_body_names if name not in body_names]
        if missing:
            raise ValueError(f"motion body names are missing limb bodies: {missing}")
        indexes = np.asarray([body_names.index(name) for name in limb_body_names], dtype=np.int64)

    if np.any(indexes < 0) or np.any(indexes >= num_bodies):
        raise IndexError(f"limb body indexes {indexes.tolist()} outside body_pos_w body count {num_bodies}")
    return indexes


def _as_string_list(values: np.ndarray) -> list[str]:
    items = np.asarray(values).reshape(-1).tolist()
    return [item.decode("utf-8") if isinstance(item, bytes) else str(item) for item in items]


def _materialize_virtual_limb_bodies(
    motion: Mapping[str, np.ndarray], limb_body_names: Sequence[str]
) -> dict[str, np.ndarray]:
    result = {key: np.asarray(value) for key, value in motion.items()}
    if "body_names" not in result:
        return result

    body_names = _as_string_list(result["body_names"])
    virtual_names = [
        name for name in limb_body_names if name not in body_names and name in CR1_VIRTUAL_BODY_SPECS
    ]
    if not virtual_names:
        return result
    if "body_quat_w" not in result:
        raise KeyError("motion must contain 'body_quat_w' to construct virtual sole contact points")

    body_pos_w = np.asarray(result["body_pos_w"], dtype=np.float32)
    body_quat_w = np.asarray(result["body_quat_w"], dtype=np.float32)
    if body_quat_w.shape != (*body_pos_w.shape[:2], 4):
        raise ValueError(
            f"body_quat_w must have shape {(*body_pos_w.shape[:2], 4)}, got {body_quat_w.shape}"
        )

    virtual_positions = []
    virtual_quaternions = []
    parent_indexes = []
    rotated_offsets = []
    for virtual_name in virtual_names:
        parent_name, local_offset = CR1_VIRTUAL_BODY_SPECS[virtual_name]
        if parent_name not in body_names:
            raise ValueError(f"motion body names are missing parent body '{parent_name}' for '{virtual_name}'")
        parent_index = body_names.index(parent_name)
        parent_quat_w = body_quat_w[:, parent_index, :]
        offset_w = _quat_apply_wxyz(parent_quat_w, np.asarray(local_offset, dtype=np.float32))
        virtual_positions.append(body_pos_w[:, parent_index, :] + offset_w)
        virtual_quaternions.append(parent_quat_w)
        parent_indexes.append(parent_index)
        rotated_offsets.append(offset_w)

    result["body_names"] = np.asarray(body_names + virtual_names)
    result["body_pos_w"] = np.concatenate(
        [body_pos_w, np.stack(virtual_positions, axis=1)], axis=1
    ).astype(np.float32)
    result["body_quat_w"] = np.concatenate(
        [body_quat_w, np.stack(virtual_quaternions, axis=1)], axis=1
    ).astype(np.float32)

    if "body_lin_vel_w" in result:
        body_lin_vel_w = np.asarray(result["body_lin_vel_w"], dtype=np.float32)
        if body_lin_vel_w.shape != body_pos_w.shape:
            raise ValueError(f"body_lin_vel_w must have shape {body_pos_w.shape}, got {body_lin_vel_w.shape}")
        if "body_ang_vel_w" in result:
            body_ang_vel_w = np.asarray(result["body_ang_vel_w"], dtype=np.float32)
            if body_ang_vel_w.shape != body_pos_w.shape:
                raise ValueError(f"body_ang_vel_w must have shape {body_pos_w.shape}, got {body_ang_vel_w.shape}")
            virtual_linear_velocities = [
                body_lin_vel_w[:, parent_index, :] + np.cross(body_ang_vel_w[:, parent_index, :], offset_w)
                for parent_index, offset_w in zip(parent_indexes, rotated_offsets, strict=True)
            ]
        else:
            fps = float(np.asarray(result["fps"]).reshape(-1)[0])
            virtual_linear_velocities = [_finite_difference_vectors(points, fps) for points in virtual_positions]
        result["body_lin_vel_w"] = np.concatenate(
            [body_lin_vel_w, np.stack(virtual_linear_velocities, axis=1)], axis=1
        ).astype(np.float32)

    if "body_ang_vel_w" in result:
        body_ang_vel_w = np.asarray(result["body_ang_vel_w"], dtype=np.float32)
        if body_ang_vel_w.shape != body_pos_w.shape:
            raise ValueError(f"body_ang_vel_w must have shape {body_pos_w.shape}, got {body_ang_vel_w.shape}")
        virtual_angular_velocities = body_ang_vel_w[:, parent_indexes, :]
        result["body_ang_vel_w"] = np.concatenate(
            [body_ang_vel_w, virtual_angular_velocities], axis=1
        ).astype(np.float32)

    return result


def _ground_motion_at_initial_feet(
    motion: Mapping[str, np.ndarray],
    limb_names: Sequence[str],
    limb_body_names: Sequence[str],
    limb_body_indexes: Sequence[int] | None,
    initial_foot_target_z: float,
) -> dict[str, np.ndarray]:
    result = {key: np.asarray(value) for key, value in motion.items()}
    if "contact_annotation_robot_grounding_z_offset" in result:
        return result

    foot_limb_indexes = [index for index, name in enumerate(limb_names) if name.endswith("_foot")]
    if not foot_limb_indexes:
        raise ValueError("ground_initial_feet requires at least one limb name ending in '_foot'")

    if limb_body_indexes is not None:
        indexes = np.asarray(limb_body_indexes, dtype=np.int64)
        foot_body_indexes = indexes[foot_limb_indexes]
    else:
        if "body_names" not in result:
            raise KeyError("motion must contain 'body_names' to ground initial feet")
        body_names = _as_string_list(result["body_names"])
        foot_body_names = [limb_body_names[index] for index in foot_limb_indexes]
        missing = [name for name in foot_body_names if name not in body_names]
        if missing:
            raise ValueError(f"motion body names are missing foot bodies for grounding: {missing}")
        foot_body_indexes = np.asarray([body_names.index(name) for name in foot_body_names], dtype=np.int64)

    body_pos_w = np.asarray(result["body_pos_w"], dtype=np.float32)
    initial_min_z = float(body_pos_w[0, foot_body_indexes, 2].min())
    grounding_z_offset = initial_foot_target_z - initial_min_z
    if grounding_z_offset != 0.0:
        body_pos_w = body_pos_w.copy()
        body_pos_w[..., 2] += grounding_z_offset
        result["body_pos_w"] = body_pos_w
    result["contact_annotation_robot_grounding_z_offset"] = np.asarray(
        [grounding_z_offset], dtype=np.float32
    )
    result["contact_annotation_robot_initial_foot_target_z"] = np.asarray(
        [initial_foot_target_z], dtype=np.float32
    )
    return result


def _quat_apply_wxyz(quaternions: np.ndarray, vector: np.ndarray) -> np.ndarray:
    norms = np.linalg.norm(quaternions, axis=-1, keepdims=True)
    if np.any(norms <= np.finfo(np.float32).eps):
        raise ValueError("body_quat_w contains a zero-length quaternion")
    quaternions = quaternions / norms
    vector = np.broadcast_to(vector, quaternions.shape[:-1] + (3,))
    xyz = quaternions[..., 1:]
    cross = 2.0 * np.cross(xyz, vector)
    return vector + quaternions[..., :1] * cross + np.cross(xyz, cross)


def _finite_difference_vectors(points: np.ndarray, fps: float) -> np.ndarray:
    if points.shape[0] <= 1:
        return np.zeros_like(points)
    return np.gradient(points, 1.0 / fps, axis=0).astype(np.float32)


def _limb_target_offsets(
    geometry: LadderGeometry,
    limb_names: Sequence[str],
    configured_offsets: Sequence[Sequence[float]] | None,
) -> np.ndarray:
    if configured_offsets is not None:
        offsets = np.asarray(configured_offsets, dtype=np.float32)
        expected_shape = (len(limb_names), 3)
        if offsets.shape != expected_shape:
            raise ValueError(f"limb_target_offsets must have shape {expected_shape}, got {offsets.shape}")
        return offsets

    offsets = []
    for limb_name in limb_names:
        if limb_name.startswith("left_"):
            offsets.append((0.0, geometry.lateral_contact_offset, 0.0))
        elif limb_name.startswith("right_"):
            offsets.append((0.0, -geometry.lateral_contact_offset, 0.0))
        else:
            offsets.append((0.0, 0.0, 0.0))
    return np.asarray(offsets, dtype=np.float32)


def _target_points(geometry: LadderGeometry, offsets: np.ndarray) -> np.ndarray:
    rung_positions = np.asarray([get_rung_pose(i, geometry)[0] for i in range(geometry.num_rungs)], dtype=np.float32)
    return rung_positions[None, :, :] + offsets[:, None, :]


def _limb_distance_thresholds(
    default_threshold: float,
    configured_thresholds: Sequence[float] | None,
    num_limbs: int,
) -> np.ndarray:
    if configured_thresholds is None:
        thresholds = np.full(num_limbs, default_threshold, dtype=np.float32)
    else:
        thresholds = np.asarray(configured_thresholds, dtype=np.float32)
        if thresholds.shape != (num_limbs,):
            raise ValueError(f"limb_distance_thresholds must have shape ({num_limbs},), got {thresholds.shape}")
    if np.any(thresholds <= 0.0):
        raise ValueError("limb distance thresholds must be positive")
    return thresholds


def _finite_difference_speed(points: np.ndarray, fps: float) -> np.ndarray:
    speeds = np.zeros(points.shape[:2], dtype=np.float32)
    if points.shape[0] <= 1:
        return speeds
    speeds[1:] = np.linalg.norm(points[1:] - points[:-1], axis=-1) * fps
    speeds[0] = speeds[1]
    return speeds


def _fill_short_gaps(mask: np.ndarray, max_gap_frames: int) -> np.ndarray:
    if max_gap_frames <= 0:
        return mask.copy()
    result = mask.copy()
    runs = _runs(mask)
    for value, start, end in runs:
        if value or start == 0 or end == len(mask):
            continue
        if end - start <= max_gap_frames and mask[start - 1] and mask[end]:
            result[start:end] = True
    return result


def _remove_short_runs(mask: np.ndarray, min_contact_frames: int) -> np.ndarray:
    if min_contact_frames <= 1:
        return mask.copy()
    result = mask.copy()
    for value, start, end in _runs(mask):
        if value and end - start < min_contact_frames:
            result[start:end] = False
    return result


def _stabilize_rung_ids(rung_ids: np.ndarray, contact_mask: np.ndarray, num_rungs: int) -> np.ndarray:
    result = rung_ids.copy()
    for value, start, end in _runs(contact_mask):
        if not value:
            continue
        counts = np.bincount(rung_ids[start:end], minlength=num_rungs)
        result[start:end] = int(np.argmax(counts))
    return result


def _runs(mask: np.ndarray) -> list[tuple[bool, int, int]]:
    if mask.size == 0:
        return []
    runs = []
    start = 0
    current = bool(mask[0])
    for index in range(1, len(mask)):
        value = bool(mask[index])
        if value != current:
            runs.append((current, start, index))
            start = index
            current = value
    runs.append((current, start, len(mask)))
    return runs
