from __future__ import annotations

import torch
from typing import TYPE_CHECKING

from isaaclab.managers import ManagerTermBase, SceneEntityCfg
from isaaclab.utils.math import (
    combine_frame_transforms,
    convert_camera_frame_orientation_convention,
    matrix_from_quat,
    quat_from_euler_xyz,
    quat_apply,
    sample_uniform,
    subtract_frame_transforms,
)

try:
    from isaaclab.utils.math import quat_apply_inverse
except ImportError:  # Isaac Lab 2.1 uses the equivalent legacy name.
    from isaaclab.utils.math import quat_rotate_inverse as quat_apply_inverse

from ladder.tasks.ladder_climb.mdp.commands import LadderMotionCommand
from ladder.robots.cr1 import CR1_ACTION_SCALE, CR1_URDF
from ladder.utils.contact_schema import CR1_VIRTUAL_BODY_SPECS
from ladder.utils.limb_heightmaps import (
    LADDER_OTHER,
    RAIL as HEIGHTMAP_RAIL,
    RUNG as HEIGHTMAP_RUNG,
    LimbHeightMapCfg,
    heightmap_cache_is_current,
    sample_limb_heightmap,
)
from ladder.utils.visual_depth import process_visual_depth, process_warp_visual_depth
from ladder.utils.warp_camera import CR1WarpBatchCamera, RUNG, ROBOT, WarpCameraCfg
from ladder.utils.wood_step_ladder import WOOD_STEP_RUNG_BOX_NAMES

if TYPE_CHECKING:
    from isaaclab.envs import ManagerBasedEnv


CR1_TRANSFORMER_VISION_ANGULAR_VELOCITY_SCALE = 0.2
CR1_TRANSFORMER_VISION_JOINT_VELOCITY_SCALE = 0.1
CR1_TRANSFORMER_VISION_PROPRIO_CLIP = 100.0


def climb_direction(env: ManagerBasedEnv, direction: float = 1.0) -> torch.Tensor:
    """Return the deployable binary climbing-direction command."""

    if direction not in (-1.0, 1.0):
        raise ValueError(f"Climbing direction must be -1 or 1, got {direction}")
    return torch.full((env.num_envs, 1), direction, device=env.device)


def visual_depth(
    env: ManagerBasedEnv,
    sensor_cfg: SceneEntityCfg,
    min_depth: float = 0.1,
    max_depth: float = 2.0,
    gaussian_std: float = 0.005,
    pixel_dropout_probability: float = 0.05,
    rung_focused_mask_probability: float = 0.1,
) -> torch.Tensor:
    """Return augmented depth in the NCHW layout expected by RSL-RL CNNs."""

    from ladder.utils.visual_depth import DepthAugmentationCfg

    camera = env.scene.sensors[sensor_cfg.name]
    cfg = DepthAugmentationCfg(
        min_depth=min_depth,
        max_depth=max_depth,
        gaussian_std=gaussian_std,
        pixel_dropout_probability=pixel_dropout_probability,
        rung_focused_mask_probability=rung_focused_mask_probability,
    )
    depth, _ = process_visual_depth(
        camera.data.output["distance_to_image_plane"],
        camera.data.output["semantic_segmentation"],
        camera.data.info.get("semantic_segmentation"),
        cfg,
    )
    # The SSR history term is evaluated after this actor depth group.  Reuse
    # this exact augmented frame rather than rendering the camera a second time.
    env._cr1_visual_depth_frame = depth
    return depth


def cr1_transformer_vision_proprio_frame(
    env: ManagerBasedEnv, climb_direction_value: float = 1.0
) -> torch.Tensor:
    """Return the field-normalized 85-D CR1 proprioceptive frame.

    The frame contains root angular velocity (3), root orientation (6), all
    joint positions (25), joint velocities (25), the previous action (25),
    and climbing direction (1). Following the X2 visual reference, angular
    velocity is multiplied by 0.2, joint-position error is divided by the
    per-joint action scale, and joint velocity is multiplied by 0.1. Rotation,
    action, and direction are already bounded representations and stay
    unchanged. The final vector is clipped to [-100, 100].
    """

    robot = env.scene.articulations["robot"]
    joint_position_scale = getattr(env, "_cr1_transformer_vision_joint_position_scale", None)
    if joint_position_scale is None:
        joint_names = tuple(robot.joint_names)
        missing = [name for name in joint_names if name not in CR1_ACTION_SCALE]
        if missing:
            raise KeyError(f"Missing CR1 TransformerVision joint-position scales for: {missing}")
        joint_position_scale = torch.tensor(
            [CR1_ACTION_SCALE[name] for name in joint_names],
            dtype=robot.data.joint_pos.dtype,
            device=robot.data.joint_pos.device,
        ).unsqueeze(0)
        if joint_position_scale.shape[-1] != robot.data.joint_pos.shape[-1]:
            raise RuntimeError(
                "CR1 TransformerVision joint-position scale count does not match the articulation: "
                f"{joint_position_scale.shape[-1]} != {robot.data.joint_pos.shape[-1]}"
            )
        env._cr1_transformer_vision_joint_position_scale = joint_position_scale

    frame = torch.cat(
        (
            robot.data.root_ang_vel_b * CR1_TRANSFORMER_VISION_ANGULAR_VELOCITY_SCALE,
            root_orientation_6d(env),
            (robot.data.joint_pos - robot.data.default_joint_pos) / joint_position_scale,
            robot.data.joint_vel * CR1_TRANSFORMER_VISION_JOINT_VELOCITY_SCALE,
            env.action_manager.action,
            climb_direction(env, direction=climb_direction_value),
        ),
        dim=-1,
    )
    return torch.clamp(
        frame,
        min=-CR1_TRANSFORMER_VISION_PROPRIO_CLIP,
        max=CR1_TRANSFORMER_VISION_PROPRIO_CLIP,
    )


def cr1_transformer_vision_base_lin_vel_target(env: ManagerBasedEnv) -> torch.Tensor:
    """Return the body-frame root linear velocity used by the velocity head."""

    return env.scene.articulations["robot"].data.root_lin_vel_b


class cr1_transformer_vision_history(ManagerTermBase):
    """Maintain synchronized proprioceptive and depth histories for TransformerVision.

    The manager executes the existing actor depth group first.  This term then
    consumes that cached frame, so the 2-frame encoder input is exactly the
    depth seen by the current visual baseline and no additional RTX/Warp render
    is performed.  Reset environments receive repeated current frames instead
    of zero-filled temporal inputs.
    """

    def __init__(self, cfg, env: ManagerBasedEnv):
        super().__init__(cfg, env)
        params = cfg.params
        self._num_proprio_frames = int(params.get("num_proprio_frames", 10))
        self._num_depth_frames = int(params.get("num_depth_frames", 2))
        self._depth_height = int(params.get("depth_height", 60))
        self._depth_width = int(params.get("depth_width", 80))
        self._climb_direction_value = float(params.get("climb_direction_value", 1.0))
        if self._num_proprio_frames <= 0 or self._num_depth_frames <= 0:
            raise ValueError("TransformerVision history lengths must be positive")

        proprio_dim = cr1_transformer_vision_proprio_frame(
            env, climb_direction_value=self._climb_direction_value
        ).shape[1]
        self._proprio_history = torch.zeros(
            (env.num_envs, self._num_proprio_frames, proprio_dim),
            dtype=torch.float32,
            device=env.device,
        )
        self._depth_history = torch.zeros(
            (env.num_envs, self._num_depth_frames, self._depth_height, self._depth_width),
            dtype=torch.float32,
            device=env.device,
        )
        self._pending_reset = torch.ones(env.num_envs, dtype=torch.bool, device=env.device)
        self._last_update_step: int | None = None

    def reset(self, env_ids=None) -> None:
        if env_ids is None:
            self._pending_reset.fill_(True)
            return
        env_ids = torch.as_tensor(env_ids, dtype=torch.long, device=self.device)
        self._pending_reset[env_ids] = True

    def __call__(
        self,
        env: ManagerBasedEnv,
        num_proprio_frames: int = 10,
        num_depth_frames: int = 2,
        depth_height: int = 60,
        depth_width: int = 80,
        climb_direction_value: float = 1.0,
    ) -> torch.Tensor:
        """Return `[B, 10, 85]` proprio history and refresh the depth history."""

        self._validate_runtime_parameters(
            num_proprio_frames,
            num_depth_frames,
            depth_height,
            depth_width,
            climb_direction_value,
        )
        depth = getattr(env, "_cr1_visual_depth_frame", None)
        if depth is None:
            raise RuntimeError(
                "TransformerVision history requires transformer_vision_depth to run before transformer_vision_inputs"
            )
        expected_depth_shape = (env.num_envs, 1, self._depth_height, self._depth_width)
        if tuple(depth.shape) != expected_depth_shape:
            raise RuntimeError(
                f"Expected cached visual depth shape {expected_depth_shape}, got {tuple(depth.shape)}"
            )
        proprio = cr1_transformer_vision_proprio_frame(
            env, climb_direction_value=self._climb_direction_value
        )
        if proprio.shape[-1] != self._proprio_history.shape[-1]:
            raise RuntimeError(
                "CR1 TransformerVision proprioceptive dimension changed after history initialization: "
                f"expected {self._proprio_history.shape[-1]}, got {proprio.shape[-1]}"
            )

        current_step = int(env.common_step_counter)
        if self._last_update_step != current_step:
            self._update(proprio, depth[:, 0])
            self._last_update_step = current_step
        elif torch.any(self._pending_reset):
            self._fill_reset_histories(proprio, depth[:, 0])

        env._cr1_transformer_vision_history_cache = {
            "depth_history": self._depth_history,
        }
        return self._proprio_history

    def _validate_runtime_parameters(
        self,
        num_proprio_frames: int,
        num_depth_frames: int,
        depth_height: int,
        depth_width: int,
        climb_direction_value: float,
    ) -> None:
        configured = (
            self._num_proprio_frames,
            self._num_depth_frames,
            self._depth_height,
            self._depth_width,
            self._climb_direction_value,
        )
        received = (
            int(num_proprio_frames),
            int(num_depth_frames),
            int(depth_height),
            int(depth_width),
            float(climb_direction_value),
        )
        if received != configured:
            raise RuntimeError("TransformerVision history parameters changed after initialization")

    def _update(self, proprio: torch.Tensor, depth: torch.Tensor) -> None:
        continuing = ~self._pending_reset
        if torch.any(continuing):
            self._shift(self._proprio_history, proprio, continuing)
            self._shift(self._depth_history, depth, continuing)
        self._fill_reset_histories(proprio, depth)

    def _fill_reset_histories(self, proprio: torch.Tensor, depth: torch.Tensor) -> None:
        if not torch.any(self._pending_reset):
            return
        env_ids = self._pending_reset.nonzero(as_tuple=False).squeeze(-1)
        self._proprio_history[env_ids] = proprio[env_ids, None, :].expand(
            -1, self._num_proprio_frames, -1
        )
        self._depth_history[env_ids] = depth[env_ids, None, :, :].expand(
            -1, self._num_depth_frames, -1, -1
        )
        self._pending_reset[env_ids] = False

    @staticmethod
    def _shift(history: torch.Tensor, frame: torch.Tensor, mask: torch.Tensor) -> None:
        env_ids = mask.nonzero(as_tuple=False).squeeze(-1)
        selected = history[env_ids]
        selected[:, :-1].copy_(selected[:, 1:].clone())
        selected[:, -1].copy_(frame[env_ids])
        history[env_ids] = selected


def cr1_transformer_vision_depth_history(env: ManagerBasedEnv) -> torch.Tensor:
    """Return the depth history prepared by :class:`cr1_transformer_vision_history`."""

    cache = getattr(env, "_cr1_transformer_vision_history_cache", None)
    if cache is None:
        raise RuntimeError("TransformerVision depth history must follow TransformerVision proprio history")
    return cache["depth_history"]


# Compatibility aliases for the retired prototype task. New code must use the
# TransformerVision names above and must not depend on these aliases.
cr1_ssr_proprio_frame = cr1_transformer_vision_proprio_frame
cr1_ssr_base_lin_vel_target = cr1_transformer_vision_base_lin_vel_target
cr1_ssr_visual_history = cr1_transformer_vision_history
cr1_ssr_depth_history = cr1_transformer_vision_depth_history


def _compute_cr1_limb_heightmap_target(
    env: ManagerBasedEnv,
    robot_name: str = "robot",
    ladder_name: str = "ladder",
    rows: int = 10,
    columns: int = 3,
    x_extent: float = 0.315,
    y_extent: float = 0.160,
    ground_height: float = -0.03,
    ray_start_height: float = 2.0,
    max_ray_distance: float = 4.0,
    output: str = "relative_height_m",
) -> torch.Tensor:
    """Return CR1's four-limb relative-height targets for auxiliary training.

    The returned tensor is ``[B, 4, rows, columns]`` in the fixed order
    ``left_hand, right_hand, left_foot, right_foot``.  Hand references are
    sphere centers and foot references are the virtual sole points.  Rays and
    grid axes remain aligned with world gravity and world X/Y; limb rotations
    are not used to rotate the map.  ``hit_valid`` is returned as a float mask
    when requested and must mask the later reconstruction loss.
    """

    if output not in ("relative_height_m", "hit_valid", "hit_class"):
        raise ValueError(f"Unsupported CR1 limb height-map output: {output!r}")

    current_step = int(env.common_step_counter)
    cache = getattr(env, "_cr1_limb_heightmap_target_cache", None)
    if heightmap_cache_is_current(
        cache, common_step_counter=current_step, output=output
    ):
        return cache[output]

    robot = env.scene.articulations[robot_name]
    ladder = env.scene.rigid_object_collections[ladder_name]
    device = robot.data.body_pos_w.device
    dtype = robot.data.body_pos_w.dtype

    centers = []
    for side in ("left", "right"):
        hand_index = robot.body_names.index(f"{side}_sphere_hand_link")
        centers.append(robot.data.body_pos_w[:, hand_index])

    for side in ("left", "right"):
        sole_name = f"{side}_sole_contact_point"
        ankle_name, sole_offset = CR1_VIRTUAL_BODY_SPECS[sole_name]
        ankle_index = robot.body_names.index(ankle_name)
        offset = torch.as_tensor(sole_offset, dtype=dtype, device=device).expand(
            robot.data.body_pos_w.shape[0], -1
        )
        centers.append(
            robot.data.body_pos_w[:, ankle_index]
            + quat_apply(robot.data.body_quat_w[:, ankle_index], offset)
        )
    limb_centers_w = torch.stack(centers, dim=1)

    from ladder.tasks.ladder_climb.config.cr1.wood_step_geometry_dr_env_cfg import (
        WOOD_STEP_BOX_SPECS,
    )

    specs_by_name = {spec.name: spec for spec in WOOD_STEP_BOX_SPECS}
    missing = sorted(set(ladder.object_names) - set(specs_by_name))
    if missing:
        raise ValueError(f"Missing CR1 wood-step box specs for runtime objects: {missing}")
    box_sizes = torch.as_tensor(
        [specs_by_name[name].size for name in ladder.object_names],
        dtype=dtype,
        device=device,
    )
    box_classes = torch.tensor(
        [
            HEIGHTMAP_RUNG
            if name in WOOD_STEP_RUNG_BOX_NAMES
            else HEIGHTMAP_RAIL
            if name.startswith("front_zigzag_side_board_")
            else LADDER_OTHER
            for name in ladder.object_names
        ],
        dtype=torch.long,
        device=device,
    )
    map_cfg = LimbHeightMapCfg(
        rows=rows,
        columns=columns,
        x_extent=x_extent,
        y_extent=y_extent,
        ray_start_height=ray_start_height,
        max_ray_distance=max_ray_distance,
    )
    ground_height_w = torch.full(
        (env.num_envs,), ground_height, dtype=dtype, device=device
    )
    maps = [
        sample_limb_heightmap(
            limb_centers_w=limb_centers_w[:, index],
            box_positions_w=ladder.data.object_pos_w,
            box_quaternions_wxyz=ladder.data.object_quat_w,
            box_sizes=box_sizes,
            box_classes=box_classes,
            cfg=map_cfg,
            ground_height_w=ground_height_w,
        )
        for index in range(4)
    ]
    cache = {
        "common_step_counter": current_step,
        "relative_height_m": torch.stack(
            [height_map.relative_height_m for height_map in maps], dim=1
        ),
        "hit_valid": torch.stack(
            [height_map.hit_valid for height_map in maps], dim=1
        ).to(dtype=dtype),
        "hit_class": torch.stack(
            [height_map.hit_class for height_map in maps], dim=1
        ),
        # Diagnostic geometry for placing target and predicted relative maps
        # back on the same world-XY sampling grids. These keys are not exposed
        # as policy or critic observations.
        "plane_points_w": torch.stack(
            [height_map.plane_points_w for height_map in maps], dim=1
        ),
    }
    env._cr1_limb_heightmap_target_cache = cache
    return cache[output]


class cr1_limb_heightmap_target(ManagerTermBase):
    """Share one limb-map ray query within a step and invalidate it on reset."""

    def __init__(self, cfg, env: ManagerBasedEnv):
        super().__init__(cfg, env)

    def reset(self, env_ids=None) -> None:
        # A manual reset can occur without advancing common_step_counter. Clear
        # the shared cache so the post-reset observation cannot reuse geometry
        # from the previous episode.
        self._env._cr1_limb_heightmap_target_cache = None

    def __call__(
        self,
        env: ManagerBasedEnv,
        robot_name: str = "robot",
        ladder_name: str = "ladder",
        rows: int = 10,
        columns: int = 3,
        x_extent: float = 0.315,
        y_extent: float = 0.160,
        ground_height: float = -0.03,
        ray_start_height: float = 2.0,
        max_ray_distance: float = 4.0,
        output: str = "relative_height_m",
    ) -> torch.Tensor:
        return _compute_cr1_limb_heightmap_target(
            env,
            robot_name=robot_name,
            ladder_name=ladder_name,
            rows=rows,
            columns=columns,
            x_extent=x_extent,
            y_extent=y_extent,
            ground_height=ground_height,
            ray_start_height=ray_start_height,
            max_ray_distance=max_ray_distance,
            output=output,
        )


class warp_visual_depth(ManagerTermBase):
    """GPU-resident Warp depth/RFM observation for the CR1 visual policy.

    This replaces only the RTX camera source.  The actor still receives the
    same processed NCHW depth format and the critic remains privileged.
    """

    def __init__(self, cfg, env: ManagerBasedEnv):
        super().__init__(cfg, env)
        from ladder.tasks.ladder_climb.config.cr1.wood_step_env_cfg import CR1_GROUND_Z
        from ladder.tasks.ladder_climb.config.cr1.wood_step_geometry_dr_env_cfg import (
            WOOD_STEP_BOX_SPECS,
        )

        params = cfg.params
        self._robot_name = str(params.get("robot_name", "robot"))
        self._ladder_name = str(params.get("ladder_name", "ladder"))
        self._camera_body_name = str(params.get("camera_body_name", "d435_head_link"))
        self._augmentation_cfg = _visual_depth_augmentation_cfg(params)
        self._ground_height = float(params.get("ground_height", CR1_GROUND_Z))
        self._translation_range = tuple(params.get("translation_range", (-0.01, 0.01)))
        self._rotation_range = tuple(params.get("rotation_range", (-0.0261799388, 0.0261799388)))
        if len(self._translation_range) != 2 or len(self._rotation_range) != 2:
            raise ValueError("Warp camera translation and rotation ranges must each have two values")

        camera_cfg = WarpCameraCfg(
            width=int(params.get("width", 80)),
            height=int(params.get("height", 60)),
            horizontal_fov_deg=float(params.get("horizontal_fov_deg", 87.0)),
            vertical_fov_deg=float(params.get("vertical_fov_deg", 58.0)),
            min_depth=self._augmentation_cfg.min_depth,
            max_depth=self._augmentation_cfg.max_depth,
        )
        robot = env.scene.articulations[self._robot_name]
        ladder = env.scene.rigid_object_collections[self._ladder_name]
        if self._camera_body_name not in robot.body_names:
            raise ValueError(f"Unknown Warp camera body {self._camera_body_name!r}")
        self._camera_body_id = robot.body_names.index(self._camera_body_name)
        self._renderer = CR1WarpBatchCamera(
            camera_cfg,
            num_envs=env.num_envs,
            robot_urdf=CR1_URDF,
            robot_body_names=robot.body_names,
            ladder_box_specs=WOOD_STEP_BOX_SPECS,
            ladder_object_names=ladder.object_names,
            rung_box_names=WOOD_STEP_RUNG_BOX_NAMES,
            device=env.device,
        )
        self._local_camera_positions = torch.zeros((env.num_envs, 3), device=env.device)
        self._local_camera_quaternions = torch.zeros((env.num_envs, 4), device=env.device)
        self._local_camera_quaternions[:, 0] = 1.0
        self._sample_camera_extrinsics(torch.arange(env.num_envs, device=env.device))

    def reset(self, env_ids=None) -> None:
        if env_ids is None:
            env_ids = torch.arange(self.num_envs, device=self.device)
        else:
            env_ids = torch.as_tensor(env_ids, dtype=torch.long, device=self.device)
        self._sample_camera_extrinsics(env_ids)

    def __call__(
        self,
        env: ManagerBasedEnv,
        robot_name: str = "robot",
        ladder_name: str = "ladder",
        camera_body_name: str = "d435_head_link",
        width: int = 80,
        height: int = 60,
        horizontal_fov_deg: float = 87.0,
        vertical_fov_deg: float = 58.0,
        min_depth: float = 0.1,
        max_depth: float = 2.0,
        gaussian_std: float = 0.005,
        pixel_dropout_probability: float = 0.05,
        rung_focused_mask_probability: float = 0.1,
        translation_range: tuple[float, float] = (-0.01, 0.01),
        rotation_range: tuple[float, float] = (-0.0261799388, 0.0261799388),
    ) -> torch.Tensor:
        """Render the current batch.

        IsaacLab passes ``ObservationTermCfg.params`` to every invocation of a
        stateful term as well as to its constructor, and its 2.1 manager
        validates the full explicit signature. Configuration is consumed once
        in ``__init__``; the repeated parameters are intentionally unused.
        """
        robot = env.scene.articulations[self._robot_name]
        ladder = env.scene.rigid_object_collections[self._ladder_name]
        positions, quaternions = combine_frame_transforms(
            robot.data.body_pos_w[:, self._camera_body_id],
            robot.data.body_quat_w[:, self._camera_body_id],
            self._local_camera_positions,
            self._local_camera_quaternions,
        )
        camera_quaternions_opengl = convert_camera_frame_orientation_convention(
            quaternions, origin="world", target="opengl"
        ).contiguous()
        output = self._renderer.render(
            camera_positions_w=positions.contiguous(),
            camera_quaternions_wxyz_opengl=camera_quaternions_opengl,
            robot_body_positions_w=robot.data.body_pos_w,
            robot_body_quaternions_wxyz=robot.data.body_quat_w,
            ladder_positions_w=ladder.data.object_pos_w,
            ladder_quaternions_wxyz=ladder.data.object_quat_w,
            ground_height=self._ground_height,
        )
        depth, _ = process_warp_visual_depth(
            output.depth,
            output.hit_class,
            rung_class=RUNG,
            robot_class=ROBOT,
            cfg=self._augmentation_cfg,
        )
        env._cr1_visual_depth_frame = depth
        return depth

    def _sample_camera_extrinsics(self, env_ids: torch.Tensor) -> None:
        count = env_ids.numel()
        self._local_camera_positions[env_ids] = sample_uniform(
            self._translation_range[0],
            self._translation_range[1],
            (count, 3),
            device=self.device,
        )
        local_rpy = sample_uniform(
            self._rotation_range[0],
            self._rotation_range[1],
            (count, 3),
            device=self.device,
        )
        self._local_camera_quaternions[env_ids] = quat_from_euler_xyz(
            local_rpy[:, 0], local_rpy[:, 1], local_rpy[:, 2]
        )


def _visual_depth_augmentation_cfg(params: dict) -> object:
    """Build the shared paper-aligned augmentation configuration from term params."""

    from ladder.utils.visual_depth import DepthAugmentationCfg

    return DepthAugmentationCfg(
        min_depth=float(params.get("min_depth", 0.1)),
        max_depth=float(params.get("max_depth", 2.0)),
        gaussian_std=float(params.get("gaussian_std", 0.005)),
        pixel_dropout_probability=float(params.get("pixel_dropout_probability", 0.05)),
        rung_focused_mask_probability=float(params.get("rung_focused_mask_probability", 0.1)),
    )


def ladder_params(env: ManagerBasedEnv, command_name: str) -> torch.Tensor:
    command: LadderMotionCommand = env.command_manager.get_term(command_name)
    return command.ladder_params


def contact_indicator(env: ManagerBasedEnv, command_name: str) -> torch.Tensor:
    command: LadderMotionCommand = env.command_manager.get_term(command_name)
    return command.contact_indicator


def contact_rung_id(env: ManagerBasedEnv, command_name: str) -> torch.Tensor:
    command: LadderMotionCommand = env.command_manager.get_term(command_name)
    return command.contact_rung_id.float() / max(command.ladder_geometry.num_rungs - 1, 1)


def reference_joint_pos(env: ManagerBasedEnv, command_name: str) -> torch.Tensor:
    command: LadderMotionCommand = env.command_manager.get_term(command_name)
    return command.joint_pos


def reference_joint_vel(env: ManagerBasedEnv, command_name: str) -> torch.Tensor:
    command: LadderMotionCommand = env.command_manager.get_term(command_name)
    return command.joint_vel


def motion_phase(env: ManagerBasedEnv, command_name: str) -> torch.Tensor:
    command: LadderMotionCommand = env.command_manager.get_term(command_name)
    denominator = max(command.motion.time_step_total - 1, 1)
    return (command.time_steps.float() / denominator).unsqueeze(-1)


def reference_body_pos_b(env: ManagerBasedEnv, command_name: str) -> torch.Tensor:
    """Reference tracked-body positions expressed in the reference root frame."""

    command: LadderMotionCommand = env.command_manager.get_term(command_name)
    num_bodies = len(command.cfg.body_names)
    pos_b, _ = subtract_frame_transforms(
        command.body_pos_w[:, :1, :].repeat(1, num_bodies, 1),
        command.body_quat_w[:, :1, :].repeat(1, num_bodies, 1),
        command.body_pos_w,
        command.body_quat_w,
    )
    return pos_b.reshape(env.num_envs, -1)


def root_orientation_6d(
    env: ManagerBasedEnv, asset_cfg: SceneEntityCfg = SceneEntityCfg("robot")
) -> torch.Tensor:
    asset = env.scene[asset_cfg.name]
    rotation = matrix_from_quat(asset.data.root_quat_w)
    return rotation[..., :2].reshape(env.num_envs, -1)


def ladder_relative_root_pos(env: ManagerBasedEnv, command_name: str) -> torch.Tensor:
    """Robot root position in the sampled ladder axial/lateral/normal frame."""

    command: LadderMotionCommand = env.command_manager.get_term(command_name)
    relative = command.robot.data.root_pos_w - command.ladder_origins_w
    if command.cfg.ladder_relative_observation_frame == "world":
        return relative
    if command.cfg.ladder_relative_observation_frame != "ladder":
        raise ValueError(
            "ladder_relative_observation_frame must be 'world' or 'ladder', got "
            f"{command.cfg.ladder_relative_observation_frame!r}"
        )
    cosine = torch.cos(command.ladder_phi)
    sine = torch.sin(command.ladder_phi)
    axial = relative[:, 0] * cosine + relative[:, 2] * sine
    normal = -relative[:, 0] * sine + relative[:, 2] * cosine
    return torch.stack((axial, relative[:, 1], normal), dim=-1)


def target_contact_pos_b(env: ManagerBasedEnv, command_name: str) -> torch.Tensor:
    command: LadderMotionCommand = env.command_manager.get_term(command_name)
    target_pos_b, _ = subtract_frame_transforms(
        command.robot_anchor_pos_w[:, None, :].repeat(1, len(command.limb_names), 1),
        command.robot_anchor_quat_w[:, None, :].repeat(1, len(command.limb_names), 1),
        command.target_contact_pos_w,
        None,
    )
    return target_pos_b.reshape(env.num_envs, -1)


def contact_error_b(env: ManagerBasedEnv, command_name: str) -> torch.Tensor:
    command: LadderMotionCommand = env.command_manager.get_term(command_name)
    anchor_pos_w = command.robot_anchor_pos_w[:, None, :].repeat(1, len(command.limb_names), 1)
    anchor_quat_w = command.robot_anchor_quat_w[:, None, :].repeat(1, len(command.limb_names), 1)
    limb_pos_b, _ = subtract_frame_transforms(
        anchor_pos_w,
        anchor_quat_w,
        command.robot_limb_pos_w,
        None,
    )
    target_pos_b, _ = subtract_frame_transforms(
        anchor_pos_w,
        command.robot_anchor_quat_w[:, None, :].repeat(1, len(command.limb_names), 1),
        command.target_contact_pos_w,
        None,
    )
    return (target_pos_b - limb_pos_b).reshape(env.num_envs, -1)


def robot_body_pos_b(env: ManagerBasedEnv, command_name: str) -> torch.Tensor:
    command: LadderMotionCommand = env.command_manager.get_term(command_name)
    num_bodies = len(command.cfg.body_names)
    pos_b, _ = subtract_frame_transforms(
        command.robot_body_pos_w[:, :1, :].repeat(1, num_bodies, 1),
        command.robot_body_quat_w[:, :1, :].repeat(1, num_bodies, 1),
        command.robot_body_pos_w,
        command.robot_body_quat_w,
    )
    return pos_b.view(env.num_envs, -1)


def robot_body_lin_vel_b(env: ManagerBasedEnv, command_name: str) -> torch.Tensor:
    command: LadderMotionCommand = env.command_manager.get_term(command_name)
    num_bodies = len(command.cfg.body_names)
    root_quat_w = command.robot_body_quat_w[:, :1, :].repeat(1, num_bodies, 1)
    return quat_apply_inverse(root_quat_w, command.robot_body_lin_vel_w).reshape(env.num_envs, -1)


def reference_body_lin_vel_b(env: ManagerBasedEnv, command_name: str) -> torch.Tensor:
    command: LadderMotionCommand = env.command_manager.get_term(command_name)
    num_bodies = len(command.cfg.body_names)
    root_quat_w = command.body_quat_w[:, :1, :].repeat(1, num_bodies, 1)
    return quat_apply_inverse(root_quat_w, command.body_lin_vel_w).reshape(env.num_envs, -1)


def body_pos_error_b(env: ManagerBasedEnv, command_name: str) -> torch.Tensor:
    return robot_body_pos_b(env, command_name) - reference_body_pos_b(env, command_name)


def body_lin_vel_error_b(env: ManagerBasedEnv, command_name: str) -> torch.Tensor:
    return robot_body_lin_vel_b(env, command_name) - reference_body_lin_vel_b(env, command_name)


def joint_pos_error(env: ManagerBasedEnv, command_name: str) -> torch.Tensor:
    command: LadderMotionCommand = env.command_manager.get_term(command_name)
    return command.robot_joint_pos - command.joint_pos


def robot_body_ori_b(env: ManagerBasedEnv, command_name: str) -> torch.Tensor:
    command: LadderMotionCommand = env.command_manager.get_term(command_name)
    num_bodies = len(command.cfg.body_names)
    _, ori_b = subtract_frame_transforms(
        command.robot_anchor_pos_w[:, None, :].repeat(1, num_bodies, 1),
        command.robot_anchor_quat_w[:, None, :].repeat(1, num_bodies, 1),
        command.robot_body_pos_w,
        command.robot_body_quat_w,
    )
    mat = matrix_from_quat(ori_b)
    return mat[..., :2].reshape(mat.shape[0], -1)


def motion_anchor_pos_b(env: ManagerBasedEnv, command_name: str) -> torch.Tensor:
    command: LadderMotionCommand = env.command_manager.get_term(command_name)
    pos, _ = subtract_frame_transforms(
        command.robot_anchor_pos_w,
        command.robot_anchor_quat_w,
        command.anchor_pos_w,
        command.anchor_quat_w,
    )
    return pos.view(env.num_envs, -1)


def motion_anchor_ori_b(env: ManagerBasedEnv, command_name: str) -> torch.Tensor:
    command: LadderMotionCommand = env.command_manager.get_term(command_name)
    _, ori = subtract_frame_transforms(
        command.robot_anchor_pos_w,
        command.robot_anchor_quat_w,
        command.anchor_pos_w,
        command.anchor_quat_w,
    )
    mat = matrix_from_quat(ori)
    return mat[..., :2].reshape(mat.shape[0], -1)
