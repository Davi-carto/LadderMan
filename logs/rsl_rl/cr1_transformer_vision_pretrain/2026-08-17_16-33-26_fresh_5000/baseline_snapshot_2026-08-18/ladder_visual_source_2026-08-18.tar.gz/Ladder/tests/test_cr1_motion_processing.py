from pathlib import Path
from xml.etree import ElementTree

import numpy as np

from ladder.utils.urdf_kinematics import forward_kinematics


REPO_ROOT = Path(__file__).resolve().parents[2]
CR1_URDF = (
    REPO_ROOT
    / "assets"
    / "robots"
    / "CR1-B2-PRO-260608"
    / "CR1-B2-pro_free_wrist_fixed_spherehand.urdf"
)


def test_cr1_urdf_has_25_actuated_joints_and_current_contact_bodies():
    root = ElementTree.parse(CR1_URDF).getroot()
    actuated = [
        joint.attrib["name"]
        for joint in root.findall("joint")
        if joint.attrib.get("type") not in ("fixed", "floating")
    ]
    links = {link.attrib["name"] for link in root.findall("link")}

    assert len(actuated) == 25
    assert {
        "left_wrist_x_link",
        "right_wrist_x_link",
        "left_sphere_hand_link",
        "right_sphere_hand_link",
        "left_sole_contact_point",
        "right_sole_contact_point",
    } <= links


def test_offline_urdf_fk_matches_existing_isaaclab_export():
    motion_file = (
        REPO_ROOT
        / "Ladder"
        / "motions"
        / "climing_ladder_cr1_downsample4_motion_annotated_wrist_d0145_v035.npz"
    )
    with np.load(motion_file, allow_pickle=False) as motion:
        frame_ids = np.asarray([0, 200, 400, 727])
        joint_names = motion["joint_names"].tolist()
        body_names = motion["body_names"].tolist()
        root_index = body_names.index("base_link")
        body_pos_w, body_quat_w = forward_kinematics(
            CR1_URDF,
            motion["body_pos_w"][frame_ids, root_index],
            motion["body_quat_w"][frame_ids, root_index],
            motion["joint_pos"][frame_ids],
            joint_names,
            body_names,
        )

        assert np.allclose(body_pos_w, motion["body_pos_w"][frame_ids], atol=2.0e-6)
        alignment = np.abs(np.sum(body_quat_w * motion["body_quat_w"][frame_ids], axis=-1))
        assert np.all(alignment > 1.0 - 5.0e-7)


def test_group_smoothed_50hz_motion_is_training_shaped_and_finite():
    motion_file = (
        REPO_ROOT
        / "Ladder"
        / "motions"
        / "climing_ladder_cr1_leg3hz_other5hz_50fps_annotated_wrist_d0145_v035.npz"
    )
    with np.load(motion_file, allow_pickle=False) as motion:
        assert motion["fps"].tolist() == [50.0]
        assert motion["joint_pos"].shape == (1213, 25)
        assert motion["body_pos_w"].shape == (1213, 42, 3)
        assert motion["contact_indicator"].shape == (1213, 4)
        assert motion["contact_rung_id"].shape == (1213, 4)
        for key in (
            "joint_pos",
            "joint_vel",
            "body_pos_w",
            "body_quat_w",
            "body_lin_vel_w",
            "body_ang_vel_w",
            "contact_indicator",
        ):
            assert np.isfinite(motion[key]).all()
        assert motion["contact_annotation_ladder_num_rungs"].tolist() == [7]
        assert np.allclose(motion["contact_annotation_ladder_origin"], [0.445, 0.04, 0.19])
        assert motion["motion_processing_joint_cutoff_hz"].tolist() == [5.0]
        assert motion["motion_processing_leg_joint_cutoff_hz"].tolist() == [3.0]


def test_contact_transition_frames_are_stable_for_fixed_frame_smoke_checks():
    motion_file = (
        REPO_ROOT
        / "Ladder"
        / "motions"
        / "climing_ladder_cr1_leg3hz_other5hz_50fps_annotated_wrist_d0145_v035.npz"
    )
    expected = {
        "left_hand": [228, 368, 389, 631, 661, 910, 932, 1079],
        "right_hand": [235, 244, 282, 499, 524, 776, 799, 1082],
        "left_foot": [344, 561, 597, 844, 881],
        "right_foot": [470, 701, 744, 976, 1021],
    }
    with np.load(motion_file, allow_pickle=False) as motion:
        indicator = motion["contact_indicator"] > 0.5
        for limb_index, limb_name in enumerate(motion["limb_names"].tolist()):
            transitions = np.flatnonzero(indicator[1:, limb_index] != indicator[:-1, limb_index]) + 1
            assert transitions.tolist() == expected[limb_name]


def test_arc_length_retimed_preview_distributes_hand_motion_and_preserves_start():
    motion_file = (
        REPO_ROOT
        / "Ladder"
        / "motions"
        / "restored_prefix_v300_stride2_slow50"
        / "smooth_start"
        / "reference_repaired"
        / "climing_ladder_cr1_f300_2604_slow50_smooth_start_terminal_arc_uniform_contact_safe_preview.npz"
    )
    segments = (
        (440, 555, "right_sphere_hand_link"),
        (830, 1000, "right_sphere_hand_link"),
        (1121, 1193, "left_sphere_hand_link"),
    )
    with np.load(motion_file, allow_pickle=False) as motion:
        assert motion["joint_pos"].shape == (1386, 25)
        assert np.all(np.diff(motion["arc_retime_source_time"]) > 0.0)
        assert np.all(motion["joint_pos"][:25] == motion["joint_pos"][0])
        assert np.all(motion["contact_rung_id"][motion["contact_indicator"] <= 0.5] == -1)

        body_names = motion["body_names"].tolist()
        for start, end, body_name in segments:
            body_pos = motion["body_pos_w"][start : end + 1, body_names.index(body_name)]
            step_distance = np.linalg.norm(np.diff(body_pos, axis=0), axis=-1)
            assert step_distance.max() / step_distance.mean() < 2.0
