import sys
from pathlib import Path

import numpy as np


SCRIPTS_DIR = Path(__file__).resolve().parents[1] / "scripts"
if str(SCRIPTS_DIR) not in sys.path:
    sys.path.insert(0, str(SCRIPTS_DIR))

from stabilize_cr1_contact_motion import (
    _contact_anchors_and_weights,
    _refine_initial_root_xy,
    _solve_root_translation,
)


def test_contact_anchor_weights_blend_and_use_run_median():
    positions = np.zeros((20, 2, 3), dtype=np.float64)
    positions[2:18, 0, 0] = np.linspace(0.0, 0.03, 16)
    contact = np.zeros((20, 2), dtype=bool)
    contact[2:18, 0] = True

    anchors, weights = _contact_anchors_and_weights(positions, contact)

    assert np.allclose(anchors[2:18, 0, 0], 0.015)
    assert weights[2, 0] == 0.0
    assert weights[17, 0] == 0.0
    assert weights[:, 1].sum() == 0.0
    assert weights[:, 0].max() == 1.0


def test_root_translation_reduces_weighted_stance_error():
    positions = np.zeros((40, 2, 3), dtype=np.float64)
    positions[5:35, 0, 0] = np.linspace(-0.02, 0.02, 30)
    contact = np.zeros((40, 2), dtype=bool)
    contact[5:35, 0] = True
    anchors, weights = _contact_anchors_and_weights(positions, contact)

    correction = _solve_root_translation(positions, anchors, weights)

    before = weights[..., None] * (positions - anchors)
    after = weights[..., None] * (positions + correction[:, None, :] - anchors)
    assert correction.shape == (40, 3)
    assert np.isfinite(correction).all()
    assert np.linalg.norm(after) < np.linalg.norm(before)


def test_contact_at_trajectory_boundary_does_not_blend_in():
    positions = np.zeros((100, 2, 3), dtype=np.float64)
    contact = np.zeros((100, 2), dtype=bool)
    contact[:85, 1] = True

    _, weights = _contact_anchors_and_weights(positions, contact)

    assert weights[0, 1] == 1.0
    assert weights[50, 1] == 1.0
    assert weights[84, 1] == 0.0


def test_initial_root_xy_refinement_preserves_boundaries_and_z():
    frame_count = 120
    time = np.arange(frame_count, dtype=np.float64) / 50.0
    root_pos = np.zeros((frame_count, 3), dtype=np.float64)
    root_pos[:, 1] = 0.08 * np.sin(2.0 * np.pi * 0.8 * time)
    root_pos[:, 2] = np.linspace(0.8, 1.0, frame_count)

    refined = _refine_initial_root_xy(root_pos, 50.0)

    assert np.allclose(refined[0], root_pos[0])
    assert np.allclose(refined[:, 2], root_pos[:, 2])
    assert np.allclose(refined[81:], root_pos[81:])
    assert np.linalg.norm(np.diff(refined[:51, :2], axis=0), axis=1).sum() < np.linalg.norm(
        np.diff(root_pos[:51, :2], axis=0), axis=1
    ).sum()
