from types import SimpleNamespace

import torch
from tensordict import TensorDict

from rsl_rl.runners import OnPolicyRunner

from ladder.rsl_rl.algorithms import (
    TRANSFORMER_VISION_DATA_CONTRACT,
    TransformerVisionPPO,
    TransformerVisionPretrainer,
)
from ladder.rsl_rl.modules import TransformerVisionActor, TransformerVisionEncoder
from ladder.rsl_rl.runners import TransformerVisionPPOVecEnvWrapper


def _observations(num_envs: int = 2, critic_dim: int = 17) -> TensorDict:
    history = torch.rand(num_envs, 10, 85)
    return TensorDict(
        {
            "transformer_vision_current_proprio": history[:, -1].clone(),
            "transformer_vision_proprio_history": history,
            "transformer_vision_depth_history": torch.rand(num_envs, 2, 60, 80),
            "transformer_vision_limb_heightmaps": torch.rand(num_envs, 4, 10, 3),
            "transformer_vision_heightmap_valid": torch.ones(num_envs, 4, 10, 3),
            "transformer_vision_heightmap_hit_class": torch.randint(0, 5, (num_envs, 4, 10, 3)),
            "transformer_vision_velocity_target": torch.rand(num_envs, 3),
            "transformer_vision_next_proprio_target": torch.rand(num_envs, 85),
            "critic": torch.rand(num_envs, critic_dim),
        },
        batch_size=[num_envs],
    )


def _raw_observations(num_envs: int = 2, critic_dim: int = 17) -> dict:
    observations = _observations(num_envs, critic_dim)
    return {
        "transformer_vision_inputs": {
            "proprio_history": observations["transformer_vision_proprio_history"],
            "depth_history": observations["transformer_vision_depth_history"],
        },
        "transformer_vision_targets": {
            "relative_height": observations["transformer_vision_limb_heightmaps"],
            "hit_valid": observations["transformer_vision_heightmap_valid"],
            "hit_class": observations["transformer_vision_heightmap_hit_class"],
        },
        "transformer_vision_auxiliary_targets": {
            "base_lin_vel": observations["transformer_vision_velocity_target"],
            "next_proprio": observations["transformer_vision_next_proprio_target"],
        },
        "critic": observations["critic"],
    }


def _visual_checkpoint(tmp_path) -> str:
    encoder = TransformerVisionEncoder()
    payload = TransformerVisionPretrainer(encoder).state_dict()
    path = tmp_path / "visual_pretrain.pt"
    torch.save(payload, path)
    return str(path)


def _config(visual_checkpoint: str, num_steps: int = 2) -> dict:
    return {
        "num_steps_per_env": num_steps,
        "multi_gpu": None,
        "policy": {
            "init_noise_std": 1.0,
            "actor_hidden_dims": [32, 16],
            "critic_hidden_dims": [32, 16],
        },
        "algorithm": {
            "class_name": "ladder.rsl_rl.algorithms:TransformerVisionPPO",
            "num_learning_epochs": 1,
            "num_mini_batches": 1,
            "clip_param": 0.2,
            "gamma": 0.99,
            "lam": 0.95,
            "value_loss_coef": 1.0,
            "entropy_coef": 0.005,
            "learning_rate": 1.0e-3,
            "auxiliary_learning_rate": 1.0e-3,
            "auxiliary_mini_batch_envs": 2,
            "auxiliary_num_epochs": 1,
            "max_grad_norm": 1.0,
            "use_clipped_value_loss": True,
            "schedule": "adaptive",
            "desired_kl": 0.01,
            "normalize_advantage_per_mini_batch": False,
            "visual_checkpoint": visual_checkpoint,
            "rnd_cfg": None,
            "symmetry_cfg": None,
        },
    }


def _algorithm(tmp_path) -> TransformerVisionPPO:
    observations = _observations()
    environment = SimpleNamespace(num_envs=2, num_actions=25)
    return TransformerVisionPPO.construct_algorithm(
        observations,
        environment,
        _config(_visual_checkpoint(tmp_path)),
        "cpu",
    )


def _collect_two_steps(algorithm: TransformerVisionPPO) -> TensorDict:
    observations = _observations()
    algorithm.act(observations)
    next_observations = _observations()
    algorithm.process_env_step(
        next_observations,
        torch.ones(2),
        torch.tensor([False, True]),
        {},
    )
    assert torch.count_nonzero(algorithm.visual_hidden_state[:, 1]) == 0
    algorithm.act(next_observations)
    final_observations = _observations()
    algorithm.process_env_step(
        final_observations,
        torch.ones(2),
        torch.zeros(2, dtype=torch.bool),
        {},
    )
    return final_observations


def test_actor_uses_current_frame_plus_51_latent_and_resets_inference_state():
    actor = TransformerVisionActor(actor_hidden_dims=(32, 16)).eval()
    observations = _observations()

    actions = actor(observations)
    assert actions.shape == (2, 25)
    assert actor.action_mlp[0].in_features == 136
    assert actor._inference_hidden_state.shape == (1, 2, 256)
    assert torch.count_nonzero(actor._inference_hidden_state) > 0

    actor.reset(torch.tensor([False, True]))
    assert torch.count_nonzero(actor._inference_hidden_state[:, 0]) > 0
    assert torch.count_nonzero(actor._inference_hidden_state[:, 1]) == 0


def test_ppo_uses_fixed_rollout_latent_and_optimizer_boundaries(tmp_path):
    torch.manual_seed(19)
    algorithm = _algorithm(tmp_path)
    final_observations = _collect_two_steps(algorithm)
    assert algorithm.storage.actor_inputs.shape[-1] == 136
    torch.testing.assert_close(
        algorithm.storage.actor_inputs[0, :, :85],
        algorithm.storage.proprio_history[0, :, -1],
    )
    assert algorithm.rollout_log_prob_max_error().item() < 1.0e-5
    algorithm.compute_returns(final_observations)

    visual_before = [parameter.detach().clone() for parameter in algorithm.policy.encoder.parameters()]
    algorithm._ppo_update()
    assert torch.all(algorithm.policy.output_std >= 0.2)
    for parameter, previous in zip(algorithm.policy.encoder.parameters(), visual_before, strict=True):
        torch.testing.assert_close(parameter, previous)

    actor_before_aux = [parameter.detach().clone() for parameter in algorithm.policy.action_mlp.parameters()]
    auxiliary = algorithm._auxiliary_update()
    assert auxiliary["aux_total"] > 0.0
    assert any(
        not torch.equal(parameter, previous)
        for parameter, previous in zip(algorithm.policy.encoder.parameters(), visual_before, strict=True)
    )
    for parameter, previous in zip(algorithm.policy.action_mlp.parameters(), actor_before_aux, strict=True):
        torch.testing.assert_close(parameter, previous)


def test_checkpoint_reload_preserves_deterministic_visual_policy(tmp_path):
    torch.manual_seed(20)
    algorithm = _algorithm(tmp_path)
    final_observations = _collect_two_steps(algorithm)
    algorithm.compute_returns(final_observations)
    losses = algorithm.update()
    assert all(torch.isfinite(torch.tensor(value)) for value in losses.values())

    payload = algorithm.save()
    assert payload["data_contract"] == TRANSFORMER_VISION_DATA_CONTRACT
    restored = _algorithm(tmp_path)
    restored.load(payload, load_cfg=None, strict=True)
    algorithm.reset_inference()
    restored.reset_inference()
    torch.testing.assert_close(
        algorithm.act_inference(final_observations),
        restored.act_inference(final_observations),
    )


def test_vector_wrapper_exposes_current_frame_without_old_660d_policy():
    raw_observations = _raw_observations()

    class _FakeEnv:
        def __init__(self):
            self.unwrapped = SimpleNamespace(
                num_envs=2,
                device="cpu",
                max_episode_length=100,
                action_manager=SimpleNamespace(total_action_dim=25),
                cfg=SimpleNamespace(is_finite_horizon=True),
                episode_length_buf=torch.zeros(2, dtype=torch.long),
                observation_manager=SimpleNamespace(compute=lambda: raw_observations),
            )

        def reset(self):
            return raw_observations, {}

        def step(self, actions):
            return (
                raw_observations,
                torch.ones(2),
                torch.zeros(2, dtype=torch.bool),
                torch.zeros(2, dtype=torch.bool),
                {},
            )

        def close(self):
            pass

    wrapper = TransformerVisionPPOVecEnvWrapper(_FakeEnv())
    packed = wrapper.get_observations()
    assert "policy" not in packed
    assert packed["transformer_vision_current_proprio"].shape == (2, 85)
    torch.testing.assert_close(
        packed["transformer_vision_current_proprio"],
        packed["transformer_vision_proprio_history"][:, -1],
    )


def test_constructs_through_installed_rsl_runner(tmp_path):
    raw_observations = _raw_observations()

    class _FakeEnv:
        def __init__(self):
            self.unwrapped = SimpleNamespace(
                num_envs=2,
                device="cpu",
                max_episode_length=100,
                action_manager=SimpleNamespace(total_action_dim=25),
                cfg=SimpleNamespace(is_finite_horizon=True),
                episode_length_buf=torch.zeros(2, dtype=torch.long),
                observation_manager=SimpleNamespace(compute=lambda: raw_observations),
            )

        def reset(self):
            return raw_observations, {}

        def step(self, actions):
            return (
                raw_observations,
                torch.ones(2),
                torch.zeros(2, dtype=torch.bool),
                torch.zeros(2, dtype=torch.bool),
                {},
            )

        def close(self):
            pass

    config = _config(_visual_checkpoint(tmp_path))
    config.update({"save_interval": 100, "logger": "tensorboard"})
    runner = OnPolicyRunner(
        TransformerVisionPPOVecEnvWrapper(_FakeEnv()),
        config,
        log_dir=None,
        device="cpu",
    )
    runner.learn(num_learning_iterations=1)
    assert runner.current_learning_iteration == 0
