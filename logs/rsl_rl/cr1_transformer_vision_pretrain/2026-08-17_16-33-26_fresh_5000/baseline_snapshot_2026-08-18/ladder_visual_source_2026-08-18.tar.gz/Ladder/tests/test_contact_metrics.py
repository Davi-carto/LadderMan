import pytest


torch = pytest.importorskip("torch")

from ladder.utils.contact_metrics import classify_limb_contacts


def test_contact_metrics_separate_reference_required_from_physical_and_target_contact():
    indicator = torch.tensor([[1.0, 0.0, 1.0]])
    positions = torch.tensor([[[0.00, 0.0, 0.0], [0.0, 0.0, 0.0], [0.10, 0.0, 0.0]]])
    targets = torch.zeros_like(positions)
    forces = torch.tensor([[[6.0, 0.0, 0.0], [8.0, 0.0, 0.0], [6.0, 0.0, 0.0]]])

    required, physical, target = classify_limb_contacts(
        indicator, positions, targets, forces, torch.tensor([0.05, 0.05, 0.05]), 5.0
    )

    assert required.tolist() == [[True, False, True]]
    assert physical.tolist() == [[True, True, True]]
    assert target.tolist() == [[True, False, False]]


def test_contact_metrics_reject_invalid_thresholds():
    values = torch.zeros((1, 1, 3))
    with pytest.raises(ValueError, match="force_threshold"):
        classify_limb_contacts(torch.ones((1, 1)), values, values, values, 0.1, -1.0)
    with pytest.raises(ValueError, match="positive"):
        classify_limb_contacts(torch.ones((1, 1)), values, values, values, 0.0, 5.0)
