"""Reduce CR1 stance-foot drift with smooth root translation and leg-only IK."""

from __future__ import annotations

import argparse
import sys
from pathlib import Path
from xml.etree import ElementTree

import numpy as np
from scipy.signal import butter, sosfiltfilt
from scipy.sparse import diags
from scipy.sparse.linalg import spsolve


REPO_ROOT = Path(__file__).resolve().parents[2]
SOURCE_DIR = REPO_ROOT / "Ladder" / "source" / "ladder"
if str(SOURCE_DIR) not in sys.path:
    sys.path.insert(0, str(SOURCE_DIR))

from ladder.utils.urdf_kinematics import finite_difference, forward_kinematics, quaternion_angular_velocity


DEFAULT_ROBOT = (
    REPO_ROOT
    / "assets"
    / "robots"
    / "CR1-B2-PRO-260608"
    / "CR1-B2-pro_free_wrist_fixed_spherehand.urdf"
)
FOOT_BODY_NAMES = ("left_sole_contact_point", "right_sole_contact_point")
ARM_BODY_NAMES = ("left_sphere_hand_link", "right_sphere_hand_link")
LEG_JOINT_NAMES = (
    (
        "left_hip_y_joint",
        "left_hip_x_joint",
        "left_hip_z_joint",
        "left_knee_joint",
        "left_ankle_y_joint",
        "left_ankle_x_joint",
    ),
    (
        "right_hip_y_joint",
        "right_hip_x_joint",
        "right_hip_z_joint",
        "right_knee_joint",
        "right_ankle_y_joint",
        "right_ankle_x_joint",
    ),
)
ARM_JOINT_NAMES = (
    (
        "left_shoulder_y_joint",
        "left_shoulder_x_joint",
        "left_shoulder_z_joint",
        "left_elbow_joint",
    ),
    (
        "right_shoulder_y_joint",
        "right_shoulder_x_joint",
        "right_shoulder_z_joint",
        "right_elbow_joint",
    ),
)

BLEND_FRAMES = 15
ROOT_MAGNITUDE_WEIGHT = 0.5
ROOT_VELOCITY_WEIGHT = 1.0
ROOT_ACCELERATION_WEIGHT = 10.0
IK_ITERATIONS = 5
IK_DAMPING = 1.0e-4
IK_MAX_STEP = 0.04
IK_CORRECTION_CUTOFF_HZ = 2.5
JACOBIAN_EPSILON = 1.0e-4
INITIAL_RIGHT_STANCE_END_FRAME = 85
INITIAL_ROOT_FILTER_END_FRAME = 51
INITIAL_ROOT_FILTER_BLEND_FRAMES = 30
INITIAL_ROOT_XY_CUTOFF_HZ = 0.5
INITIAL_ROOT_XY_CORRECTION_SCALE = 0.75


def _parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--input_file", type=Path, required=True, help="Smoothed annotated CR1 motion.")
    parser.add_argument("--output_file", type=Path, required=True, help="Contact-aware output motion.")
    parser.add_argument("--robot_asset", type=Path, default=DEFAULT_ROBOT, help="CR1 URDF used for offline FK.")
    parser.add_argument(
        "--refine_initial_right_stance",
        action="store_true",
        help="Reduce initial root XY sway and stabilize the right sole on the ground through frame 84.",
    )
    parser.add_argument(
        "--leg_only_xy",
        action="store_true",
        help="Keep the root and sole Z unchanged; reduce stance-foot XY drift using only the corresponding leg.",
    )
    parser.add_argument("--overwrite", action="store_true", help="Overwrite output_file if it exists.")
    return parser.parse_args()


def _as_names(values: np.ndarray) -> list[str]:
    items = np.asarray(values).reshape(-1).tolist()
    return [item.decode("utf-8") if isinstance(item, bytes) else str(item) for item in items]


def _runs(mask: np.ndarray) -> list[tuple[int, int]]:
    edges = np.diff(np.concatenate(([False], mask, [False])).astype(np.int8))
    return list(zip(np.flatnonzero(edges == 1), np.flatnonzero(edges == -1), strict=True))


def _contact_anchors_and_weights(
    foot_positions: np.ndarray,
    contact_indicator: np.ndarray,
) -> tuple[np.ndarray, np.ndarray]:
    anchors = np.zeros_like(foot_positions, dtype=np.float64)
    weights = np.zeros(contact_indicator.shape, dtype=np.float64)
    for foot_index in range(len(FOOT_BODY_NAMES)):
        for start, end in _runs(contact_indicator[:, foot_index]):
            anchors[start:end, foot_index] = np.median(foot_positions[start:end, foot_index], axis=0)
            run_length = end - start
            blend_frames = min(BLEND_FRAMES, max(2, run_length // 3))
            blend_up = 0.5 - 0.5 * np.cos(np.linspace(0.0, np.pi, blend_frames))
            run_weights = np.ones(run_length, dtype=np.float64)
            if start > 0:
                run_weights[:blend_frames] = blend_up
            if end < contact_indicator.shape[0]:
                run_weights[-blend_frames:] = np.minimum(run_weights[-blend_frames:], blend_up[::-1])
            weights[start:end, foot_index] = run_weights
    return anchors, weights


def _refine_initial_root_xy(root_pos: np.ndarray, fps: float) -> np.ndarray:
    required_frames = INITIAL_ROOT_FILTER_END_FRAME + INITIAL_ROOT_FILTER_BLEND_FRAMES
    if root_pos.shape[0] < required_frames:
        raise ValueError(
            f"initial stance refinement requires at least {required_frames} frames, got {root_pos.shape[0]}"
        )

    root_filter = butter(4, INITIAL_ROOT_XY_CUTOFF_HZ, fs=fps, output="sos")
    filtered_xy = sosfiltfilt(root_filter, root_pos[:, :2], axis=0)
    correction = filtered_xy - root_pos[:, :2]
    correction = (correction - correction[0]) * INITIAL_ROOT_XY_CORRECTION_SCALE

    blend = np.zeros(root_pos.shape[0], dtype=np.float64)
    blend[:INITIAL_ROOT_FILTER_END_FRAME] = 1.0
    blend_end = INITIAL_ROOT_FILTER_END_FRAME + INITIAL_ROOT_FILTER_BLEND_FRAMES
    blend[INITIAL_ROOT_FILTER_END_FRAME:blend_end] = 0.5 + 0.5 * np.cos(
        np.linspace(0.0, np.pi, INITIAL_ROOT_FILTER_BLEND_FRAMES)
    )

    result = root_pos.copy()
    result[:, :2] += correction * blend[:, None]
    return result


def _refine_initial_right_stance(
    robot_asset: Path,
    root_pos: np.ndarray,
    root_quat: np.ndarray,
    source_joint_pos: np.ndarray,
    source_joint_names: list[str],
    fps: float,
) -> tuple[np.ndarray, np.ndarray, np.ndarray]:
    if root_pos.shape[0] < INITIAL_RIGHT_STANCE_END_FRAME:
        raise ValueError(
            "initial right-stance refinement requires at least "
            f"{INITIAL_RIGHT_STANCE_END_FRAME} frames, got {root_pos.shape[0]}"
        )

    hand_targets = _arm_positions(
        robot_asset, root_pos, root_quat, source_joint_pos, source_joint_names
    )
    refined_root_pos = _refine_initial_root_xy(root_pos, fps)
    foot_positions = _foot_positions(
        robot_asset, refined_root_pos, root_quat, source_joint_pos, source_joint_names
    )
    initial_contact = np.zeros((root_pos.shape[0], len(FOOT_BODY_NAMES)), dtype=bool)
    initial_contact[:INITIAL_RIGHT_STANCE_END_FRAME, 1] = True
    anchors, weights = _contact_anchors_and_weights(foot_positions, initial_contact)

    # The requested cleanup is planar; retain the reference sole height instead of locking it.
    anchors[:INITIAL_RIGHT_STANCE_END_FRAME, 1, 2] = foot_positions[
        :INITIAL_RIGHT_STANCE_END_FRAME, 1, 2
    ]
    refined_source_joint_pos = _apply_leg_ik(
        robot_asset,
        refined_root_pos,
        root_quat,
        source_joint_pos,
        source_joint_names,
        anchors,
        weights,
        fps,
    )
    refined_source_joint_pos = _apply_arm_ik(
        robot_asset,
        refined_root_pos,
        root_quat,
        refined_source_joint_pos,
        source_joint_names,
        hand_targets,
        fps,
    )
    return refined_root_pos, refined_source_joint_pos, weights


def _solve_root_translation(
    foot_positions: np.ndarray,
    anchors: np.ndarray,
    weights: np.ndarray,
) -> np.ndarray:
    frame_count = foot_positions.shape[0]
    first_difference = diags(
        (-np.ones(frame_count - 1), np.ones(frame_count - 1)),
        (0, 1),
        shape=(frame_count - 1, frame_count),
        format="csc",
    )
    second_difference = diags(
        (np.ones(frame_count - 2), -2.0 * np.ones(frame_count - 2), np.ones(frame_count - 2)),
        (0, 1, 2),
        shape=(frame_count - 2, frame_count),
        format="csc",
    )
    system = (
        diags(weights.sum(axis=1) + ROOT_MAGNITUDE_WEIGHT, 0, format="csc")
        + ROOT_VELOCITY_WEIGHT * (first_difference.T @ first_difference)
        + ROOT_ACCELERATION_WEIGHT * (second_difference.T @ second_difference)
    )
    target = np.sum(weights[..., None] * (anchors - foot_positions), axis=1)
    return np.stack([spsolve(system, target[:, axis]) for axis in range(3)], axis=1)


def _foot_positions(
    robot_asset: Path,
    root_pos: np.ndarray,
    root_quat: np.ndarray,
    source_joint_pos: np.ndarray,
    source_joint_names: list[str],
) -> np.ndarray:
    positions, _ = forward_kinematics(
        robot_asset,
        root_pos,
        root_quat,
        source_joint_pos,
        source_joint_names,
        ["base_link", *FOOT_BODY_NAMES],
    )
    return positions[:, 1:]


def _arm_positions(
    robot_asset: Path,
    root_pos: np.ndarray,
    root_quat: np.ndarray,
    source_joint_pos: np.ndarray,
    source_joint_names: list[str],
) -> np.ndarray:
    positions, _ = forward_kinematics(
        robot_asset,
        root_pos,
        root_quat,
        source_joint_pos,
        source_joint_names,
        ["base_link", *ARM_BODY_NAMES],
    )
    return positions[:, 1:]


def _apply_leg_ik(
    robot_asset: Path,
    root_pos: np.ndarray,
    root_quat: np.ndarray,
    source_joint_pos: np.ndarray,
    source_joint_names: list[str],
    anchors: np.ndarray,
    weights: np.ndarray,
    fps: float,
) -> np.ndarray:
    result = source_joint_pos.copy()
    leg_indexes = [[source_joint_names.index(name) for name in names] for names in LEG_JOINT_NAMES]
    correction_filter = butter(4, IK_CORRECTION_CUTOFF_HZ, fs=fps, output="sos")

    for _ in range(IK_ITERATIONS):
        current_feet = _foot_positions(robot_asset, root_pos, root_quat, result, source_joint_names)
        for foot_index, joint_indexes in enumerate(leg_indexes):
            active_frames = np.flatnonzero(weights[:, foot_index] > 0.0)
            if active_frames.size == 0:
                continue
            error = anchors[:, foot_index] - current_feet[:, foot_index]
            jacobian = np.zeros((result.shape[0], 3, len(joint_indexes)), dtype=np.float64)
            for column, joint_index in enumerate(joint_indexes):
                perturbed = result.copy()
                perturbed[:, joint_index] += JACOBIAN_EPSILON
                perturbed_feet = _foot_positions(
                    robot_asset, root_pos, root_quat, perturbed, source_joint_names
                )
                jacobian[:, :, column] = (
                    perturbed_feet[:, foot_index] - current_feet[:, foot_index]
                ) / JACOBIAN_EPSILON

            raw_correction = np.zeros((result.shape[0], len(joint_indexes)), dtype=np.float64)
            for frame in active_frames:
                frame_jacobian = jacobian[frame]
                damped_system = frame_jacobian @ frame_jacobian.T + IK_DAMPING * np.eye(3)
                correction = frame_jacobian.T @ np.linalg.solve(damped_system, error[frame])
                raw_correction[frame] = (
                    np.clip(correction, -IK_MAX_STEP, IK_MAX_STEP) * weights[frame, foot_index]
                )

            for column, joint_index in enumerate(joint_indexes):
                smooth_correction = sosfiltfilt(correction_filter, raw_correction[:, column])
                result[:, joint_index] += smooth_correction * weights[:, foot_index]
    return result


def _apply_arm_ik(
    robot_asset: Path,
    root_pos: np.ndarray,
    root_quat: np.ndarray,
    source_joint_pos: np.ndarray,
    source_joint_names: list[str],
    hand_targets: np.ndarray,
    fps: float,
) -> np.ndarray:
    result = source_joint_pos.copy()
    arm_indexes = [[source_joint_names.index(name) for name in names] for names in ARM_JOINT_NAMES]
    correction_filter = butter(4, IK_CORRECTION_CUTOFF_HZ, fs=fps, output="sos")

    for _ in range(IK_ITERATIONS):
        current_hands = _arm_positions(robot_asset, root_pos, root_quat, result, source_joint_names)
        for arm_index, joint_indexes in enumerate(arm_indexes):
            error = hand_targets[:, arm_index] - current_hands[:, arm_index]
            jacobian = np.zeros((result.shape[0], 3, len(joint_indexes)), dtype=np.float64)
            for column, joint_index in enumerate(joint_indexes):
                perturbed = result.copy()
                perturbed[:, joint_index] += JACOBIAN_EPSILON
                perturbed_hands = _arm_positions(
                    robot_asset, root_pos, root_quat, perturbed, source_joint_names
                )
                jacobian[:, :, column] = (
                    perturbed_hands[:, arm_index] - current_hands[:, arm_index]
                ) / JACOBIAN_EPSILON

            raw_correction = np.zeros((result.shape[0], len(joint_indexes)), dtype=np.float64)
            for frame in range(result.shape[0]):
                frame_jacobian = jacobian[frame]
                damped_system = frame_jacobian @ frame_jacobian.T + IK_DAMPING * np.eye(3)
                correction = frame_jacobian.T @ np.linalg.solve(damped_system, error[frame])
                raw_correction[frame] = np.clip(correction, -IK_MAX_STEP, IK_MAX_STEP)

            for column, joint_index in enumerate(joint_indexes):
                result[:, joint_index] += sosfiltfilt(correction_filter, raw_correction[:, column])
    return result


def _validate_joint_limits(
    robot_asset: Path,
    source_joint_pos: np.ndarray,
    source_joint_names: list[str],
) -> None:
    joints = {joint.attrib["name"]: joint for joint in ElementTree.parse(robot_asset).getroot().findall("joint")}
    violations = []
    for index, name in enumerate(source_joint_names):
        limit = joints[name].find("limit")
        lower = float(limit.attrib["lower"])
        upper = float(limit.attrib["upper"])
        if np.any((source_joint_pos[:, index] < lower) | (source_joint_pos[:, index] > upper)):
            violations.append(name)
    if violations:
        raise ValueError(f"contact-aware IK exceeded URDF limits: {violations}")


def _maximum_contact_range(
    foot_positions: np.ndarray,
    contact_indicator: np.ndarray,
    weights: np.ndarray | None = None,
) -> np.ndarray:
    ranges = []
    for foot_index in range(len(FOOT_BODY_NAMES)):
        for start, end in _runs(contact_indicator[:, foot_index]):
            indexes = np.arange(start, end)
            if weights is not None:
                indexes = indexes[weights[start:end, foot_index] > 0.9]
            if indexes.size > 1:
                ranges.append(np.ptp(foot_positions[indexes, foot_index], axis=0))
    return np.max(ranges, axis=0) if ranges else np.zeros(3)


def main() -> None:
    args = _parse_args()
    if args.leg_only_xy and args.refine_initial_right_stance:
        raise ValueError("--leg_only_xy cannot be combined with --refine_initial_right_stance")
    input_file = args.input_file.expanduser().resolve()
    output_file = args.output_file.expanduser().resolve()
    robot_asset = args.robot_asset.expanduser().resolve()
    if not input_file.is_file():
        raise FileNotFoundError(input_file)
    if not robot_asset.is_file():
        raise FileNotFoundError(robot_asset)
    if output_file.exists() and not args.overwrite:
        raise FileExistsError(f"Output file exists: {output_file}. Pass --overwrite to replace it.")

    with np.load(input_file, allow_pickle=False) as data:
        motion = {key: data[key] for key in data.files}
    required = (
        "fps",
        "joint_pos",
        "joint_names",
        "source_joint_names",
        "body_pos_w",
        "body_quat_w",
        "body_names",
        "contact_indicator",
        "limb_names",
    )
    missing = [key for key in required if key not in motion]
    if missing:
        raise KeyError(f"input motion is missing keys: {missing}")
    if _as_names(motion["limb_names"]) != ["left_hand", "right_hand", "left_foot", "right_foot"]:
        raise ValueError("expected canonical CR1 limb order")

    fps = float(np.asarray(motion["fps"]).reshape(-1)[0])
    joint_names = _as_names(motion["joint_names"])
    source_joint_names = _as_names(motion["source_joint_names"])
    body_names = _as_names(motion["body_names"])
    root_index = body_names.index("base_link")
    root_pos = np.asarray(motion["body_pos_w"][:, root_index], dtype=np.float64)
    root_quat = np.asarray(motion["body_quat_w"][:, root_index], dtype=np.float64)
    source_joint_pos = np.asarray(motion["joint_pos"], dtype=np.float64)[
        :, [joint_names.index(name) for name in source_joint_names]
    ]
    foot_contact = np.asarray(motion["contact_indicator"][:, 2:4] > 0.5)

    original_feet = _foot_positions(robot_asset, root_pos, root_quat, source_joint_pos, source_joint_names)
    anchors, weights = _contact_anchors_and_weights(original_feet, foot_contact)
    if args.leg_only_xy:
        anchors[..., 2] = original_feet[..., 2]
        corrected_root_pos = root_pos.copy()
    else:
        root_correction = _solve_root_translation(original_feet, anchors, weights)
        corrected_root_pos = root_pos + root_correction
    corrected_source_joint_pos = _apply_leg_ik(
        robot_asset,
        corrected_root_pos,
        root_quat,
        source_joint_pos,
        source_joint_names,
        anchors,
        weights,
        fps,
    )
    initial_stance_weights = None
    if args.refine_initial_right_stance:
        corrected_root_pos, corrected_source_joint_pos, initial_stance_weights = _refine_initial_right_stance(
            robot_asset,
            corrected_root_pos,
            root_quat,
            corrected_source_joint_pos,
            source_joint_names,
            fps,
        )
    _validate_joint_limits(robot_asset, corrected_source_joint_pos, source_joint_names)

    body_pos_w, body_quat_w = forward_kinematics(
        robot_asset,
        corrected_root_pos,
        root_quat,
        corrected_source_joint_pos,
        source_joint_names,
        body_names,
    )
    corrected_joint_pos = corrected_source_joint_pos[
        :, [source_joint_names.index(name) for name in joint_names]
    ].astype(np.float32)
    total_root_correction = corrected_root_pos - root_pos
    total_joint_correction = corrected_source_joint_pos - source_joint_pos
    output = {
        "fps": np.asarray([fps], dtype=np.float32),
        "joint_pos": corrected_joint_pos,
        "joint_vel": finite_difference(corrected_joint_pos, fps),
        "body_pos_w": body_pos_w,
        "body_quat_w": body_quat_w,
        "body_lin_vel_w": finite_difference(body_pos_w, fps),
        "body_ang_vel_w": quaternion_angular_velocity(body_quat_w, fps),
        "joint_names": np.asarray(joint_names),
        "body_names": np.asarray(body_names),
        "source_joint_names": np.asarray(source_joint_names),
        "contact_stabilization_source_file": np.asarray([str(input_file)]),
        "contact_stabilization_blend_frames": np.asarray([BLEND_FRAMES], dtype=np.int64),
        "contact_stabilization_root_weights": np.asarray(
            [ROOT_MAGNITUDE_WEIGHT, ROOT_VELOCITY_WEIGHT, ROOT_ACCELERATION_WEIGHT], dtype=np.float32
        ),
        "contact_stabilization_ik_params": np.asarray(
            [IK_ITERATIONS, IK_DAMPING, IK_MAX_STEP, IK_CORRECTION_CUTOFF_HZ], dtype=np.float32
        ),
        "contact_stabilization_root_delta_rms": np.asarray(
            [np.sqrt(np.mean(np.square(total_root_correction)))], dtype=np.float32
        ),
        "contact_stabilization_root_delta_max": np.asarray(
            [np.max(np.linalg.norm(total_root_correction, axis=1))], dtype=np.float32
        ),
        "contact_stabilization_joint_delta_rms": np.asarray(
            [np.sqrt(np.mean(np.square(total_joint_correction)))], dtype=np.float32
        ),
        "contact_stabilization_joint_delta_max": np.asarray(
            [np.max(np.abs(total_joint_correction))], dtype=np.float32
        ),
    }
    if args.refine_initial_right_stance:
        output["contact_stabilization_initial_right_stance_end_frame"] = np.asarray(
            [INITIAL_RIGHT_STANCE_END_FRAME], dtype=np.int64
        )
        output["contact_stabilization_initial_root_filter_params"] = np.asarray(
            [
                INITIAL_ROOT_FILTER_END_FRAME,
                INITIAL_ROOT_FILTER_BLEND_FRAMES,
                INITIAL_ROOT_XY_CUTOFF_HZ,
                INITIAL_ROOT_XY_CORRECTION_SCALE,
            ],
            dtype=np.float32,
        )
    for key, value in motion.items():
        if key.startswith(("motion_conversion_", "motion_processing_")):
            output[key] = value
    for key, value in output.items():
        if np.issubdtype(value.dtype, np.number) and not np.isfinite(value).all():
            raise ValueError(f"non-finite output: {key}")

    corrected_feet = body_pos_w[:, [body_names.index(name) for name in FOOT_BODY_NAMES]]
    output_file.parent.mkdir(parents=True, exist_ok=True)
    np.savez(output_file, **output)
    print(f"[INFO] Wrote contact-aware motion: {output_file}")
    print(
        "[INFO] Maximum stance-foot XYZ range: "
        f"{(_maximum_contact_range(original_feet, foot_contact) * 100).round(3).tolist()} -> "
        f"{(_maximum_contact_range(corrected_feet, foot_contact) * 100).round(3).tolist()} cm"
    )
    print(
        "[INFO] Maximum core-stance XYZ range: "
        f"{(_maximum_contact_range(corrected_feet, foot_contact, weights) * 100).round(3).tolist()} cm"
    )
    print(
        f"[INFO] Root correction: rms={np.sqrt(np.mean(np.square(total_root_correction))):.6f} m, "
        f"max={np.max(np.linalg.norm(total_root_correction, axis=1)):.6f} m"
    )
    print(
        "[INFO] Joint correction: "
        f"rms={np.sqrt(np.mean(np.square(total_joint_correction))):.6f} rad, "
        f"max={np.max(np.abs(total_joint_correction)):.6f} rad"
    )
    if initial_stance_weights is not None:
        initial_end = INITIAL_ROOT_FILTER_END_FRAME
        original_initial_right = original_feet[:initial_end, 1]
        corrected_initial_right = corrected_feet[:initial_end, 1]
        print(
            "[INFO] Initial right-sole XY range/path: "
            f"{(np.ptp(original_initial_right[:, :2], axis=0) * 100).round(3).tolist()} / "
            f"{np.linalg.norm(np.diff(original_initial_right[:, :2], axis=0), axis=1).sum() * 100:.3f} -> "
            f"{(np.ptp(corrected_initial_right[:, :2], axis=0) * 100).round(3).tolist()} / "
            f"{np.linalg.norm(np.diff(corrected_initial_right[:, :2], axis=0), axis=1).sum() * 100:.3f} cm"
        )


if __name__ == "__main__":
    main()
