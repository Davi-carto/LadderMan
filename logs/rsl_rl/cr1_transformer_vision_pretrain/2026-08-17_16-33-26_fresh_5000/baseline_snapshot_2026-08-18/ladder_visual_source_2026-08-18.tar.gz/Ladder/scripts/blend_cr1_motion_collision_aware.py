"""Blend a processed CR1 trajectory toward its source without worsening penetration."""

from __future__ import annotations

import argparse
import sys
from pathlib import Path

import numpy as np
from scipy.optimize import lsq_linear
from scipy.sparse import diags, eye, vstack


REPO_ROOT = Path(__file__).resolve().parents[2]
SOURCE_DIR = REPO_ROOT / "Ladder" / "source" / "ladder"
SCRIPT_DIR = REPO_ROOT / "Ladder" / "scripts"
for path in (SOURCE_DIR, SCRIPT_DIR):
    if str(path) not in sys.path:
        sys.path.insert(0, str(path))

from detect_cr1_reset_valid_frames import (
    DEFAULT_GROUND_Z,
    DEFAULT_LADDER_ASSET,
    DEFAULT_LADDER_POS,
    DEFAULT_LADDER_YAW_DEG,
    DEFAULT_ROBOT_ASSET,
    _build_collision_model,
)
from ladder.utils.urdf_kinematics import finite_difference, forward_kinematics, quaternion_angular_velocity


BLEND_LEVELS = np.asarray([1.0, 0.8, 0.6, 0.4, 0.25, 0.15, 0.1, 0.05, 0.0])


def _parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--input_file", type=Path, required=True, help="Collision-audited source motion.")
    parser.add_argument("--candidate_file", type=Path, required=True, help="Processed motion to blend toward.")
    parser.add_argument("--baseline_reset_file", type=Path, required=True, help="Source penetration sidecar.")
    parser.add_argument("--output_file", type=Path, required=True, help="Output blended motion.")
    parser.add_argument("--robot_asset", type=Path, default=DEFAULT_ROBOT_ASSET)
    parser.add_argument("--ladder_asset", type=Path, default=DEFAULT_LADDER_ASSET)
    parser.add_argument("--penetration_tolerance", type=float, default=0.001)
    parser.add_argument("--alpha_velocity_weight", type=float, default=20.0)
    parser.add_argument("--alpha_acceleration_weight", type=float, default=200.0)
    parser.add_argument("--overwrite", action="store_true")
    return parser.parse_args()


def _names(values: np.ndarray) -> list[str]:
    return [str(value) for value in np.asarray(values).reshape(-1).tolist()]


class CollisionDepth:
    def __init__(self, mujoco, robot_asset: Path, ladder_asset: Path, joint_names: list[str]):
        self.mujoco = mujoco
        self.model = _build_collision_model(
            mujoco,
            robot_asset,
            ladder_asset,
            DEFAULT_GROUND_Z,
            DEFAULT_LADDER_POS,
            DEFAULT_LADDER_YAW_DEG,
        )
        self.data = mujoco.MjData(self.model)
        self.model.geom_margin[:] = 0.05
        self.model.geom_gap[:] = 0.0
        self.joint_ids = {
            mujoco.mj_id2name(self.model, mujoco.mjtObj.mjOBJ_JOINT, index): index
            for index in range(self.model.njnt)
        }
        missing = [name for name in joint_names if name not in self.joint_ids]
        if missing:
            raise ValueError(f"collision model is missing motion joints: {missing}")
        self.joint_names = joint_names
        self.root_address = int(self.model.jnt_qposadr[self.joint_ids["root_joint"]])
        self.environment_geoms = {
            geom
            for geom in range(self.model.ngeom)
            if (
                mujoco.mj_id2name(
                    self.model,
                    mujoco.mjtObj.mjOBJ_BODY,
                    int(self.model.geom_bodyid[geom]),
                )
                or ""
            ).startswith("env_")
        }
        self.from_to = np.empty(6, dtype=np.float64)

    def __call__(
        self, root_pos: np.ndarray, root_quat: np.ndarray, joint_pos: np.ndarray
    ) -> dict[tuple[int, int], float]:
        self.data.qpos[:] = self.model.qpos0
        self.data.qpos[self.root_address : self.root_address + 3] = root_pos
        self.data.qpos[self.root_address + 3 : self.root_address + 7] = root_quat
        for column, name in enumerate(self.joint_names):
            joint_id = self.joint_ids[name]
            self.data.qpos[int(self.model.jnt_qposadr[joint_id])] = joint_pos[column]
        self.mujoco.mj_forward(self.model, self.data)

        depths: dict[tuple[int, int], float] = {}
        checked: set[tuple[int, int]] = set()
        for contact in self.data.contact:
            geom_1, geom_2 = int(contact.geom1), int(contact.geom2)
            if (geom_1 in self.environment_geoms) == (geom_2 in self.environment_geoms):
                continue
            robot_geom, environment_geom = (
                (geom_2, geom_1) if geom_1 in self.environment_geoms else (geom_1, geom_2)
            )
            pair = (robot_geom, environment_geom)
            if pair in checked:
                continue
            checked.add(pair)
            distance = self.mujoco.mj_geomDistance(
                self.model,
                self.data,
                robot_geom,
                environment_geom,
                0.05,
                self.from_to,
            )
            depths[pair] = max(0.0, -float(distance))
        return depths


def _max_depth(depths: dict[tuple[int, int], float]) -> float:
    return max(depths.values(), default=0.0)


def _within_pair_limits(
    candidate: dict[tuple[int, int], float],
    source: dict[tuple[int, int], float],
    tolerance: float,
) -> bool:
    return all(depth <= max(tolerance, source.get(pair, 0.0)) + 1.0e-7 for pair, depth in candidate.items())


def _interpolate(
    alpha: float,
    source_pos: np.ndarray,
    source_quat: np.ndarray,
    source_joint: np.ndarray,
    candidate_pos: np.ndarray,
    candidate_quat: np.ndarray,
    candidate_joint: np.ndarray,
) -> tuple[np.ndarray, np.ndarray, np.ndarray]:
    root_pos = (1.0 - alpha) * source_pos + alpha * candidate_pos
    root_quat = (1.0 - alpha) * source_quat + alpha * candidate_quat
    root_quat /= np.linalg.norm(root_quat)
    joint_pos = (1.0 - alpha) * source_joint + alpha * candidate_joint
    return root_pos, root_quat, joint_pos


def _regularize_alpha(upper: np.ndarray, velocity_weight: float, acceleration_weight: float) -> np.ndarray:
    frame_count = upper.shape[0]
    first = diags(
        (-np.ones(frame_count - 1), np.ones(frame_count - 1)),
        (0, 1),
        shape=(frame_count - 1, frame_count),
    )
    second = diags(
        (np.ones(frame_count - 2), -2.0 * np.ones(frame_count - 2), np.ones(frame_count - 2)),
        (0, 1, 2),
        shape=(frame_count - 2, frame_count),
    )
    matrix = vstack(
        [eye(frame_count), np.sqrt(velocity_weight) * first, np.sqrt(acceleration_weight) * second],
        format="csr",
    )
    target = np.concatenate(
        [np.ones(frame_count), np.zeros(frame_count - 1), np.zeros(frame_count - 2)]
    )
    alpha = lsq_linear(
        matrix,
        target,
        bounds=(np.zeros(frame_count), np.maximum(upper, 1.0e-12)),
        tol=1.0e-10,
        lsmr_tol=1.0e-10,
        max_iter=500,
    ).x
    alpha[upper == 0.0] = 0.0
    return np.minimum(alpha, upper)


def main() -> None:
    args = _parse_args()
    input_file = args.input_file.expanduser().resolve()
    candidate_file = args.candidate_file.expanduser().resolve()
    baseline_file = args.baseline_reset_file.expanduser().resolve()
    output_file = args.output_file.expanduser().resolve()
    robot_asset = args.robot_asset.expanduser().resolve()
    ladder_asset = args.ladder_asset.expanduser().resolve()
    for path in (input_file, candidate_file, baseline_file, robot_asset, ladder_asset):
        if not path.is_file():
            raise FileNotFoundError(path)
    if output_file.exists() and not args.overwrite:
        raise FileExistsError(f"Output file exists: {output_file}. Pass --overwrite to replace it.")

    try:
        import mujoco
    except ModuleNotFoundError as exc:
        raise ModuleNotFoundError("Run collision-aware blending in the retarget environment.") from exc

    with np.load(input_file, allow_pickle=False) as source_data:
        source = {key: source_data[key] for key in source_data.files}
    with np.load(candidate_file, allow_pickle=False) as candidate_data:
        candidate = {key: candidate_data[key] for key in candidate_data.files}
    with np.load(baseline_file, allow_pickle=False) as baseline_data:
        baseline_depth = np.asarray(baseline_data["reset_max_penetration_depth"], dtype=np.float64)

    joint_names = _names(source["joint_names"])
    body_names = _names(source["body_names"])
    source_joint_names = _names(source["source_joint_names"])
    if joint_names != _names(candidate["joint_names"]) or body_names != _names(candidate["body_names"]):
        raise ValueError("source and candidate joint/body names must match exactly")
    frame_count = source["joint_pos"].shape[0]
    if candidate["joint_pos"].shape[0] != frame_count or baseline_depth.shape != (frame_count,):
        raise ValueError("source, candidate, and penetration sidecar frame counts must match")

    root_index = body_names.index("base_link")
    source_root_pos = np.asarray(source["body_pos_w"][:, root_index], dtype=np.float64)
    source_root_quat = np.asarray(source["body_quat_w"][:, root_index], dtype=np.float64)
    source_joint_pos = np.asarray(source["joint_pos"], dtype=np.float64)
    candidate_root_pos = np.asarray(candidate["body_pos_w"][:, root_index], dtype=np.float64)
    candidate_root_quat = np.asarray(candidate["body_quat_w"][:, root_index], dtype=np.float64)
    candidate_joint_pos = np.asarray(candidate["joint_pos"], dtype=np.float64)
    candidate_root_quat = np.where(
        (np.sum(source_root_quat * candidate_root_quat, axis=1) < 0.0)[:, None],
        -candidate_root_quat,
        candidate_root_quat,
    )

    collision_depth = CollisionDepth(mujoco, robot_asset, ladder_asset, joint_names)
    source_pair_depths = [
        collision_depth(source_root_pos[frame], source_root_quat[frame], source_joint_pos[frame])
        for frame in range(frame_count)
    ]
    upper = np.zeros(frame_count, dtype=np.float64)
    for frame in range(frame_count):
        for alpha in BLEND_LEVELS:
            state = _interpolate(
                float(alpha),
                source_root_pos[frame],
                source_root_quat[frame],
                source_joint_pos[frame],
                candidate_root_pos[frame],
                candidate_root_quat[frame],
                candidate_joint_pos[frame],
            )
            if _within_pair_limits(
                collision_depth(*state), source_pair_depths[frame], args.penetration_tolerance
            ):
                upper[frame] = alpha
                break

    alpha = _regularize_alpha(upper, args.alpha_velocity_weight, args.alpha_acceleration_weight)
    root_pos = np.empty_like(source_root_pos)
    root_quat = np.empty_like(source_root_quat)
    joint_pos = np.empty_like(source_joint_pos)
    final_depth = np.zeros(frame_count, dtype=np.float64)
    for frame in range(frame_count):
        state = _interpolate(
            float(alpha[frame]),
            source_root_pos[frame],
            source_root_quat[frame],
            source_joint_pos[frame],
            candidate_root_pos[frame],
            candidate_root_quat[frame],
            candidate_joint_pos[frame],
        )
        depths = collision_depth(*state)
        if not _within_pair_limits(depths, source_pair_depths[frame], args.penetration_tolerance):
            alpha[frame] = 0.0
            state = (source_root_pos[frame], source_root_quat[frame], source_joint_pos[frame])
            depths = source_pair_depths[frame]
        root_pos[frame], root_quat[frame], joint_pos[frame] = state
        final_depth[frame] = _max_depth(depths)

    source_indexes = [joint_names.index(name) for name in source_joint_names]
    body_pos_w, body_quat_w = forward_kinematics(
        robot_asset,
        root_pos,
        root_quat,
        joint_pos[:, source_indexes],
        source_joint_names,
        body_names,
    )
    fps = float(np.asarray(source["fps"]).reshape(-1)[0])
    output = {
        "fps": np.asarray([fps], dtype=np.float32),
        "joint_pos": joint_pos.astype(np.float32),
        "joint_vel": finite_difference(joint_pos, fps),
        "body_pos_w": body_pos_w,
        "body_quat_w": body_quat_w,
        "body_lin_vel_w": finite_difference(body_pos_w, fps),
        "body_ang_vel_w": quaternion_angular_velocity(body_quat_w, fps),
        "joint_names": np.asarray(joint_names),
        "body_names": np.asarray(body_names),
        "source_joint_names": np.asarray(source_joint_names),
        "collision_aware_blend_source_file": np.asarray([str(input_file)]),
        "collision_aware_blend_candidate_file": np.asarray([str(candidate_file)]),
        "collision_aware_blend_alpha": alpha.astype(np.float32),
        "collision_aware_blend_alpha_upper": upper.astype(np.float32),
        "collision_aware_blend_depth": final_depth.astype(np.float32),
        "collision_aware_blend_alpha_regularization": np.asarray(
            [args.alpha_velocity_weight, args.alpha_acceleration_weight], dtype=np.float32
        ),
    }
    for key, value in source.items():
        if key.startswith(("motion_export_", "motion_processing_", "collision_aware_blend_")):
            output.setdefault(key, value)
    output_file.parent.mkdir(parents=True, exist_ok=True)
    np.savez(output_file, **output)
    print(f"[INFO] Wrote collision-aware blend: {output_file}")
    print(
        f"[INFO] Alpha min/mean/max={alpha.min():.3f}/{alpha.mean():.3f}/{alpha.max():.3f}; "
        f"frames below 0.1={int(np.sum(alpha < 0.1))}"
    )
    print(
        f"[INFO] Strict-valid frames={int(np.sum(final_depth <= args.penetration_tolerance))}/{frame_count}; "
        f"worst penetration={1000.0 * final_depth.max():.3f} mm"
    )


if __name__ == "__main__":
    main()
