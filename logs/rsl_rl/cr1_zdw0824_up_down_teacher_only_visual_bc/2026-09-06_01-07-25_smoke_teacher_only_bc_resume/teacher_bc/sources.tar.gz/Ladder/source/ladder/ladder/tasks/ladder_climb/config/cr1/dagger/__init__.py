"""Nonvisual Hybrid DAgger + PPO task for CR1."""

from .agent_cfg import (
    CR1DaggerPPORunnerCfg,
    CR1PureVisualDaggerRunnerCfg,
    CR1VisualDaggerPPORunnerCfg,
)
from .env_cfg import CR1DaggerEnvCfg
from .pure_env_cfg import CR1PureVisualDaggerEnvCfg
from .visual_env_cfg import CR1DaggerVisualEnvCfg

__all__ = [
    "CR1DaggerEnvCfg",
    "CR1DaggerPPORunnerCfg",
    "CR1DaggerVisualEnvCfg",
    "CR1VisualDaggerPPORunnerCfg",
    "CR1PureVisualDaggerEnvCfg",
    "CR1PureVisualDaggerRunnerCfg",
]
