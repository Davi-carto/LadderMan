"""Torch helpers for separating reference contact labels from physical contact."""

from __future__ import annotations

import torch


def classify_limb_contacts(
    contact_indicator: torch.Tensor,
    limb_positions_w: torch.Tensor,
    target_positions_w: torch.Tensor,
    net_forces_w: torch.Tensor,
    target_distance_thresholds: torch.Tensor | float,
    force_threshold: float,
) -> tuple[torch.Tensor, torch.Tensor, torch.Tensor]:
    """Return reference-required, physical, and target-contact masks.

    ``physical_contact`` is a force-threshold proxy for contact on the selected
    limb body.  ``target_contact`` additionally requires the limb to be in its
    reference contact phase and within its configured distance of the target.
    ContactSensor net force is not pair-specific, so the distance gate avoids
    counting an unrelated contact as successful target contact.
    """

    if force_threshold < 0.0:
        raise ValueError(f"force_threshold must be nonnegative, got {force_threshold}")
    if contact_indicator.ndim != 2:
        raise ValueError(f"contact_indicator must have shape (env, limb), got {contact_indicator.shape}")
    if limb_positions_w.shape != target_positions_w.shape or limb_positions_w.ndim != 3:
        raise ValueError("limb and target positions must have matching shape (env, limb, 3)")
    if net_forces_w.shape != limb_positions_w.shape:
        raise ValueError("net_forces_w must have the same shape as limb positions")

    thresholds = torch.as_tensor(
        target_distance_thresholds,
        dtype=limb_positions_w.dtype,
        device=limb_positions_w.device,
    )
    if thresholds.ndim == 0:
        thresholds = thresholds.expand(limb_positions_w.shape[1])
    if thresholds.shape != (limb_positions_w.shape[1],):
        raise ValueError(
            "target_distance_thresholds must be a scalar or one value per limb, "
            f"got {thresholds.shape} for {limb_positions_w.shape[1]} limbs"
        )
    if torch.any(thresholds <= 0.0):
        raise ValueError("target distance thresholds must be positive")

    required = contact_indicator > 0.5
    physical_contact = torch.linalg.vector_norm(net_forces_w, dim=-1) > force_threshold
    target_near = torch.linalg.vector_norm(limb_positions_w - target_positions_w, dim=-1) <= thresholds
    target_contact = required & physical_contact & target_near
    return required, physical_contact, target_contact
