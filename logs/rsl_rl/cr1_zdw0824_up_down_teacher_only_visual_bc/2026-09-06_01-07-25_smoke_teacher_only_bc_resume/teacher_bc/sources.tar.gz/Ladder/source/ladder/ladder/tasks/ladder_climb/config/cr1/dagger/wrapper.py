"""Vector-environment adapter for CR1 DAgger."""

from __future__ import annotations

import torch
from tensordict import TensorDict
from rsl_rl.env import VecEnv

from .student_teacher import CRITIC_KEY, STUDENT_KEY, TEACHER_KEY


def as_dagger_tensordict(
    observations: dict | TensorDict,
    *,
    num_envs: int,
    device: str | torch.device,
    actor_only: bool = False,
) -> TensorDict:
    if isinstance(observations, TensorDict):
        observations = observations.to_dict()
    student = observations[STUDENT_KEY]
    result = {STUDENT_KEY: student}
    if not actor_only:
        result.update(
            {
                TEACHER_KEY: observations[TEACHER_KEY],
                CRITIC_KEY: observations[CRITIC_KEY],
            }
        )
    return TensorDict(result, batch_size=[num_envs], device=device)


class CR1DaggerVecEnvWrapper(VecEnv):
    def __init__(self, env, clip_actions: float | None = None) -> None:
        if clip_actions is not None and clip_actions <= 0.0:
            raise ValueError("clip_actions must be positive or None")
        self.env = env
        self.clip_actions = clip_actions
        self.actor_only = False
        self.num_envs = env.unwrapped.num_envs
        self.device = env.unwrapped.device
        self.max_episode_length = env.unwrapped.max_episode_length
        self.num_actions = env.unwrapped.action_manager.total_action_dim
        self.env.reset()

    @property
    def cfg(self):
        return self.env.unwrapped.cfg

    @property
    def unwrapped(self):
        return self.env.unwrapped

    @property
    def episode_length_buf(self):
        return self.env.unwrapped.episode_length_buf

    @episode_length_buf.setter
    def episode_length_buf(self, value):
        self.env.unwrapped.episode_length_buf = value

    def _convert(self, observations) -> TensorDict:
        return as_dagger_tensordict(
            observations,
            num_envs=self.num_envs,
            device=self.device,
            actor_only=self.actor_only,
        )

    def get_observations(self) -> TensorDict:
        return self._convert(self.env.unwrapped.observation_manager.compute())

    def reset(self) -> TensorDict:
        observations, _ = self.env.reset()
        return self._convert(observations)

    def step(self, actions: torch.Tensor):
        if self.clip_actions is not None:
            actions = actions.clamp(-self.clip_actions, self.clip_actions)
        observations, rewards, terminated, truncated, extras = self.env.step(actions)
        dones = (terminated | truncated).to(dtype=torch.bool)
        if not self.cfg.is_finite_horizon:
            extras["time_outs"] = truncated
        return self._convert(observations), rewards, dones, extras

    def close(self) -> None:
        self.env.close()


__all__ = ["CR1DaggerVecEnvWrapper", "as_dagger_tensordict"]
