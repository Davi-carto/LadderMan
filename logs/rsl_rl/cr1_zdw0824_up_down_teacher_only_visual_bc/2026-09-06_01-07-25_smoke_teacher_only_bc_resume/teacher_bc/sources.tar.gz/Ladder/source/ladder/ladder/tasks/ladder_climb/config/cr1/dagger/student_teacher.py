"""Networks and frozen-teacher loading for CR1 DAgger."""

from __future__ import annotations

from collections import OrderedDict
from pathlib import Path

import torch
from tensordict import TensorDict
from torch import nn


STUDENT_KEY = "student"
TEACHER_KEY = "teacher"
CRITIC_KEY = "critic"


def elu_mlp(input_dim: int, hidden_dims: list[int], output_dim: int) -> nn.Sequential:
    layers: list[nn.Module] = []
    previous_dim = input_dim
    for hidden_dim in hidden_dims:
        layers.extend((nn.Linear(previous_dim, hidden_dim), nn.ELU()))
        previous_dim = hidden_dim
    layers.append(nn.Linear(previous_dim, output_dim))
    return nn.Sequential(*layers)


class CR1DaggerStudent(nn.Module):
    """Deployable feed-forward policy over a flattened five-frame history."""

    def __init__(
        self,
        observation_dim: int,
        action_dim: int,
        hidden_dims: list[int],
        init_noise_std: float,
    ) -> None:
        super().__init__()
        self.observation_dim = observation_dim
        self.action_dim = action_dim
        self.mlp = elu_mlp(observation_dim, hidden_dims, action_dim)
        self.log_std = nn.Parameter(
            torch.full((action_dim,), float(init_noise_std)).log()
        )

    @property
    def output_std(self) -> torch.Tensor:
        return self.log_std.exp()

    def action_mean(self, observations: torch.Tensor | TensorDict) -> torch.Tensor:
        if isinstance(observations, TensorDict):
            observations = observations[STUDENT_KEY]
        return self.mlp(observations)

    def forward(self, observations: torch.Tensor | TensorDict) -> torch.Tensor:
        return self.action_mean(observations)

    def reset(self, dones: torch.Tensor | None = None) -> None:
        del dones


def load_frozen_teacher(
    checkpoint: str,
    *,
    observation_dim: int,
    action_dim: int,
    hidden_dims: list[int],
    device: str | torch.device,
) -> nn.Sequential:
    """Load only the deterministic actor MLP from an RSL-RL checkpoint."""

    path = Path(checkpoint).expanduser().resolve()
    if not path.is_file():
        raise FileNotFoundError(f"Teacher checkpoint was not found: {path}")
    payload = torch.load(path, map_location="cpu", weights_only=False)
    if not isinstance(payload, dict):
        raise TypeError("Teacher checkpoint payload must be a dictionary")

    if "actor_state_dict" in payload:
        source = payload["actor_state_dict"]
        state = OrderedDict(
            (key.removeprefix("mlp."), value)
            for key, value in source.items()
            if key.startswith("mlp.")
        )
    elif "model_state_dict" in payload:
        source = payload["model_state_dict"]
        state = OrderedDict(
            (key.removeprefix("actor."), value)
            for key, value in source.items()
            if key.startswith("actor.")
        )
    else:
        raise KeyError(
            "Teacher checkpoint must contain actor_state_dict or model_state_dict"
        )
    if not state:
        raise KeyError("Teacher checkpoint contains no supported actor MLP parameters")

    teacher = elu_mlp(observation_dim, hidden_dims, action_dim)
    teacher.load_state_dict(state, strict=True)
    teacher.to(device).eval().requires_grad_(False)
    return teacher


__all__ = [
    "CRITIC_KEY",
    "STUDENT_KEY",
    "TEACHER_KEY",
    "CR1DaggerStudent",
    "elu_mlp",
    "load_frozen_teacher",
]
