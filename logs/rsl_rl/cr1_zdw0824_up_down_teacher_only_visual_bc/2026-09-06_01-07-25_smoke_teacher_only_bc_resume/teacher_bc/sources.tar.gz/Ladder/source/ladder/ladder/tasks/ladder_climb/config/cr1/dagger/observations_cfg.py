"""Observation contract for nonvisual CR1 teacher-student training."""

from __future__ import annotations

import torch

from isaaclab.envs import ManagerBasedEnv
from isaaclab.managers import ObservationGroupCfg as ObsGroup
from isaaclab.managers import ObservationTermCfg as ObsTerm
from isaaclab.utils import configclass

from ladder.tasks.ladder_climb import mdp


STUDENT_FRAME_DIM = 84
STUDENT_HISTORY_LENGTH = 5
STUDENT_OBSERVATION_DIM = STUDENT_FRAME_DIM * STUDENT_HISTORY_LENGTH


def cr1_dagger_proprio_frame(env: ManagerBasedEnv) -> torch.Tensor:
    """Return one noisy, deployable 84-D proprioceptive frame.

    This deliberately removes the no-command compatibility pad from the
    established 85-D visual proprioception contract.  No reference motion,
    phase, annotated contact, or simulator-only state enters this tensor.
    """

    frame = mdp.cr1_transformer_vision_proprio_frame(
        env,
        include_climb_command=False,
        add_noise=True,
    )
    if frame.shape[-1] != STUDENT_FRAME_DIM + 1:
        raise RuntimeError(
            "Expected the CR1 proprioception builder to return 85 values, got "
            f"{frame.shape[-1]}"
        )
    return frame[..., :STUDENT_FRAME_DIM]


@configclass
class CR1DaggerStudentObservationCfg(ObsGroup):
    """Five deployable proprioception frames, flattened oldest to newest."""

    proprio_history = ObsTerm(
        func=cr1_dagger_proprio_frame,
        history_length=STUDENT_HISTORY_LENGTH,
    )

    def __post_init__(self):
        self.enable_corruption = False
        self.concatenate_terms = True


__all__ = [
    "CR1DaggerStudentObservationCfg",
    "STUDENT_FRAME_DIM",
    "STUDENT_HISTORY_LENGTH",
    "STUDENT_OBSERVATION_DIM",
    "cr1_dagger_proprio_frame",
]
