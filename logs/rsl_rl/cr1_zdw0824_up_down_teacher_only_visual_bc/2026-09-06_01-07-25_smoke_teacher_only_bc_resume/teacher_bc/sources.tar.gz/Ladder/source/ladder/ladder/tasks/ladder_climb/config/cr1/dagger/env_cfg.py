"""CR1 environment exposing student, teacher, and critic observations."""

from isaaclab.utils import configclass

from ..wood_step_zdw0824_no_command_full_state_env_cfg import (
    CR1ZDW0824FullStateObservationCfg,
    CR1ZDW0824NoCommandFullStateMiddleStandSmoothOutputEnvCfg,
)
from .observations_cfg import CR1DaggerStudentObservationCfg


@configclass
class CR1DaggerObservationsCfg:
    student: CR1DaggerStudentObservationCfg = CR1DaggerStudentObservationCfg()
    teacher: CR1ZDW0824FullStateObservationCfg = CR1ZDW0824FullStateObservationCfg()
    critic: CR1ZDW0824FullStateObservationCfg = CR1ZDW0824FullStateObservationCfg()


@configclass
class CR1DaggerEnvCfg(
    CR1ZDW0824NoCommandFullStateMiddleStandSmoothOutputEnvCfg
):
    """Validated task dynamics with an asymmetric DAgger observation contract."""

    observations: CR1DaggerObservationsCfg = CR1DaggerObservationsCfg()


__all__ = ["CR1DaggerEnvCfg", "CR1DaggerObservationsCfg"]
