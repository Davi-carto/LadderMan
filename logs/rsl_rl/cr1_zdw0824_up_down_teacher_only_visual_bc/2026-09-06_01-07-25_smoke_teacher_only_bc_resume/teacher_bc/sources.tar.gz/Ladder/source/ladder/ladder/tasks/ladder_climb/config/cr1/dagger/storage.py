"""Rollout storage for feed-forward Hybrid DAgger + PPO."""

from __future__ import annotations

from dataclasses import dataclass
from typing import Iterator

import torch


@dataclass
class DaggerTransition:
    student_observation: torch.Tensor
    critic_observation: torch.Tensor
    actions: torch.Tensor
    old_action_mean: torch.Tensor
    old_action_std: torch.Tensor
    old_action_log_prob: torch.Tensor
    teacher_action_mean: torch.Tensor
    value: torch.Tensor


class DaggerRolloutStorage:
    def __init__(
        self,
        num_steps: int,
        num_envs: int,
        student_dim: int,
        critic_dim: int,
        action_dim: int,
        device: str | torch.device,
    ) -> None:
        self.num_steps = num_steps
        self.num_envs = num_envs
        self.student_dim = student_dim
        self.critic_dim = critic_dim
        self.action_dim = action_dim
        self.device = torch.device(device)
        self.step = 0
        self.student_observations = torch.zeros(num_steps, num_envs, student_dim, device=self.device)
        self.critic_observations = torch.zeros(num_steps, num_envs, critic_dim, device=self.device)
        self.actions = torch.zeros(num_steps, num_envs, action_dim, device=self.device)
        self.old_action_mean = torch.zeros_like(self.actions)
        self.old_action_std = torch.zeros_like(self.actions)
        self.old_action_log_prob = torch.zeros(num_steps, num_envs, 1, device=self.device)
        self.teacher_action_mean = torch.zeros_like(self.actions)
        self.values = torch.zeros(num_steps, num_envs, 1, device=self.device)
        self.rewards = torch.zeros_like(self.values)
        self.dones = torch.zeros(num_steps, num_envs, dtype=torch.bool, device=self.device)
        self.returns = torch.zeros_like(self.values)
        self.advantages = torch.zeros_like(self.values)

    def add(self, transition: DaggerTransition, reward: torch.Tensor, done: torch.Tensor) -> None:
        if self.step >= self.num_steps:
            raise OverflowError("DAgger rollout storage is full")
        index = self.step
        self.student_observations[index].copy_(transition.student_observation)
        self.critic_observations[index].copy_(transition.critic_observation)
        self.actions[index].copy_(transition.actions)
        self.old_action_mean[index].copy_(transition.old_action_mean)
        self.old_action_std[index].copy_(transition.old_action_std)
        self.old_action_log_prob[index].copy_(transition.old_action_log_prob)
        self.teacher_action_mean[index].copy_(transition.teacher_action_mean)
        self.values[index].copy_(transition.value)
        self.rewards[index].copy_(reward.reshape(self.num_envs, 1))
        self.dones[index].copy_(done.to(dtype=torch.bool).reshape(self.num_envs))
        self.step += 1

    def compute_returns(self, last_value: torch.Tensor, gamma: float, lam: float) -> None:
        if self.step != self.num_steps:
            raise RuntimeError(f"Expected {self.num_steps} transitions, stored {self.step}")
        advantage = torch.zeros_like(last_value)
        for index in reversed(range(self.num_steps)):
            next_value = last_value if index == self.num_steps - 1 else self.values[index + 1]
            not_done = (~self.dones[index]).to(self.values.dtype).unsqueeze(-1)
            delta = self.rewards[index] + gamma * not_done * next_value - self.values[index]
            advantage = delta + gamma * lam * not_done * advantage
            self.advantages[index] = advantage
            self.returns[index] = advantage + self.values[index]
        self.advantages.sub_(self.advantages.mean()).div_(self.advantages.std().clamp_min(1.0e-8))

    def batches(self, num_mini_batches: int, num_epochs: int) -> Iterator[dict[str, torch.Tensor]]:
        total = self.num_steps * self.num_envs
        if num_mini_batches > total:
            raise ValueError("num_mini_batches cannot exceed rollout sample count")
        flat = {
            "student_observations": self.student_observations.reshape(total, self.student_dim),
            "critic_observations": self.critic_observations.reshape(total, self.critic_dim),
            "actions": self.actions.reshape(total, self.action_dim),
            "old_action_mean": self.old_action_mean.reshape(total, self.action_dim),
            "old_action_std": self.old_action_std.reshape(total, self.action_dim),
            "old_action_log_prob": self.old_action_log_prob.reshape(total, 1),
            "teacher_action_mean": self.teacher_action_mean.reshape(total, self.action_dim),
            "values": self.values.reshape(total, 1),
            "advantages": self.advantages.reshape(total, 1),
            "returns": self.returns.reshape(total, 1),
        }
        for _ in range(num_epochs):
            for selected in torch.tensor_split(
                torch.randperm(total, device=self.device), num_mini_batches
            ):
                yield {name: value[selected] for name, value in flat.items()}

    def clear(self) -> None:
        self.step = 0


__all__ = ["DaggerRolloutStorage", "DaggerTransition"]
