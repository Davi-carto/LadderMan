"""Ladder climbing task package."""
