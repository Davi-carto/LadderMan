"""Feed-forward Hybrid DAgger + PPO for the nonvisual CR1 student."""

from __future__ import annotations

from itertools import chain

import torch
from tensordict import TensorDict
from torch import nn
from torch.distributions import Normal

from .storage import DaggerRolloutStorage, DaggerTransition
from .student_teacher import (
    CRITIC_KEY,
    STUDENT_KEY,
    TEACHER_KEY,
    CR1DaggerStudent,
    elu_mlp,
    load_frozen_teacher,
)


class CR1HybridDaggerPPO:
    """PPO on student rollouts with frozen-teacher action supervision."""

    def __init__(
        self,
        policy: CR1DaggerStudent,
        teacher: nn.Module,
        critic: nn.Module,
        storage: DaggerRolloutStorage,
        *,
        num_learning_epochs: int,
        num_mini_batches: int,
        clip_param: float,
        gamma: float,
        lam: float,
        value_loss_coef: float,
        entropy_coef: float,
        learning_rate: float,
        max_grad_norm: float,
        use_clipped_value_loss: bool,
        schedule: str,
        desired_kl: float | None,
        dagger_initial_coeff: float,
        dagger_final_coeff: float,
        dagger_anneal_start: int,
        dagger_anneal_iterations: int,
        device: str | torch.device,
    ) -> None:
        if schedule not in ("adaptive", "fixed"):
            raise ValueError(f"Unsupported PPO schedule {schedule!r}")
        if dagger_initial_coeff < 0.0 or dagger_final_coeff < 0.0:
            raise ValueError("DAgger coefficients must be non-negative")
        if dagger_anneal_iterations <= dagger_anneal_start:
            raise ValueError("DAgger anneal end must be greater than its start")
        self.device = torch.device(device)
        self.policy = policy.to(self.device)
        self.teacher = teacher.to(self.device).eval()
        self.critic = critic.to(self.device)
        self.storage = storage
        self.num_learning_epochs = num_learning_epochs
        self.num_mini_batches = num_mini_batches
        self.clip_param = clip_param
        self.gamma = gamma
        self.lam = lam
        self.value_loss_coef = value_loss_coef
        self.entropy_coef = entropy_coef
        self.learning_rate = learning_rate
        self.max_grad_norm = max_grad_norm
        self.use_clipped_value_loss = use_clipped_value_loss
        self.schedule = schedule
        self.desired_kl = desired_kl
        self.dagger_initial_coeff = dagger_initial_coeff
        self.dagger_final_coeff = dagger_final_coeff
        self.dagger_anneal_start = dagger_anneal_start
        self.dagger_anneal_iterations = dagger_anneal_iterations
        self.update_iteration = 0
        self.rnd = None
        self.intrinsic_rewards = None
        self._pending: DaggerTransition | None = None
        self.optimizer = torch.optim.Adam(
            chain(self.policy.parameters(), self.critic.parameters()), lr=learning_rate
        )

    @staticmethod
    def construct_algorithm(
        obs: TensorDict, env, cfg: dict, device: str
    ) -> "CR1HybridDaggerPPO":
        CR1HybridDaggerPPO._validate_observations(obs)
        if cfg.get("multi_gpu") is not None:
            raise NotImplementedError("CR1 DAgger currently supports one GPU")
        policy_cfg = cfg["policy"]
        algorithm_cfg = dict(cfg["algorithm"])
        algorithm_cfg.pop("class_name", None)
        algorithm_cfg.pop("rnd_cfg", None)
        algorithm_cfg.pop("symmetry_cfg", None)
        algorithm_cfg.pop("normalize_advantage_per_mini_batch", None)
        algorithm_cfg.pop("optimizer", None)
        teacher_checkpoint = algorithm_cfg.pop("teacher_checkpoint")
        if not teacher_checkpoint:
            raise ValueError("A fresh CR1 DAgger run requires teacher_checkpoint")
        student_dim = int(obs[STUDENT_KEY].shape[-1])
        teacher_dim = int(obs[TEACHER_KEY].shape[-1])
        critic_dim = int(obs[CRITIC_KEY].shape[-1])
        action_dim = env.num_actions
        student = CR1DaggerStudent(
            student_dim,
            action_dim,
            list(policy_cfg["actor_hidden_dims"]),
            float(policy_cfg["init_noise_std"]),
        )
        teacher = load_frozen_teacher(
            teacher_checkpoint,
            observation_dim=teacher_dim,
            action_dim=action_dim,
            hidden_dims=list(algorithm_cfg.pop("teacher_hidden_dims")),
            device=device,
        )
        critic = elu_mlp(critic_dim, list(policy_cfg["critic_hidden_dims"]), 1)
        storage = DaggerRolloutStorage(
            int(cfg["num_steps_per_env"]),
            env.num_envs,
            student_dim,
            critic_dim,
            action_dim,
            device,
        )
        return CR1HybridDaggerPPO(
            student,
            teacher,
            critic,
            storage,
            device=device,
            num_learning_epochs=int(algorithm_cfg.pop("num_learning_epochs")),
            num_mini_batches=int(algorithm_cfg.pop("num_mini_batches")),
            clip_param=float(algorithm_cfg.pop("clip_param")),
            gamma=float(algorithm_cfg.pop("gamma")),
            lam=float(algorithm_cfg.pop("lam")),
            value_loss_coef=float(algorithm_cfg.pop("value_loss_coef")),
            entropy_coef=float(algorithm_cfg.pop("entropy_coef")),
            learning_rate=float(algorithm_cfg.pop("learning_rate")),
            max_grad_norm=float(algorithm_cfg.pop("max_grad_norm")),
            use_clipped_value_loss=bool(algorithm_cfg.pop("use_clipped_value_loss")),
            schedule=str(algorithm_cfg.pop("schedule")),
            desired_kl=algorithm_cfg.pop("desired_kl"),
            dagger_initial_coeff=float(algorithm_cfg.pop("dagger_initial_coeff")),
            dagger_final_coeff=float(algorithm_cfg.pop("dagger_final_coeff")),
            dagger_anneal_start=int(algorithm_cfg.pop("dagger_anneal_start")),
            dagger_anneal_iterations=int(algorithm_cfg.pop("dagger_anneal_iterations")),
        )

    @property
    def dagger_coeff(self) -> float:
        if self.update_iteration <= self.dagger_anneal_start:
            return self.dagger_initial_coeff
        if self.update_iteration >= self.dagger_anneal_iterations:
            return self.dagger_final_coeff
        alpha = (self.update_iteration - self.dagger_anneal_start) / (
            self.dagger_anneal_iterations - self.dagger_anneal_start
        )
        return self.dagger_initial_coeff + alpha * (
            self.dagger_final_coeff - self.dagger_initial_coeff
        )

    def act(self, obs: TensorDict) -> torch.Tensor:
        if self._pending is not None:
            raise RuntimeError("process_env_step must follow every act call")
        self._validate_observations(obs)
        with torch.no_grad():
            mean = self.policy.action_mean(obs[STUDENT_KEY])
            std = self.policy.output_std.expand_as(mean)
            distribution = Normal(mean, std)
            actions = distribution.sample()
            teacher_mean = self.teacher(obs[TEACHER_KEY])
            value = self.critic(obs[CRITIC_KEY])
        self._pending = DaggerTransition(
            obs[STUDENT_KEY].detach(),
            obs[CRITIC_KEY].detach(),
            actions.detach(),
            mean.detach(),
            std.detach(),
            distribution.log_prob(actions).sum(-1, keepdim=True).detach(),
            teacher_mean.detach(),
            value.detach(),
        )
        return actions

    def process_env_step(self, obs, rewards, dones, extras) -> None:
        del obs
        if self._pending is None:
            raise RuntimeError("act must be called before process_env_step")
        reward = rewards.detach().clone().to(self.device)
        if "time_outs" in extras:
            reward += (
                self.gamma
                * self._pending.value.squeeze(-1)
                * extras["time_outs"].to(reward)
            )
        self.storage.add(self._pending, reward, dones)
        self._pending = None

    def compute_returns(self, obs: TensorDict) -> None:
        with torch.no_grad():
            last_value = self.critic(obs[CRITIC_KEY])
        self.storage.compute_returns(last_value, self.gamma, self.lam)

    def update(self) -> dict[str, float]:
        totals = {
            "value": 0.0,
            "surrogate": 0.0,
            "entropy": 0.0,
            "policy_kl": 0.0,
            "dagger_action_mse": 0.0,
        }
        updates = 0
        coefficient = self.dagger_coeff
        for batch in self.storage.batches(self.num_mini_batches, self.num_learning_epochs):
            mean = self.policy.action_mean(batch["student_observations"])
            std = self.policy.output_std.expand_as(mean)
            distribution = Normal(mean, std)
            log_prob = distribution.log_prob(batch["actions"]).sum(-1, keepdim=True)
            entropy = distribution.entropy().sum(-1).mean()
            values = self.critic(batch["critic_observations"])
            ratio = (log_prob - batch["old_action_log_prob"]).exp()
            surrogate = -batch["advantages"] * ratio
            clipped = -batch["advantages"] * ratio.clamp(
                1.0 - self.clip_param, 1.0 + self.clip_param
            )
            surrogate_loss = torch.maximum(surrogate, clipped).mean()
            if self.use_clipped_value_loss:
                value_clipped = batch["values"] + (
                    values - batch["values"]
                ).clamp(-self.clip_param, self.clip_param)
                value_loss = torch.maximum(
                    (values - batch["returns"]).square(),
                    (value_clipped - batch["returns"]).square(),
                ).mean()
            else:
                value_loss = (values - batch["returns"]).square().mean()
            dagger_loss = (mean - batch["teacher_action_mean"]).square().mean()
            loss = (
                surrogate_loss
                + self.value_loss_coef * value_loss
                - self.entropy_coef * entropy
                + coefficient * dagger_loss
            )
            self.optimizer.zero_grad()
            loss.backward()
            nn.utils.clip_grad_norm_(
                chain(self.policy.parameters(), self.critic.parameters()),
                self.max_grad_norm,
            )
            self.optimizer.step()
            with torch.no_grad():
                kl = self._normal_kl(
                    batch["old_action_mean"], batch["old_action_std"], mean, std
                ).mean()
            self._adapt_learning_rate(float(kl))
            totals["value"] += float(value_loss)
            totals["surrogate"] += float(surrogate_loss)
            totals["entropy"] += float(entropy)
            totals["policy_kl"] += float(kl)
            totals["dagger_action_mse"] += float(dagger_loss)
            updates += 1
        self.storage.clear()
        self.update_iteration += 1
        result = {name: value / updates for name, value in totals.items()}
        result["dagger_coeff"] = coefficient
        result["student_teacher_action_rmse"] = result["dagger_action_mse"] ** 0.5
        return result

    def act_inference(self, obs: TensorDict, dones=None) -> torch.Tensor:
        del dones
        with torch.no_grad():
            return self.policy.action_mean(obs)

    def train_mode(self) -> None:
        self.policy.train()
        self.critic.train()
        self.teacher.eval()

    def eval_mode(self) -> None:
        self.policy.eval()
        self.critic.eval()
        self.teacher.eval()

    def get_policy(self) -> CR1DaggerStudent:
        return self.policy

    def save(self) -> dict:
        return {
            "data_contract": "cr1_dagger_5x84_v1",
            "policy_state_dict": self.policy.state_dict(),
            "critic_state_dict": self.critic.state_dict(),
            "optimizer_state_dict": self.optimizer.state_dict(),
            "update_iteration": self.update_iteration,
        }

    def load(self, loaded_dict: dict, load_cfg: dict | None, strict: bool) -> bool:
        if loaded_dict.get("data_contract") != "cr1_dagger_5x84_v1":
            raise RuntimeError("Incompatible CR1 DAgger checkpoint data contract")
        load_cfg = load_cfg or {
            "actor": True,
            "critic": True,
            "optimizer": True,
            "iteration": True,
        }
        if load_cfg.get("actor", True):
            self.policy.load_state_dict(loaded_dict["policy_state_dict"], strict=strict)
        if load_cfg.get("critic", True):
            self.critic.load_state_dict(loaded_dict["critic_state_dict"], strict=strict)
        if load_cfg.get("optimizer", True):
            self.optimizer.load_state_dict(loaded_dict["optimizer_state_dict"])
        self.update_iteration = int(loaded_dict.get("update_iteration", 0))
        return bool(load_cfg.get("iteration", True))

    def _adapt_learning_rate(self, kl: float) -> None:
        if self.schedule != "adaptive" or self.desired_kl is None:
            return
        if kl > self.desired_kl * 2.0:
            self.learning_rate = max(1.0e-5, self.learning_rate / 1.5)
        elif 0.0 < kl < self.desired_kl / 2.0:
            self.learning_rate = min(1.0e-3, self.learning_rate * 1.5)
        for group in self.optimizer.param_groups:
            group["lr"] = self.learning_rate

    @staticmethod
    def _normal_kl(old_mean, old_std, mean, std):
        return (
            torch.log(std / old_std)
            + (old_std.square() + (old_mean - mean).square())
            / (2.0 * std.square())
            - 0.5
        )

    @staticmethod
    def _validate_observations(obs: TensorDict) -> None:
        missing = [key for key in (STUDENT_KEY, TEACHER_KEY, CRITIC_KEY) if key not in obs]
        if missing:
            raise KeyError(f"Missing CR1 DAgger observations: {missing}")
        if any(obs[key].ndim != 2 for key in (STUDENT_KEY, TEACHER_KEY, CRITIC_KEY)):
            raise ValueError("CR1 DAgger observations must all have shape [B,D]")


__all__ = ["CR1HybridDaggerPPO"]
