"""Train LadderMan policies with RSL-RL.

This entry point is intentionally local to Ladder so task registration and
reference-motion loading do not depend on whole_body_tracking scripts.
"""

import argparse
import os
import pickle
import sys
from datetime import datetime
from pathlib import Path

from isaaclab.app import AppLauncher

import cli_args  # isort: skip


REPO_ROOT = Path(__file__).resolve().parents[3]
LADDER_SOURCE_DIR = REPO_ROOT / "Ladder" / "source" / "ladder"
if str(LADDER_SOURCE_DIR) not in sys.path:
    sys.path.insert(0, str(LADDER_SOURCE_DIR))


parser = argparse.ArgumentParser(description="Train a LadderMan RSL-RL agent.")
parser.add_argument("--video", action="store_true", default=False, help="Record videos during training.")
parser.add_argument("--video_length", type=int, default=200, help="Length of the recorded video in steps.")
parser.add_argument("--video_interval", type=int, default=2000, help="Interval between video recordings in steps.")
parser.add_argument("--num_envs", type=int, default=None, help="Number of environments to simulate.")
parser.add_argument("--task", type=str, default="Ladder-Climb-CR1-v0", help="Name of the task.")
parser.add_argument("--seed", type=int, default=None, help="Seed used for the environment.")
parser.add_argument("--max_iterations", type=int, default=None, help="RL policy training iterations.")
parser.add_argument("--motion_file", type=str, required=True, help="Path to LadderMan climbing motion.npz.")
parser.add_argument(
    "--vision_checkpoint",
    type=str,
    default=None,
    help="TransformerVision pretraining checkpoint used to initialize a fresh visual PPO run.",
)
parser.add_argument(
    "--teacher_checkpoint",
    type=str,
    default=None,
    help="Frozen full-state teacher checkpoint for Hybrid DAgger + PPO.",
)
parser.add_argument(
    "--disable_randomization",
    action="store_true",
    help="Disable startup physics randomization and reset-state perturbations for baseline training.",
)
parser.add_argument(
    "--base_reset_noise_only",
    action="store_true",
    help="Disable physics/joint randomization but retain the configured base pose and velocity reset noise.",
)
cli_args.add_rsl_rl_args(parser)
AppLauncher.add_app_launcher_args(parser)
args_cli, hydra_args = parser.parse_known_args()

if args_cli.disable_randomization and args_cli.base_reset_noise_only:
    parser.error("--disable_randomization and --base_reset_noise_only are mutually exclusive")

if args_cli.video:
    args_cli.enable_cameras = True
if args_cli.task.endswith("-Visual-v0"):
    args_cli.enable_cameras = True

sys.argv = [sys.argv[0]] + hydra_args

app_launcher = AppLauncher(args_cli)
simulation_app = app_launcher.app

import gymnasium as gym
import torch
from rsl_rl.runners import OnPolicyRunner

from isaaclab.envs import DirectMARLEnv, DirectMARLEnvCfg, DirectRLEnvCfg, ManagerBasedRLEnvCfg, multi_agent_to_single_agent
from isaaclab.utils.dict import print_dict
from isaaclab.utils.io import dump_yaml
from isaaclab_rl.rsl_rl import RslRlOnPolicyRunnerCfg, RslRlVecEnvWrapper
from isaaclab_tasks.utils import get_checkpoint_path
from isaaclab_tasks.utils.hydra import hydra_task_config

import ladder.tasks  # noqa: F401
from rsl_rl_compat import convert_legacy_runner_cfg


try:
    from isaaclab.utils.io import dump_pickle
except ImportError:

    def dump_pickle(filename, data):
        """Compatibility fallback for IsaacLab versions without dump_pickle."""

        if not filename.endswith(".pkl"):
            filename += ".pkl"
        os.makedirs(os.path.dirname(filename), exist_ok=True)
        with open(filename, "wb") as file:
            pickle.dump(data, file)


torch.backends.cuda.matmul.allow_tf32 = True
torch.backends.cudnn.allow_tf32 = True
torch.backends.cudnn.deterministic = False
torch.backends.cudnn.benchmark = False


@hydra_task_config(args_cli.task, "rsl_rl_cfg_entry_point")
def main(env_cfg: ManagerBasedRLEnvCfg | DirectRLEnvCfg | DirectMARLEnvCfg, agent_cfg: RslRlOnPolicyRunnerCfg):
    agent_cfg = cli_args.update_rsl_rl_cfg(agent_cfg, args_cli)
    env_cfg.scene.num_envs = args_cli.num_envs if args_cli.num_envs is not None else env_cfg.scene.num_envs
    agent_cfg.max_iterations = (
        args_cli.max_iterations if args_cli.max_iterations is not None else agent_cfg.max_iterations
    )
    env_cfg.seed = agent_cfg.seed
    env_cfg.sim.device = args_cli.device if args_cli.device is not None else env_cfg.sim.device
    env_cfg.commands.motion.motion_file = os.path.abspath(args_cli.motion_file)
    # Command/contact markers are useful for replay, but add no training signal
    # and create point-instancer warnings in headless multi-env training.
    env_cfg.commands.motion.debug_vis = False
    env_cfg.scene.contact_forces.debug_vis = False
    if args_cli.disable_randomization:
        for event_name in (
            "robot_material",
            "robot_mass",
            "joint_position_offset",
            "torso_com",
            "motor_strength",
            "motor_strength_interval",
            "camera_extrinsics",
            "root_velocity_push",
        ):
            if hasattr(env_cfg.events, event_name):
                setattr(env_cfg.events, event_name, None)
        env_cfg.commands.motion.pose_range = {
            name: (0.0, 0.0) for name in ("x", "y", "z", "roll", "pitch", "yaw")
        }
        env_cfg.commands.motion.fixed_start_pose_range = {}
        env_cfg.commands.motion.velocity_range = {
            name: (0.0, 0.0) for name in ("x", "y", "z", "roll", "pitch", "yaw")
        }
        env_cfg.commands.motion.joint_position_range = (0.0, 0.0)
        env_cfg.commands.motion.ladder_inclination_delta_range = (0.0, 0.0)
        env_cfg.commands.motion.ladder_spacing_delta_range = (0.0, 0.0)
        print("[INFO] Domain and reset-state randomization disabled for this run.")
    elif args_cli.base_reset_noise_only:
        for event_name in (
            "robot_material",
            "robot_mass",
            "joint_position_offset",
            "torso_com",
            "motor_strength",
            "motor_strength_interval",
            "camera_extrinsics",
            "root_velocity_push",
        ):
            if hasattr(env_cfg.events, event_name):
                setattr(env_cfg.events, event_name, None)
        env_cfg.commands.motion.joint_position_range = (0.0, 0.0)
        env_cfg.commands.motion.ladder_inclination_delta_range = (0.0, 0.0)
        env_cfg.commands.motion.ladder_spacing_delta_range = (0.0, 0.0)
        print("[INFO] Physics/joint randomization disabled; base reset noise retained.")

    log_root_path = os.path.abspath(os.path.join("logs", "rsl_rl", agent_cfg.experiment_name))
    print(f"[INFO] Logging experiment in directory: {log_root_path}")
    log_dir = datetime.now().strftime("%Y-%m-%d_%H-%M-%S")
    if agent_cfg.run_name:
        log_dir += f"_{agent_cfg.run_name}"
    log_dir = os.path.join(log_root_path, log_dir)

    env = gym.make(args_cli.task, cfg=env_cfg, render_mode="rgb_array" if args_cli.video else None)
    if isinstance(env.unwrapped, DirectMARLEnv):
        env = multi_agent_to_single_agent(env)

    if agent_cfg.resume:
        explicit_checkpoint = None
        if args_cli.checkpoint is not None:
            checkpoint_path = os.path.abspath(os.path.expanduser(args_cli.checkpoint))
            if os.path.isfile(checkpoint_path):
                explicit_checkpoint = checkpoint_path
        resume_path = (
            explicit_checkpoint
            if explicit_checkpoint is not None
            else get_checkpoint_path(
                log_root_path,
                agent_cfg.load_run,
                agent_cfg.load_checkpoint,
            )
        )

    if args_cli.video:
        video_kwargs = {
            "video_folder": os.path.join(log_dir, "videos", "train"),
            "step_trigger": lambda step: step % args_cli.video_interval == 0,
            "video_length": args_cli.video_length,
            "disable_logger": True,
        }
        print("[INFO] Recording videos during training.")
        print_dict(video_kwargs, nesting=4)
        env = gym.wrappers.RecordVideo(env, **video_kwargs)

    runner_cfg = agent_cfg.to_dict()
    if runner_cfg.get("use_pure_dagger_visual_runner", False):
        from ladder.tasks.ladder_climb.config.cr1.dagger.pure_wrapper import (
            CR1PureVisualDaggerVecEnvWrapper,
        )

        if args_cli.teacher_checkpoint is None:
            raise ValueError("A pure visual DAgger run requires --teacher_checkpoint")
        teacher_checkpoint = os.path.abspath(os.path.expanduser(args_cli.teacher_checkpoint))
        if not os.path.isfile(teacher_checkpoint):
            raise FileNotFoundError(
                f"Pure visual DAgger teacher checkpoint was not found: {teacher_checkpoint}"
            )
        runner_cfg["algorithm"]["teacher_checkpoint"] = teacher_checkpoint
        agent_cfg.algorithm.teacher_checkpoint = teacher_checkpoint
        env = CR1PureVisualDaggerVecEnvWrapper(env, clip_actions=agent_cfg.clip_actions)
        if runner_cfg.get("use_teacher_only_visual_bc", False):
            print(
                "[INFO] Teacher-only visual BC: every environment executes teacher means forever; "
                f"last {agent_cfg.algorithm.validation_num_envs} envs are held out of optimization. "
                "Only 2*KL + 1*feature MSE updates. Episode performance belongs to TEACHER.",
                flush=True,
            )
        else:
            print(
                "[INFO] Pure Visual DAgger uses BC warmup then fixed teacher/student mixing, "
                "online teacher labels, and only 2*KL + 1*feature imitation updates.",
                flush=True,
            )
    elif runner_cfg.get("use_dagger_visual_runner", False):
        from ladder.tasks.ladder_climb.config.cr1.dagger.visual_wrapper import (
            CR1DaggerVisualVecEnvWrapper,
        )

        if args_cli.teacher_checkpoint is None:
            raise ValueError("A visual DAgger run requires --teacher_checkpoint")
        teacher_checkpoint = os.path.abspath(
            os.path.expanduser(args_cli.teacher_checkpoint)
        )
        if not os.path.isfile(teacher_checkpoint):
            raise FileNotFoundError(
                f"Visual DAgger teacher checkpoint was not found: {teacher_checkpoint}"
            )
        runner_cfg["algorithm"]["teacher_checkpoint"] = teacher_checkpoint
        agent_cfg.algorithm.teacher_checkpoint = teacher_checkpoint
        env = CR1DaggerVisualVecEnvWrapper(
            env, clip_actions=agent_cfg.clip_actions
        )
        print(
            "[INFO] Visual DAgger student uses 5x85 proprio with +/-1 command, "
            "two Warp depth frames, and a 35-D velocity/height-map latent.",
            flush=True,
        )
    elif runner_cfg.get("use_dagger_runner", False):
        from ladder.tasks.ladder_climb.config.cr1.dagger.wrapper import (
            CR1DaggerVecEnvWrapper,
        )

        if args_cli.teacher_checkpoint is None:
            raise ValueError("A DAgger run requires --teacher_checkpoint")
        teacher_checkpoint = os.path.abspath(
            os.path.expanduser(args_cli.teacher_checkpoint)
        )
        if not os.path.isfile(teacher_checkpoint):
            raise FileNotFoundError(
                f"DAgger teacher checkpoint was not found: {teacher_checkpoint}"
            )
        runner_cfg["algorithm"]["teacher_checkpoint"] = teacher_checkpoint
        agent_cfg.algorithm.teacher_checkpoint = teacher_checkpoint
        env = CR1DaggerVecEnvWrapper(env, clip_actions=agent_cfg.clip_actions)
        print(
            "[INFO] CR1 DAgger uses a 5x84 deployable student history and "
            "separate full-state teacher/critic observations.",
            flush=True,
        )
    elif runner_cfg.get("use_transformer_vision_runner", False):
        from ladder.rsl_rl.runners import TransformerVisionPPOVecEnvWrapper
        from ladder.rsl_rl.modules.transformer_vision import (
            LEGACY_TASK_GOAL_TRANSFORMER_VISION_DATA_CONTRACT,
            VARIATIONAL_TRANSFORMER_VISION_DATA_CONTRACT,
        )

        if agent_cfg.resume:
            checkpoint_payload = torch.load(
                resume_path, map_location="cpu", weights_only=False
            )
            checkpoint_contract = checkpoint_payload.get("data_contract")
            if checkpoint_contract == VARIATIONAL_TRANSFORMER_VISION_DATA_CONTRACT:
                runner_cfg["algorithm"]["visual_architecture"] = "variational_legacy"
                agent_cfg.algorithm.visual_architecture = "variational_legacy"
            elif checkpoint_contract == LEGACY_TASK_GOAL_TRANSFORMER_VISION_DATA_CONTRACT:
                runner_cfg["algorithm"]["visual_architecture"] = "task_goal_legacy"
                agent_cfg.algorithm.visual_architecture = "task_goal_legacy"

        visual_initialization = runner_cfg["algorithm"].get(
            "visual_initialization", "checkpoint"
        )
        if visual_initialization not in ("checkpoint", "scratch"):
            raise ValueError(
                "TransformerVision visual_initialization must be 'checkpoint' or "
                f"'scratch', got {visual_initialization!r}"
            )
        if visual_initialization == "scratch" and args_cli.vision_checkpoint is not None:
            raise ValueError(
                "This TransformerVision task is configured for scratch training; "
                "do not pass --vision_checkpoint."
            )
        if args_cli.vision_checkpoint is not None:
            visual_checkpoint = os.path.abspath(os.path.expanduser(args_cli.vision_checkpoint))
            if not os.path.isfile(visual_checkpoint):
                raise FileNotFoundError(
                    f"TransformerVision pretraining checkpoint was not found: {visual_checkpoint}"
                )
            runner_cfg["algorithm"]["visual_checkpoint"] = visual_checkpoint
            agent_cfg.algorithm.visual_checkpoint = visual_checkpoint
        elif not agent_cfg.resume and visual_initialization == "checkpoint":
            raise ValueError(
                "A fresh TransformerVision PPO run requires --vision_checkpoint. "
                "Use --resume with a complete PPO checkpoint to continue an existing run."
            )
        elif not agent_cfg.resume:
            print(
                "[INFO] TransformerVision actor, critic, and visual encoder will train from scratch.",
                flush=True,
            )
        env = TransformerVisionPPOVecEnvWrapper(
            env,
            clip_actions=agent_cfg.clip_actions,
            clip_observations=getattr(agent_cfg, "clip_observations", None),
        )
        visual_latent_dim = (
            67
            if runner_cfg["algorithm"].get("visual_architecture") == "task_goal"
            else 51
        )
        print(
            "[INFO] TransformerVision PPO uses current proprio 85 + rollout-fixed "
            f"latent {visual_latent_dim}; the privileged critic remains separate.",
            flush=True,
        )
    elif runner_cfg.get("use_ladder_ssr_runner", False):
        from ladder.runners import LadderSSRVecEnvWrapper

        env = LadderSSRVecEnvWrapper(env, clip_actions=agent_cfg.clip_actions)
    else:
        env = RslRlVecEnvWrapper(env, clip_actions=agent_cfg.clip_actions)
        # rsl-rl 5 moved from one ActorCritic policy config to separate actor and
        # critic model configs. Older versions do not expose rsl_rl.models.MLPModel.
        try:
            from rsl_rl.models import MLPModel  # noqa: F401
        except ImportError:
            pass
        else:
            runner_cfg = convert_legacy_runner_cfg(runner_cfg)
    runner = OnPolicyRunner(env, runner_cfg, log_dir=log_dir, device=agent_cfg.device)
    runner.add_git_repo_to_log(__file__)
    if agent_cfg.resume:
        print(f"[INFO]: Loading model checkpoint from: {resume_path}")
        runner.load(resume_path)

    dump_yaml(os.path.join(log_dir, "params", "env.yaml"), env_cfg)
    dump_yaml(os.path.join(log_dir, "params", "agent.yaml"), agent_cfg)
    dump_pickle(os.path.join(log_dir, "params", "env.pkl"), env_cfg)
    dump_pickle(os.path.join(log_dir, "params", "agent.pkl"), agent_cfg)

    if runner_cfg.get("use_teacher_only_visual_bc", False):
        runner.alg.configure_diagnostics(
            log_dir, runner_cfg, args_cli.motion_file, teacher_checkpoint, runner.logger,
            resume_path=resume_path if agent_cfg.resume else None,
        )

    runner.learn(num_learning_iterations=agent_cfg.max_iterations, init_at_random_ep_len=True)
    env.close()


if __name__ == "__main__":
    main()
    simulation_app.close()
