// Wood step ladder parametric OpenSCAD model
// Units: meters

total_h = 1.8;
front_phi = 65.0;
step_count = 7;
step_w = 0.8;
step_d = 0.18;
step_t = 0.06;
step_spacing = 0.25;
rear_spread = 1.1;
side_t = 0.06;
side_d = 0.14;

module box(size) { cube(size, center=true); }

function y_from_z(z) = -z / tan(front_phi);

for (i = [1:step_count]) {
    z = i * step_spacing;
    translate([0, y_from_z(z) + step_d * 0.10, z])
        box([step_w, step_d, step_t]);
    translate([0, y_from_z(z) + step_d / 2 + 0.003, z + step_t / 2 + 0.002])
        box([step_w, 0.018, 0.006]);
}

rail_len = total_h / sin(front_phi) + 0.2;
rail_mid_y = (y_from_z(step_spacing) + y_from_z(total_h)) / 2;
rail_mid_z = (step_spacing + total_h) / 2;

for (x = [-step_w/2 - side_t/2, step_w/2 + side_t/2]) {
    translate([x, rail_mid_y, rail_mid_z])
        rotate([90-front_phi, 0, 0])
            box([side_t, side_d, rail_len]);
}

top_y = y_from_z(total_h);
translate([0, top_y - 0.22 * 0.15, total_h])
    box([step_w + 0.12, 0.22, 0.06]);

for (x = [-step_w/2 - side_t/2, step_w/2 + side_t/2]) {
    translate([x, top_y, total_h + 0.11])
        box([0.09, 0.12, 0.22]);
}

rear_y = y_from_z(step_spacing) - rear_spread;
rear_mid_y = (rear_y + top_y) / 2;
rear_mid_z = total_h / 2;
rear_angle = atan2(total_h, top_y - rear_y);

for (x = [-step_w/2 - 0.05, step_w/2 + 0.05]) {
    translate([x, rear_mid_y, rear_mid_z])
        rotate([90-rear_angle, 0, 0])
            box([0.08, 0.08, total_h / sin(rear_angle) + 0.16]);
}

translate([0, rear_y + (top_y - rear_y) * (0.78 / total_h), 0.78])
    box([step_w + 0.12, 0.07, 0.08]);
